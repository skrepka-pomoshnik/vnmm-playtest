"""Short, seeded road notes for the transition card."""

from dataclasses import dataclass

from mmvn.models import GameState


@dataclass(frozen=True)
class TravelBeat:
    """A short piece of travel writing shown after a successful move."""

    beat_id: str
    title: str
    body: str


TRAVEL_CARD_BEATS: dict[tuple[str, str], tuple[TravelBeat, ...]] = {
    ("dorm", "faculty"): (
        TravelBeat(
            "dorm_faculty_path",
            "Дорога к факультету",
            "От общежития до корпуса пятнадцать минут пешком. Утренний поток уже тянется к лестнице, и я успеваю сверить аудиторию до того, как она потеряется среди дверей.",
        ),
        TravelBeat(
            "dorm_faculty_students",
            "По пути",
            "На повороте к факультету двое студентов сверяют один лист на двоих. Один спрашивает, где сегодня матан; я показываю расписание и иду дальше.",
        ),
        TravelBeat(
            "dorm_faculty_wind",
            "У корпуса",
            "Ветер с Университетской выворачивает край расписания. Я прижимаю лист папкой и захожу в корпус с тем же планом, с которым вышел.",
        ),
        TravelBeat(
            "dorm_faculty_mel",
            "Короткая дорога",
            "У входа кто-то роняет кусок мела. Мы поднимаем его одновременно, и студент спрашивает, не видел ли я аудиторию 09.",
        ),
        TravelBeat(
            "dorm_faculty_goat",
            "Тимяшкинская дорожная служба",
            "На дорожке к факультету меня остановила тимяшкинская коза: сначала преградила путь, потом боднула сумку. Один лист расписания пришлось поднять с земли, но до корпуса я добрался.",
        ),
    ),
    ("faculty", "dorm"): (
        TravelBeat(
            "faculty_dorm_steps",
            "Обратно в общежитие",
            "Корпус остаётся за спиной, а дорога до общежития занимает те же пятнадцать минут. На лестнице ещё слышны голоса тех, кто решил задержаться.",
        ),
        TravelBeat(
            "faculty_dorm_schedule",
            "Лист на ветру",
            "У выхода я складываю расписание вчетверо. На улице оно снова раскрывается на самом неудобном месте — там, где завтрашний день начинается раньше, чем хотелось бы.",
        ),
        TravelBeat(
            "faculty_dorm_student",
            "После занятий",
            "У ворот меня догоняет студент с факультетской папкой и спрашивает, не перенесли ли приём. Мы сверяем листы; ни один не выглядит окончательным.",
        ),
    ),
    ("faculty", "mausoleum"): (
        TravelBeat(
            "faculty_mausoleum_lunch",
            "К Мавзолею",
            "От факультета до Мавзолея идти четверть часа. Чем ближе столовая, тем труднее делать вид, что запах горячего чая не относится ко мне.",
        ),
        TravelBeat(
            "faculty_mausoleum_queue",
            "Короткий переход",
            "На дорожке к Мавзолею люди расходятся в разные стороны: одни несут папки, другие уже обсуждают, что взять к чаю. Я выбираю темп, с которым ещё можно успеть обратно.",
        ),
        TravelBeat(
            "faculty_mausoleum_kolya",
            "У входа в столовую",
            "У входа в Мавзолей Коля считает мелочь и одновременно рассказывает кому-то про долг. Увидев меня, он убирает монеты в карман и делает вид, что разговор окончен.",
        ),
    ),
    ("mausoleum", "faculty"): (
        TravelBeat(
            "mausoleum_faculty_tea",
            "Из Мавзолея к корпусу",
            "Чай остаётся в Мавзолее, а факультет снова зовёт лестницами и папками. Через пятнадцать минут я уже различаю знакомое окно у деканата.",
        ),
        TravelBeat(
            "mausoleum_faculty_queue",
            "После короткого перерыва",
            "У выхода из Мавзолея двое студентов спорят, считать ли разговор за столом отдыхом. Я не вмешиваюсь: до факультета всё равно идти четверть часа.",
        ),
        TravelBeat(
            "mausoleum_faculty_note",
            "Записка на ходу",
            "Кто-то сунул мне в руку листок с номером аудитории и сразу побежал обратно. Я читаю его только у корпуса: почерк оказался знакомым, а номер — нет.",
        ),
    ),
    ("dorm", "mausoleum"): (
        TravelBeat(
            "dorm_mausoleum_route",
            "Через двор к Мавзолею",
            "До Мавзолея дорога проходит через двор и дальше к факультетской столовой. Я иду за студентами с кружками, потому что они явно знают короткий путь.",
        ),
        TravelBeat(
            "dorm_mausoleum_hunger",
            "Запах столовой",
            "На полпути начинает пахнуть горячей выпечкой. Это не помогает планировать день, зато объясняет, почему люди с факультета идут быстрее обычного.",
        ),
    ),
    ("mausoleum", "dorm"): (
        TravelBeat(
            "mausoleum_dorm_evening",
            "Домой после Мавзолея",
            "От Мавзолея я возвращаюсь к общежитию с папкой под мышкой. Вечерний двор уже заполняется теми, кто только собирается начать свою часть дня.",
        ),
        TravelBeat(
            "mausoleum_dorm_receipt",
            "Последняя крошка",
            "На выходе я проверяю карманы: там остаётся чек, карандаш и один кусок сахара, который не удалось растворить в чае.",
        ),
    ),
    ("pomi", "faculty"): (
        TravelBeat(
            "pomi_faculty_arrival",
            "С Балтийского к корпусу",
            "После дороги через Балтийский вокзал Университетская кажется почти соседним двором. На платформе я ещё раз проверяю, в какую сторону идти к факультету.",
        ),
    ),
    ("pomi", "dorm"): (
        TravelBeat(
            "pomi_dorm_arrival",
            "С Балтийского к общежитию",
            "Город остаётся за спиной, а после электрички дорога к общежитию кажется продолжением одного длинного расписания.",
        ),
    ),
    ("faculty", "pomi"): (
        TravelBeat(
            "faculty_pomi_train",
            "К Балтийскому вокзалу",
            "До ПОМИ начинается не с двери факультета, а с длинной дороги к электричке. Я прячу расписание поглубже: в вагоне оно всё равно будет жить собственной жизнью.",
        ),
    ),
    ("dorm", "pomi"): (
        TravelBeat(
            "dorm_pomi_train",
            "Из общежития в город",
            "Сначала нужно дойти до Университетской, потом дорога сама превратится в электричку. Я проверяю билет, папку и расписание в этом порядке.",
        ),
    ),
}


DEFAULT_TRAVEL_BEAT = TravelBeat(
    "generic_travel",
    "Дорога",
    "Переход закончен. Новое место встречает обычным шумом, а расписание уже требует следующего решения.",
)

TRAVEL_MISHAP_BEATS = {
    "martyshkino": TravelBeat(
        "mishap_martyshkino",
        "Мартышкино",
        "Дорога закончилась не на той станции. Я снова сверяю название платформы и решаю, что сегодня расписание явно проверяет меня на внимательность.",
    ),
    "remiz": TravelBeat(
        "mishap_remiz",
        "Заячий Ремиз",
        "Автобус привёз меня не туда. На обратной остановке я держу расписание открытым, пока знакомое направление наконец не появляется на табличке.",
    ),
    "dogs": TravelBeat(
        "mishap_dogs",
        "Дорога с препятствием",
        "У платформы дорогу перекрыла стая. Я выбираю обход и ещё некоторое время слышу лай за гаражами.",
    ),
}


def _beats_for(origin: str, destination: str) -> tuple[TravelBeat, ...]:
    return TRAVEL_CARD_BEATS.get((origin, destination), (DEFAULT_TRAVEL_BEAT,))


def travel_card_beat_id(state: GameState, origin: str, destination: str) -> str:
    """Return one reproducible road beat without consuming gameplay RNG."""

    beats = _beats_for(origin, destination)
    route_sum = sum(map(ord, origin)) + sum(map(ord, destination))
    index = (state.seed + state.day * 17 + state.slot * 11 + route_sum) % len(beats)
    return beats[index].beat_id


def travel_card_beat(
    state: GameState,
    origin: str,
    destination: str,
    beat_id: str | None = None,
) -> TravelBeat:
    """Return a stored beat, falling back safely for a fixture or new route."""

    beats = _beats_for(origin, destination)
    selected_id = beat_id or travel_card_beat_id(state, origin, destination)
    return next((beat for beat in beats if beat.beat_id == selected_id), beats[0])


def travel_mishap_beat(kind: str | None) -> TravelBeat:
    """Return the short explanation shown after a return-trip mishap."""

    return TRAVEL_MISHAP_BEATS.get(kind, DEFAULT_TRAVEL_BEAT)


__all__ = [
    "DEFAULT_TRAVEL_BEAT",
    "TRAVEL_CARD_BEATS",
    "TRAVEL_MISHAP_BEATS",
    "TravelBeat",
    "travel_card_beat",
    "travel_card_beat_id",
    "travel_mishap_beat",
]
