"""Short subject-specific exam beats kept separate from exam arithmetic."""

from dataclasses import dataclass

from mmvn.constants import PRESENCE_LABELS, RandomSource
from mmvn.models import GameState
from mmvn.rules.domain.exams.exam_projection import exam_crowd_candidates
from mmvn.schedule import RESERVE_SLOT


@dataclass(frozen=True)
class SubjectFlavor:
    intro_variants: tuple[str, ...]
    success_variants: tuple[str, ...]
    failure_variants: tuple[str, ...]


SUBJECT_FLAVOR = {
    "algebra": SubjectFlavor(
        (
            "На столе лежит задача с определителем. Предыдущий студент оставил рядом половинку мела.",
            "На доске уже записаны четыре строки. Преподаватель просит начать с определения.",
            "Преподаватель просматривает решение и дважды возвращается к одному переходу.",
        ),
        (
            "Последний переход сошёлся. Преподаватель откладывает лист рядом с ведомостью.",
            "На листе осталось несколько исправлений, но объяснение принято.",
        ),
        (
            "Условие на базис исчезло между двумя строками. Мы втроём — я, преподаватель и собственный лист — некоторое время его ищем.",
            "Преподаватель обводит неверный переход моей ручкой. За весь ответ это первая вещь, которая получается с первого раза.",
        ),
    ),
    "matan": SubjectFlavor(
        (
            "Матан начинается с определения. На следующей странице оно уже понадобится дважды.",
            "На доске написан предел, а рядом оставлено место для доказательства.",
            "Преподаватель листает работу молча и останавливается возле оценки сходимости.",
        ),
        (
            "Оценка получилась с нужной стороны. Преподаватель закрывает работу.",
            "Последнее уточнение принято. Я наконец опускаю руку с мелом.",
        ),
        (
            "Условия сходимости нет. Оно находится на обороте листка, которым я заложил нужную страницу конспекта.",
            "На втором уточняющем вопросе я наконец отвечаю на первый. Преподаватель терпеливо уточняет, в каком порядке ждать остальные.",
        ),
    ),
    "geometry": SubjectFlavor(
        (
            "На столе лежит аккуратный рисунок. Теперь надо объяснить, какие линии заданы условием.",
            "Задача начинается с множества, которое на школьную фигуру совсем не похоже.",
            "Преподаватель сначала рассматривает рисунок, потом просит сформулировать идею без него.",
        ),
        (
            "Недостающая прямая появилась из условия, а не из рисунка. Ответ принят.",
            "Преподаватель кивает и просит оставить схему следующему студенту.",
        ),
        (
            "Спасающая доказательство прямая оказывается сгибом от предыдущей страницы. Я стираю её, и доказательство уходит вместе с ней.",
            "Доказательство работает для фигуры, которая существует только на моём рисунке. Преподаватель разрешает забрать её с собой.",
        ),
    ),
    "informatics": SubjectFlavor(
        (
            "В компьютерном классе свободна одна машина. У соседней уже ждут окончания теста.",
            "Сначала приходится найти принимающего преподавателя, потом — свою папку на диске.",
            "На экране мигает приглашение командной строки. Я ещё раз проверяю имя файла.",
        ),
        (
            "Программа проходит оба теста. Преподаватель записывает результат в ведомость.",
            "После последнего запуска ошибок нет. Во всяком случае, видимых.",
        ),
        (
            "Программа падает на втором тесте так быстро, что преподаватель не успевает сесть обратно.",
            "Ошибка повторяется по команде. Компьютер бодро возвращает приглашение, будто именно этого от него и добивались.",
        ),
    ),
    "english": SubjectFlavor(
        (
            "Перед английским я повторяю будущие времена и несколько слов о летних планах.",
            "Преподавательница находит мою фамилию в журнале и задаёт первый вопрос.",
            "На доске остались слова предыдущего студента. Мой рассказ должен быть другим.",
        ),
        (
            "Рассказ получился связным, хотя одно время пришлось исправить.",
            "Преподавательница закрывает журнал и открывает зачётку на нужной странице.",
        ),
        (
            "К концу ответа летние планы успевают побывать в прошлом, будущем и ещё одном времени, которого в таблице не было.",
            "Слов хватает, но времена меняются при каждом вопросе. Неизменным остаётся только желание выйти в коридор.",
        ),
    ),
    "pe": SubjectFlavor(
        (
            "На физкультуре Серж уже держит секундомер, хотя старт ещё не дали.",
            "Дорожка отсюда выглядит короткой. За первым поворотом это впечатление проходит.",
            "Преподаватель сверяет фамилию в ведомости и отправляет меня на старт.",
        ),
        (
            "Секундомер останавливается внутри норматива. Серж показывает результат.",
            "После финиша я ещё могу назвать фамилию. Преподаватель находит её в ведомости.",
        ),
        (
            "До норматива не хватает нескольких секунд. Я ищу их на циферблате, Серж показывает на дорожку.",
            "Дорожка закончилась, а нужное время осталось на другой стороне секундомера.",
        ),
    ),
}

EXAM_FAILURE_HINTS = {
    "algebra": (
        "Следующий ответ начни с условия: назови определение, выпиши базис и проверь переход "
        "на простом примере."
    ),
    "matan": (
        "Проверь условие сходимости и приведи пример, где две функции выглядят одинаково, "
        "но ведут себя по-разному."
    ),
    "geometry": (
        "Сначала выпиши, что гарантирует фигура, затем назови инвариант и проверь граничный случай."
    ),
    "informatics": ("Раздели условие на вход, ожидаемый выход и ошибку, которую повторяет тест."),
    "english": (
        "Подготовь письмо с конкретным примером и короткий устный ответ; проверь время глаголов."
    ),
    "pe": (
        "Запиши норматив и разбей его на повторяемые упражнения; спроси Сержа, где легче потерять секунды."
    ),
}


# These are short pieces of faculty folklore, not claims about real teachers
# or a historical source.  The story layer maps the stable ids to editable
# dialogue labels after the kernel has made the random choice.
EXAM_QUEUE_ANECDOTES: dict[str, tuple[str, ...]] = {
    "algebra": (
        "algebra_bounded_entire",
        "algebra_well_defined",
        "algebra_counterexample",
    ),
    "matan": (
        "matan_four_dimensions",
        "matan_pointwise",
        "matan_integral",
    ),
    "geometry": (
        "geometry_euler",
        "geometry_example",
        "geometry_counterexample",
    ),
}


def _pick(options: tuple[str, ...], subject: str, state: GameState) -> str:
    index = (state.seed + state.day * 3 + state.slot + state.brain + len(subject)) % len(options)
    return options[index]


def exam_intro(subject: str, state: GameState) -> str:
    """Return one deterministic intro line for a subject's first exam scene."""

    flavor = SUBJECT_FLAVOR.get(subject)
    if flavor is None:
        return "Преподаватель открывает ведомость и ждёт содержательного ответа."
    return _pick(flavor.intro_variants, subject, state)


def pe_lecture_variant(state: GameState) -> int:
    """Return the seeded PE lecture variant 0..4.

    RV-H7: seed константен на прохождение, поэтому ``seed % N`` всегда даёт
    один вариант. День и слот смешиваются через коэффициенты, взаимно простые
    к пятёрке: иначе слагаемое исчезает по модулю. Результат остаётся чистой
    функцией состояния.
    """

    return (state.seed + state.day * 13 + state.slot * 7) % 5


def exam_outro(subject: str, passed: bool, state: GameState) -> str:
    """Return a subject-specific success or failure beat after the resolver."""

    flavor = SUBJECT_FLAVOR.get(subject)
    if flavor is None:
        return "Результат записан в ведомость."
    options = flavor.success_variants if passed else flavor.failure_variants
    return _pick(options, subject, state)


def exam_failure_feedback(subject: str, before: GameState, after: GameState) -> str:
    """Return one concrete next step after an unresolved exam attempt."""

    after_progress = after.subject(subject)
    if subject not in EXAM_FAILURE_HINTS or after_progress is None or after_progress.passed:
        return ""

    hints = [EXAM_FAILURE_HINTS[subject]]
    reserve_upcoming = after.day == 5 or (after.day == 6 and after.slot < RESERVE_SLOT)
    if reserve_upcoming:
        if after.reserve_subject == subject:
            hints.append("Резерв уже закреплён за этим предметом; используй его на шестом дне.")
        elif after.reserve_all:
            hints.append("На шестом дне резерв общий; выбери в него этот предмет.")
        else:
            hints.append(
                "На шестом дне проверь резервное окно и не оставляй этот предмет на последнее место."
            )
    elif after.day >= 6:
        hints.append("Резервное окно уже прошло; проверь зачётку и доступные финальные сцены.")
    else:
        candidates = exam_crowd_candidates(before, subject)
        if candidates:
            name = PRESENCE_LABELS.get(candidates[0], candidates[0])
            hints.append(f"До окна рядом был {name}; у него можно уточнить один переход.")
        elif before.has_note(subject):
            hints.append(
                "У Саши есть конспект по этому предмету; открой определение и один пример."
            )
        else:
            before_progress = before.subject(subject)
            if (
                before_progress is not None
                and after_progress.tasks_done > before_progress.tasks_done
            ):
                hints.append(
                    "В зачётке уже есть новые шаги; следующий раз начни с оставшейся задачи."
                )
    return " ".join(hints)


def exam_queue_anecdote(subject: str, rng: RandomSource) -> str | None:
    """Pick one math-faculty queue story using the caller-provided RNG."""

    options = EXAM_QUEUE_ANECDOTES.get(subject)
    if options is None:
        return None
    return options[rng.randrange(len(options))]


def wrong_room_variant(subject: str, state: GameState) -> bool:
    """Return whether the authored rare wrong-room beat should appear."""

    return subject == "algebra" and (state.seed + state.day * 5 + state.slot) % 11 == 0


def zilberbord_delay_variant(subject: str, state: GameState) -> bool:
    """Return whether Zilberbord is late by half a pair (deterministic per seed/time)."""

    return subject == "algebra" and (state.seed + state.day * 7 + state.slot * 3 + 4) % 5 == 0


__all__ = [
    "EXAM_QUEUE_ANECDOTES",
    "SUBJECT_FLAVOR",
    "SubjectFlavor",
    "exam_failure_feedback",
    "exam_intro",
    "exam_outro",
    "exam_queue_anecdote",
    "pe_lecture_variant",
    "progress_humor_line",
    "stat_status_label",
    "stat_status_summary",
    "wrong_room_variant",
    "zilberbord_delay_variant",
]


# DREAM-02: тёмно-юморные реплики про прогресс (показываются как narrator).
PROGRESS_HUMOR: dict[str, tuple[str, ...]] = {
    "algebra": (
        "Определитель уже нулевой. Как и моя мотивация на оставшуюся неделю.",
        "Говорят, кольцо многочленов коммутативно. В отличие от расписания.",
    ),
    "matan": (
        "Эта вероятность такая же, как встретить голубя на НИИФ. То есть ненулевая, но об этом лучше не думать.",
        "Хуже этой недели уже ничего не будет. Только война, чума или сессия на пятом курсе.",
    ),
    "geometry": (
        "Доказательство от противного: предположим, что я успеваю. Противоречие.",
        "Топология говорит, что кружка и пончик гомеоморфны. Моя кружка пуста, как и надежды на резерв.",
    ),
    "informatics": (
        "Если эта программа скомпилируется с первого раза, значит что-то не так.",
        "Алгоритм O(n²) при n = один день до зачёта. Работает медленнее, чем я думаю.",
    ),
    "english": (
        "Present Perfect — это про то, что результат виден сейчас. Результат: я всё ещё здесь.",
        "Мисс Ли спрашивает про планы на будущее. Будущее — это послезавтра, если я закрою алгебру.",
    ),
    "pe": (
        "Норматив сдан. Осталось только не умереть на остальных предметах.",
        "Пульс 140. Или от бега, или от Всемирнова. Секундомер не различает.",
    ),
}


def progress_humor_line(state: GameState, subject: str) -> str:
    """Return one dark-humor line for the current exam progress, or empty string."""

    progress = state.subject(subject)
    if progress is None:
        return ""
    lines = PROGRESS_HUMOR.get(subject)
    if not lines:
        return ""
    # RV-H6: встроенный hash() рандомизирован между процессами
    # (PYTHONHASHSEED) и ломал контракт «тот же seed = тот же текст».
    # Арифметическое смешивание — как в остальных селекторах файла.
    index = (state.seed + state.day * 7 + sum(map(ord, subject))) % len(lines)
    return lines[index]


# --- Status labels (merged from status_labels.py) ---
"""Human-scale descriptions for the compact resource values."""

_STATUS_THRESHOLDS = {
    "health": (
        (15, "живой труп"),
        (30, "так себе"),
        (55, "держусь"),
        (75, "в порядке"),
        (10**9, "бодр"),
    ),
    "brain": (
        (2, "каша"),
        (4, "тяжело думать"),
        (6, "голова работает"),
        (8, "голова свежая"),
        (10**9, "разогнался"),
    ),
    "stamina": (
        (1, "пора спать"),
        (3, "устал"),
        (5, "держусь"),
        (7, "ещё есть силы"),
        (10**9, "на подъёме"),
    ),
    "charisma": (
        (2, "лучше молчать"),
        (4, "неловко"),
        (6, "можно говорить"),
        (8, "свой человек"),
        (10**9, "душа компании"),
    ),
    "money": (
        (0, "пусто"),
        (5, "только на чай"),
        (15, "хватит на день"),
        (35, "есть запас"),
        (10**9, "можно не считать мелочь"),
    ),
}


def stat_status_label(field: str, value: int) -> str:
    """Return a short, non-mechanical description of a resource value."""

    thresholds = _STATUS_THRESHOLDS.get(field)
    if thresholds is None:
        return ""
    for limit, label in thresholds:
        if value <= limit:
            return label
    return thresholds[-1][1]


def stat_status_summary(stats: object) -> str:
    """Return a compact line suitable for a paper status panel."""

    fields = (
        ("HP", "health"),
        ("мозги", "brain"),
        ("STA", "stamina"),
        ("харизма", "charisma"),
        ("₽", "money"),
    )
    return " · ".join(
        f"{short_name} {getattr(stats, field)} · {stat_status_label(field, getattr(stats, field))}"
        for short_name, field in fields
    )
