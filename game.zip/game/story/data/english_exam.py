"""Writer-facing structure of the English examination.

The rules kernel keeps one compact progress counter for every subject.  This
module gives the English scene its own vocabulary, so that counter never has
to leak into the presentation as a list of generic tasks.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EnglishExamPart:
    """One part of Miss Lee's examination."""

    key: str
    title: str
    description: str


ENGLISH_EXAM_TOPIC = "Планы на лето"

ENGLISH_EXAM_PARTS = (
    EnglishExamPart(
        "grammar",
        "Грамматика",
        "Времена, формы слов и порядок слов",
    ),
    EnglishExamPart(
        "writing",
        "Письмо",
        "Короткий текст на тему «Планы на лето»",
    ),
    EnglishExamPart(
        "speaking",
        "Говорение",
        "Связный устный ответ по той же теме",
    ),
)


__all__ = ("ENGLISH_EXAM_PARTS", "ENGLISH_EXAM_TOPIC", "EnglishExamPart")
