"""Writer-facing data modules used by the Ren'Py story layer."""
