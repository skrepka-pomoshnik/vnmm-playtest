"""A new MatMech content layer on top of the imported Zork topology.

The side program keeps the original graph's directed movement structure, but
all player-facing names, descriptions, objects, and puzzles are authored for
this project. It is deliberately a small immutable reducer so the Ren'Py
adapter can pause, redraw, and rollback it safely.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from ..semantic_ids import quest_node_semantic_id
from .zork_graph import ZORK_ROOM_KEYS, outgoing_exits

ZORK_QUEST_ID = "zork_matmech"
ZORK_TITLE = "ПОДЗЕМЕЛЬЯ МАТМЕХА"
ZORK_START_ROOM = "WHOUS"

_DIRECTION_LABELS = {
    "NORTH": "на север",
    "SOUTH": "на юг",
    "EAST": "на восток",
    "WEST": "на запад",
    "NE": "на северо-восток",
    "NW": "на северо-запад",
    "SE": "на юго-восток",
    "SW": "на юго-запад",
    "UP": "вверх",
    "DOWN": "вниз",
    "ENTER": "войти",
    "EXIT": "выйти",
    "OUT": "наружу",
    "LEAVE": "уйти",
    "CROSS": "перейти",
    "LAND": "выйти на берег",
    "LAUNC": "к шлюзу",
    "#!#!#": "аномальный переход",
}

_ITEM_LABELS = {
    "student_ticket": "студенческий билет",
    "floppy": "дискета с расписанием",
    "chalk": "обломок мела",
}

_REQUIREMENT_LABELS = {
    "ticket_checked": "проверка студенческого билета",
}

_ROOM_LABELS = {
    "WHOUS": "Западный двор Матмеха",
    "NHOUS": "Северная галерея",
    "SHOUS": "Южный двор",
    "EHOUS": "Стена корпуса",
    "KITCH": "Кафедральная кухня",
    "ATTIC": "Чердак над лабораторией",
    "LROOM": "Комната с лестницей",
    "BLROO": "Тёмный коридор",
    "CELLA": "Подвальная клетушка",
    "MTROL": "Технический ролик",
    "STUDI": "Старая аудитория",
    "GALLE": "Галерея списанных досок",
    "CYCLO": "Зал циклических машин",
    "TREAS": "Архивный сейф",
    "CPANT": "Антенная ниша",
    "CPOUT": "Машинный двор",
    "CP": "Пульт подземной сети",
}

_ROOM_INDEX = {key: index + 1 for index, key in enumerate(ZORK_ROOM_KEYS)}

# These are authored content-layer guards on top of unchanged graph edges.
# They mirror the source graph's idea of conditional exits without importing
# its names or prose into the new game.
_MOVE_GUARDS = {
    ("KITCH", "LROOM", "WEST"): ("floppy",),
    ("LROOM", "BLROO", "WEST"): ("ticket_checked",),
}


@dataclass(frozen=True)
class ZorkOption:
    """One safe, visible command in the remapped graph."""

    command: str
    label: str
    description: str


@dataclass(frozen=True)
class ZorkSession:
    """Immutable state for the MatMech Zork-like terminal."""

    quest_id: str
    title: str
    location: str
    location_label: str
    prompt: str
    text: str
    options: tuple[ZorkOption, ...]
    inventory: frozenset[str] = frozenset()
    facts: frozenset[str] = frozenset()
    history: tuple[str, ...] = ()
    turn: int = 0
    score: int = 0
    finished: bool = False
    outcome: str = "in_progress"
    last_ok: bool = True
    last_message: str = ""

    @property
    def semantic_id(self) -> str:
        """Stable content-layer ID; ZORK stays separate from DOS quests."""

        return quest_node_semantic_id(self.quest_id, self.location, namespace="quest.zork")

    @property
    def inventory_labels(self) -> tuple[str, ...]:
        """Return stable, localized inventory labels for the terminal HUD."""

        return tuple(
            _ITEM_LABELS.get(item, item)
            for item in sorted(self.inventory, key=lambda value: _ITEM_LABELS.get(value, value))
        )

    @property
    def inventory_text(self) -> str:
        """Return an empty-safe inventory string for Ren'Py text interpolation."""

        return ", ".join(self.inventory_labels) or "пусто"


def _room_label(room_key: str) -> str:
    return _ROOM_LABELS.get(room_key, f"Сектор подземелья {_ROOM_INDEX.get(room_key, 0):03d}")


def _direction_label(direction: str) -> str:
    return _DIRECTION_LABELS.get(direction, f"по метке {direction.lower()}")


def _prompt(room_key: str) -> str:
    return f"C:\\MM\\DUNGEON\\{_ROOM_INDEX.get(room_key, 0):03d}>"


def _room_text(room_key: str, inventory: frozenset[str], facts: frozenset[str]) -> str:
    """Describe a remapped room without importing any source prose."""

    if room_key == "WHOUS":
        return (
            "Ты стоишь во дворе Матмеха. Под асфальтом слышно ровное гудение: "
            "где-то ниже работает забытая вычислительная сеть. На старом плане "
            "есть надпись «вход для тех, у кого есть билет»\n\n"
            "Стрелки здесь не декоративны: это карта, которую оставила сама "
            "топология корпуса."
        )
    if room_key == "NHOUS":
        return (
            "Северная галерея заставлена досками объявлений. Свежая бумажка "
            "утверждает, что под корпусом нет никакого подземелья. Бумажка "
            "прикреплена к двери, ведущей дальше."
        )
    if room_key == "SHOUS":
        return "Южный двор пуст, кроме скамейки и провода, уходящего под землю. На проводе мелом отмечен один узел."
    if room_key == "EHOUS":
        return "За корпусом заканчивается дневной свет. На стене сохранился номер кабинета, которого нет в расписании."
    if room_key == "KITCH":
        found = (
            "Дискета уже у тебя."
            if "floppy" in inventory
            else "Под кипятильником лежит синяя дискета с наклейкой «РАСПИСАНИЕ»."
        )
        chalk = (
            "Обломок мела рядом с дискетой."
            if "chalk" not in inventory
            else "На краю стола осталась белая меловая пыль."
        )
        return f"Кафедральная кухня пережила ремонт. {found} {chalk}"
    if room_key == "ATTIC":
        return "На чердаке стоят коробки с ведомостями. Сверху на них написано: «не выбрасывать до следующей сессии»."
    if room_key == "LROOM":
        return "Комната с лестницей делит корпус на обычный и подземный маршруты. На ступеньке кто-то оставил карандашную стрелку."
    if room_key == "BLROO":
        return "Тёмный коридор пахнет пылью и горячим пластиком. Свет включается только после того, как ты перестаёшь его ждать."
    if room_key == "CELLA":
        mark = (
            "На стене есть твоя стрелка."
            if "wall_marked" in facts
            else "Стена гладкая; здесь легко забыть, откуда пришёл."
        )
        return f"В подвальной клетушке помещается один стул и половина шкафа. {mark}"
    if room_key == "MTROL":
        return "Технический ролик вращает кабельную катушку. Перед ним турникет с щелью под студенческий билет."
    if room_key == "STUDI":
        return "Старая аудитория превращена в склад. На доске осталась схема, в которой стрелки не обязаны возвращаться назад."
    if room_key == "GALLE":
        return "Галерея списанных досок. На каждой второй доске — кусок расписания, а на третьей кто-то вывел слово «проверяй»."
    if room_key == "CYCLO":
        return "Зал циклических машин гудит, хотя ни одной машины не видно. Проход вверх отмечен свежей лентой."
    if room_key == "TREAS":
        return "Архивный сейф не хранит золота. В нём лежат только старые схемы, ведомости и одна дверь в машинную часть."
    if room_key == "CPANT":
        return "Антенная ниша принимает сигналы из корпуса. На табло мигает один и тот же номер сектора."
    if room_key == "CPOUT":
        return "Машинный двор выходит к кабелям, проложенным поверх старой кладки. Один кабель ведёт к пульту."
    if room_key == "CP":
        if "floppy" in inventory and "ticket_scanned" in facts:
            return "Пульт узнал билет и видит дискету. Осталось решить, стоит ли запускать программу, которой нет в расписании."
        return "Пульт подземной сети просит два подтверждения: личность студента и носитель с расписанием."
    return (
        f"{_room_label(room_key)}. Здесь сходятся несколько старых маршрутов. "
        "На стене прикреплена новая матмеховская карточка: «сначала осмотри, "
        "потом выбирай»."
    )


def _context_options(
    room_key: str,
    inventory: frozenset[str],
    facts: frozenset[str],
) -> list[ZorkOption]:
    options: list[ZorkOption] = []
    if room_key == "WHOUS" and "ticket_checked" not in facts:
        options.append(
            ZorkOption(
                "check_ticket",
                "Проверить студенческий билет",
                "Сверить курс и специализацию с подземным пропуском.",
            )
        )
    if room_key == "KITCH":
        if "floppy" not in inventory:
            options.append(
                ZorkOption(
                    "take_floppy",
                    "Забрать синюю дискету",
                    "Без носителя пульт не сможет прочитать расписание.",
                )
            )
        if "chalk" not in inventory:
            options.append(
                ZorkOption(
                    "take_chalk",
                    "Взять обломок мела",
                    "Мел пригодится, если топология решит притвориться лабиринтом.",
                )
            )
    if room_key == "MTROL" and "ticket_checked" not in facts and "student_ticket" in inventory:
        options.append(
            ZorkOption(
                "show_ticket",
                "Предъявить студенческий билет",
                "Оставить на турникете не подпись, а проверяемый факт.",
            )
        )
    if room_key == "STUDI" and "chalk" in inventory and "wall_marked" not in facts:
        options.append(
            ZorkOption(
                "mark_wall",
                "Отметить выход мелом",
                "Сделать один из возвратных маршрутов видимым.",
            )
        )
    if room_key == "CP":
        if "ticket_scanned" not in facts and "student_ticket" in inventory:
            options.append(
                ZorkOption(
                    "scan_ticket",
                    "Приложить студенческий билет к считывателю",
                    "Пульт проверит личность перед запуском старой сети.",
                )
            )
        if "terminal_seen" not in facts:
            options.append(
                ZorkOption(
                    "inspect_terminal",
                    "Осмотреть пульт",
                    "Проверить, что именно он считает расписанием.",
                )
            )
        if "floppy" in inventory and "ticket_scanned" in facts:
            options.append(
                ZorkOption(
                    "insert_floppy",
                    "Вставить дискету и запустить ЗОРК.EXE",
                    "Проверить, можно ли пройти граф до конца и вернуться в день.",
                )
            )
    options.append(
        ZorkOption(
            "look",
            "Осмотреться ещё раз",
            "Обновить описание сектора, не меняя положение.",
        )
    )
    return options


def _movement_options(room_key: str) -> list[ZorkOption]:
    options = []
    for index, (target, direction) in enumerate(outgoing_exits(room_key)):
        target_label = "тупик" if target == "NoExit" else _room_label(target)
        requirements = _MOVE_GUARDS.get((room_key, target, direction), ())
        requirement_text = ""
        if requirements:
            labels = tuple(
                _REQUIREMENT_LABELS.get(item, _ITEM_LABELS.get(item, item)) for item in requirements
            )
            requirement_text = " Требуется: " + ", ".join(labels) + "."
        options.append(
            ZorkOption(
                f"move:{index}",
                f"Идти {_direction_label(direction)}",
                f"Следующий узел: {target_label}.{requirement_text}",
            )
        )
    return options


def _state(
    *,
    location: str,
    inventory: frozenset[str],
    facts: frozenset[str],
    history: tuple[str, ...],
    turn: int,
    score: int,
    text: str | None = None,
    finished: bool = False,
    outcome: str = "in_progress",
    last_ok: bool = True,
    last_message: str = "",
) -> ZorkSession:
    if finished:
        options: tuple[ZorkOption, ...] = ()
    else:
        options = tuple(_context_options(location, inventory, facts) + _movement_options(location))
    return ZorkSession(
        quest_id=ZORK_QUEST_ID,
        title=ZORK_TITLE,
        location=location,
        location_label=_room_label(location),
        prompt=_prompt(location),
        text=text or _room_text(location, inventory, facts),
        options=options,
        inventory=inventory,
        facts=facts,
        history=history,
        turn=turn,
        score=score,
        finished=finished,
        outcome=outcome,
        last_ok=last_ok,
        last_message=last_message,
    )


def start_zork() -> ZorkSession:
    """Start the new content layer at the graph's original start node."""

    inventory = frozenset(("student_ticket",))
    return _state(
        location=ZORK_START_ROOM,
        inventory=inventory,
        facts=frozenset(),
        history=(),
        turn=0,
        score=0,
        last_message="ЗОРК.EXE запущен.",
    )


def _invalid_choice(state: ZorkSession, message: str) -> ZorkSession:
    return replace(state, last_ok=False, last_message=message)


def _action_state(state: ZorkSession, choice: str) -> ZorkSession | None:
    inventory = state.inventory
    facts = state.facts
    score = state.score
    text = None
    if choice == "look":
        return replace(state, last_ok=True, last_message="Описание обновлено.")
    if choice == "check_ticket" or choice == "show_ticket":
        facts = facts | frozenset(("ticket_checked",))
        score += 1
        text = "Билет настоящий: первый курс, Матмех. Турникет неохотно признаёт, что это уже достаточная квалификация."
    elif choice == "take_floppy":
        inventory = inventory | frozenset(("floppy",))
        score += 1
        text = "Дискета в кармане. На наклейке написано: «расписание — это тоже граф, просто с дедлайнами»."
    elif choice == "take_chalk":
        inventory = inventory | frozenset(("chalk",))
        score += 1
        text = "Мел ломается ещё раз, но пригоден. В подземелье появляется первый честный ориентир."
    elif choice == "mark_wall":
        facts = facts | frozenset(("wall_marked",))
        score += 1
        text = "Белая стрелка связывает этот сектор с твоим маршрутом. Теперь возвращение не требует памяти наизусть."
    elif choice == "scan_ticket":
        facts = facts | frozenset(("ticket_scanned",))
        score += 1
        text = "Пульт читает билет. В строке допуска появляется: «студент обнаружен, цель не определена»."
    elif choice == "inspect_terminal":
        facts = facts | frozenset(("terminal_seen",))
        text = "Пульт принимает только дискету и подтверждённый билет. Остальные кнопки заклеены запиской «не ускорять»."
    elif choice == "insert_floppy":
        if "floppy" not in inventory or "ticket_scanned" not in facts:
            return _invalid_choice(state, "Пульт ждёт и дискету, и подтверждённый билет.")
        return _state(
            location=state.location,
            inventory=inventory,
            facts=facts | frozenset(("program_started",)),
            history=(*state.history, choice),
            turn=state.turn + 1,
            score=score + 5,
            text=(
                "ПОДЗЕМЕЛЬЯ МАТМЕХА\n\n"
                "Граф принят. Десятки старых маршрутов сходятся в одной простой "
                "мысли: выход существует, но его приходится проверить самому.\n\n"
                "ЗОРК.EXE завершён без потери билета и расписания."
            ),
            finished=True,
            outcome="success",
            last_message="Программа завершена: маршрут доказан возвращением.",
        )
    else:
        return None
    return _state(
        location=state.location,
        inventory=inventory,
        facts=facts,
        history=(*state.history, choice),
        turn=state.turn + 1,
        score=score,
        text=text,
        last_message="Команда выполнена.",
    )


def _move_state(state: ZorkSession, choice: str) -> ZorkSession | None:
    if not choice.startswith("move:"):
        return None
    try:
        edge_index = int(choice.removeprefix("move:"))
    except ValueError:
        return _invalid_choice(state, "Номер перехода повреждён.")
    exits = outgoing_exits(state.location)
    if not 0 <= edge_index < len(exits):
        return _invalid_choice(state, "Такого перехода нет в текущем узле графа.")
    target, direction = exits[edge_index]
    requirements = _MOVE_GUARDS.get((state.location, target, direction), ())
    missing = tuple(
        item for item in requirements if item not in state.inventory and item not in state.facts
    )
    if missing:
        labels = tuple(
            _REQUIREMENT_LABELS.get(item, _ITEM_LABELS.get(item, item)) for item in missing
        )
        return _invalid_choice(
            state,
            "Переход закрыт. Сначала подготовь: " + ", ".join(labels) + ".",
        )
    if target in {"NoExit", "!"}:
        return _state(
            location=state.location,
            inventory=state.inventory,
            facts=state.facts,
            history=(*state.history, choice),
            turn=state.turn + 1,
            score=state.score,
            text=(
                f"Переход {_direction_label(direction)} заканчивается у закрытой "
                "границы графа. Это не ошибка маршрута: здесь просто нет следующего узла."
            ),
            last_message="Тупик. Можно выбрать другой переход.",
        )
    return _state(
        location=target,
        inventory=state.inventory,
        facts=state.facts,
        history=(*state.history, choice),
        turn=state.turn + 1,
        score=state.score,
        last_message=f"Переход {_direction_label(direction)} выполнен.",
    )


def play_zork_step(state: ZorkSession, choice: str) -> ZorkSession:
    """Apply one command using only an edge from the imported graph."""

    if state.finished:
        return state
    next_state = _action_state(state, choice)
    if next_state is not None:
        return next_state
    next_state = _move_state(state, choice)
    if next_state is not None:
        return next_state
    return _invalid_choice(state, "Эта команда недоступна в текущем секторе.")


__all__ = [
    "ZORK_QUEST_ID",
    "ZORK_START_ROOM",
    "ZORK_TITLE",
    "ZorkOption",
    "ZorkSession",
    "play_zork_step",
    "start_zork",
]
