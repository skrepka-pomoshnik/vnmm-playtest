"""Public ZORK.EXE topology API and traversal index."""

from types import MappingProxyType

from .exits import ZORK_EXITS
from .rooms import ZORK_ROOM_KEYS

ZORK_ROOM_COUNT = len(ZORK_ROOM_KEYS)
ZORK_EXIT_COUNT = len(ZORK_EXITS)

_OUTGOING = {}
for _source, _target, _direction in ZORK_EXITS:
    _OUTGOING.setdefault(_source, []).append((_target, _direction))

ZORK_OUTGOING = MappingProxyType({key: tuple(value) for key, value in _OUTGOING.items()})


def outgoing_exits(room_key):
    """Return the original graph's exits in source-file order."""

    return ZORK_OUTGOING.get(room_key, ())


__all__ = [
    "ZORK_EXITS",
    "ZORK_EXIT_COUNT",
    "ZORK_OUTGOING",
    "ZORK_ROOM_COUNT",
    "ZORK_ROOM_KEYS",
    "outgoing_exits",
]
