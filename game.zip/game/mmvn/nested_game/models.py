"""Immutable models shared by authored computer-class quests."""

from __future__ import annotations

from dataclasses import dataclass

from ..semantic_ids import quest_node_semantic_id


@dataclass(frozen=True)
class TextQuestOption:
    """Player-facing projection of one immutable quest choice."""

    command: str
    label: str
    description: str
    available: bool = True
    blocked_reason: str = ""


@dataclass(frozen=True)
class TextQuestState:
    """Immutable state for one DOS text quest."""

    quest_id: str
    title: str
    node_id: str
    step: int
    text: str
    options: tuple[TextQuestOption, ...]
    score: int = 0
    finished: bool = False
    outcome: str = "in_progress"
    facts: frozenset[str] = frozenset()
    history: tuple[str, ...] = ()
    last_ok: bool = True
    last_message: str = ""

    @property
    def semantic_id(self) -> str:
        """Stable node ID for authored DOS-quest traces and replay tools."""

        return quest_node_semantic_id(self.quest_id, self.node_id, namespace="quest.dos")


@dataclass(frozen=True)
class _QuestChoice:
    command: str
    label: str
    description: str
    target: str
    score_delta: int = 0
    facts: tuple[str, ...] = ()
    requires: tuple[str, ...] = ()


@dataclass(frozen=True)
class _QuestNode:
    text: str
    choices: tuple[_QuestChoice, ...] = ()
    outcome: str | None = None


def _choice(
    command: str,
    label: str,
    description: str,
    target: str,
    score_delta: int = 0,
    facts: tuple[str, ...] = (),
    requires: tuple[str, ...] = (),
) -> _QuestChoice:
    return _QuestChoice(command, label, description, target, score_delta, facts, requires)


def _node(text: str, *choices: _QuestChoice, outcome: str | None = None) -> _QuestNode:
    return _QuestNode(text, tuple(choices), outcome)
