"""Embedded activity boundaries for the computer-class menu.

The original MMHEROES port and the authored student-software quests are
separate packages/modules. This facade exposes only the latter's stable API
to the main gameplay kernel.
"""

from .engine import play_text_quest_step, start_text_quest
from .models import TextQuestOption, TextQuestState

__all__ = ["TextQuestOption", "TextQuestState", "play_text_quest_step", "start_text_quest"]
