"""State transitions for authored computer-class text quests."""

from __future__ import annotations

from dataclasses import replace

from .models import TextQuestOption, TextQuestState, _QuestNode
from .quests import _QUESTS

_REQUIREMENT_LABELS = {
    "board_seen": "осмотреть стенд с расписанием",
    "schedule_seen": "сверить текущее расписание",
    "ticket_paid": "получить билет",
    "machine_seen": "осмотреть застрявший автомат",
    "cashier_checked": "проверить билет у кассира",
    "validated": "проверить перфорацию и номер заказа",
    "platform_checked": "сверить актуальную платформу",
    "helped": "помочь студентке с таким же билетом",
    "missed_train": "пережить пропущенный поезд",
    "queue_recovered": "восстановиться в очереди на следующий поезд",
    "period_measured": "записать период фигуры",
    "phase_recorded": "записать обе фазы",
    "filter_used": "проверить фильтр на шуме",
    "trick_seen": "проверить TRICK.PAS",
    "manual_read": "прочитать инструкцию STOPPER",
    "claim_reviewed": "проверить формулировку обещания",
    "sample_inspected": "разобрать граничный образец",
    "scope_written": "указать границу применимости",
    "readme_written": "записать вывод в README",
    "counterexample_seen": "найти контрпример",
    "counterexample_classified": "классифицировать контрпример",
    "well_defined": "исправить определение",
    "base_checked": "проверить базовый случай",
}


def _missing_requirements(choice, facts: frozenset[str]) -> tuple[str, ...]:
    return tuple(fact for fact in choice.requires if fact not in facts)


def _requirement_text(missing: tuple[str, ...]) -> str:
    labels = tuple(_REQUIREMENT_LABELS.get(fact, fact) for fact in missing)
    return "Сначала: " + ", ".join(labels) + "."


def _state_at(
    quest_id: str,
    title: str,
    nodes: dict[str, _QuestNode],
    node_id: str,
    step: int,
    score: int,
    facts: frozenset[str],
    history: tuple[str, ...],
    last_ok: bool = True,
    last_message: str = "",
) -> TextQuestState:
    node = nodes.get(node_id)
    if node is None:
        return TextQuestState(
            quest_id=quest_id,
            title=title,
            node_id=node_id,
            step=step,
            text="ОШИБКА КАТАЛОГА: узел квеста не найден.",
            options=(),
            score=score,
            finished=True,
            outcome="hard_fail",
            facts=facts,
            history=history,
            last_ok=False,
            last_message="Внутренний переход указывает на отсутствующий узел.",
        )
    return TextQuestState(
        quest_id=quest_id,
        title=title,
        node_id=node_id,
        step=step,
        text=node.text,
        options=tuple(
            TextQuestOption(
                choice.command,
                choice.label,
                choice.description,
                available=not _missing_requirements(choice, facts),
                blocked_reason=_requirement_text(_missing_requirements(choice, facts))
                if _missing_requirements(choice, facts)
                else "",
            )
            for choice in node.choices
        ),
        score=score,
        finished=node.outcome is not None,
        outcome=node.outcome or "in_progress",
        facts=facts,
        history=history,
        last_ok=last_ok,
        last_message=last_message,
    )


def start_text_quest(quest_id: str) -> TextQuestState:
    """Start one of the authored computer-class test quests."""

    quest = _QUESTS.get(quest_id)
    if quest is None:
        return TextQuestState(
            quest_id=quest_id,
            title=f"{quest_id.upper()}.EXE",
            node_id="missing",
            step=0,
            text="Программа не зарегистрирована в каталоге студенческого софта.",
            options=(),
            finished=True,
            outcome="hard_fail",
            last_ok=False,
            last_message="Неизвестный идентификатор квеста.",
        )
    title, nodes = quest
    return _state_at(quest_id, title, nodes, "start", 0, 0, frozenset(), ())


def play_text_quest_step(state: TextQuestState, choice: str) -> TextQuestState:
    """Apply one visible choice and return a new immutable quest state."""

    if state.finished:
        return state
    quest = _QUESTS.get(state.quest_id)
    if quest is None:
        return replace(
            state,
            finished=True,
            outcome="hard_fail",
            last_ok=False,
            last_message="Каталог квестов изменился во время запуска.",
        )
    _title, nodes = quest
    node = nodes.get(state.node_id)
    if node is None:
        return replace(
            state,
            finished=True,
            outcome="hard_fail",
            last_ok=False,
            last_message="Текущий узел квеста больше не существует.",
        )
    selected = next((item for item in node.choices if item.command == choice), None)
    if selected is None:
        return replace(
            state,
            last_ok=False,
            last_message="Терминал не принимает такой выбор в этом узле.",
        )
    missing = _missing_requirements(selected, state.facts)
    if missing:
        return replace(
            state,
            last_ok=False,
            last_message=_requirement_text(missing),
        )
    return _state_at(
        state.quest_id,
        quest[0],
        nodes,
        selected.target,
        state.step + 1,
        state.score + selected.score_delta,
        state.facts | frozenset(selected.facts),
        (*state.history, selected.command),
        last_message=f"Выбор принят: {selected.label}",
    )
