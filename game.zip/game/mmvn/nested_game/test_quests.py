"""Compatibility import for the authored student-software quest catalog."""

from .quests import _QUESTS

__all__ = ["_QUESTS"]
