"""Independently editable authored student-software quest graphs."""

from .life import _life_quest
from .proofchk import _proofchk_quest
from .stopper import _stopper_quest
from .ticket import _ticket_quest

_QUESTS = {
    "ticket": _ticket_quest(),
    "life": _life_quest(),
    "stopper": _stopper_quest(),
    "proofchk": _proofchk_quest(),
}

__all__ = ["_QUESTS"]
