"""Canonical continuous-clock durations and authored short-event budgets."""

from __future__ import annotations

from dataclasses import dataclass

from ..balance import MODERN_BALANCE, BalanceProfile, resolve_balance_profile

DAY_MINUTES = 24 * 60
SLOT_HOURS = (8, 11, 15, 19)
SLOT_LABELS = tuple(f"{hour:02d}:00" for hour in SLOT_HOURS)
SLOT_START_MINUTES = tuple(hour * 60 for hour in SLOT_HOURS)
SLOT_DURATION_MINUTES = MODERN_BALANCE.duration.window_minutes


@dataclass(frozen=True)
class TimeBudget:
    """A visible time cost for a free-form scene or an optional event."""

    minutes: int
    display: str
    category: str = "dialogue"

    def __post_init__(self) -> None:
        if self.minutes < 0:
            raise ValueError("time budget must not be negative")
        if not self.display:
            raise ValueError("time budget must have a display label")


DEFAULT_DIALOGUE_TIME_MINUTES = MODERN_BALANCE.duration.default_dialogue_minutes
MAX_DIALOGUE_TIME_MINUTES = MODERN_BALANCE.duration.max_dialogue_minutes
MAX_AMBIENT_TIME_MINUTES = MODERN_BALANCE.duration.max_ambient_minutes


def format_duration(minutes: int) -> str:
    """Format a positive duration in the compact Russian UI vocabulary."""

    def minute_word(value: int) -> str:
        value %= 100
        if 11 <= value <= 14:
            return "минут"
        remainder = value % 10
        if remainder == 1:
            return "минута"
        if 2 <= remainder <= 4:
            return "минуты"
        return "минут"

    if minutes < 0:
        raise ValueError("duration must not be negative")
    if minutes == 0:
        return "0 минут"
    hours, remainder = divmod(minutes, 60)
    if hours and remainder:
        return "{} {} {}".format(
            hours,
            "час" if hours == 1 else "часа" if hours < 5 else "часов",
            f"{remainder} {minute_word(remainder)}",
        )
    if hours:
        return "{} {}".format(
            hours,
            "час" if hours == 1 else "часа" if hours < 5 else "часов",
        )
    return f"{minutes} {minute_word(minutes)}"


def window_cost_label(slot: int, profile: BalanceProfile | str | None = None) -> str:
    """Describe a legacy day-band boundary for old planner fixtures.

    This helper is retained for old screens and tests only.  It does not
    describe the cost of an action; reducers use exact minute knobs.
    """

    selected = resolve_balance_profile(profile)
    if not 0 <= slot < len(selected.duration.window_minutes):
        raise ValueError("slot must be a valid daily window")
    if selected.calendar_mode == "hourly":
        return "до следующего часа · 1 час"
    next_slot = (slot + 1) % len(selected.duration.window_minutes)
    if slot == len(selected.duration.window_minutes) - 1:
        return "до 08:00 · ночь"
    return (
        f"до {SLOT_LABELS[next_slot]} · {format_duration(selected.duration.window_minutes[slot])}"
    )


def absolute_minutes(
    day: int,
    slot: int,
    profile: BalanceProfile | str | None = None,
    minute_offset: int = 0,
) -> int:
    """Return a monotonic minute position for a legacy position tuple.

    ``slot`` now only supplies the starting hour when an old caller has not
    migrated to an explicit clock.  The profile's window lengths are never
    used to advance or measure gameplay time.
    """

    # Resolve the profile to keep the public API and validation behavior
    # stable, although continuous time is intentionally profile-independent.
    resolve_balance_profile(profile)
    if day < 1:
        raise ValueError("day must be positive")
    if not 0 <= slot < len(SLOT_HOURS):
        raise ValueError("slot must be a valid daily window")
    if minute_offset < 0:
        raise ValueError("minute offset must not be negative")
    hour, minute = divmod(SLOT_HOURS[slot] * 60 + minute_offset, 60)
    day_delta, hour = divmod(hour, 24)
    return (day - 1 + day_delta) * DAY_MINUTES + hour * 60 + minute


def state_absolute_minutes(state) -> int:
    """Return the canonical absolute minute for a ``GameState``-like value."""

    return (state.day - 1) * DAY_MINUTES + state.hour * 60 + state.minute


def elapsed_minutes(
    start_day: int,
    start_slot: int,
    end_day: int,
    end_slot: int,
    profile: BalanceProfile | str | None = None,
    start_minute_offset: int = 0,
    end_minute_offset: int = 0,
) -> int:
    """Return elapsed calendar time, rejecting rollback as a cost."""

    elapsed = absolute_minutes(
        end_day,
        end_slot,
        profile,
        end_minute_offset,
    ) - absolute_minutes(
        start_day,
        start_slot,
        profile,
        start_minute_offset,
    )
    if elapsed < 0:
        raise ValueError("end time must not precede start time")
    return elapsed


def _budget(minutes: int, display: str | None = None, category: str = "dialogue") -> TimeBudget:
    return TimeBudget(minutes, display or format_duration(minutes), category)


# Explicitly authored exceptions live here instead of being hidden in story
# labels. Ordinary scene choices use the short-dialogue default below.
def _budget_for_knob(knob) -> TimeBudget | None:
    if knob is None or knob.minutes == 0:
        return None
    return _budget(knob.minutes, knob.display, knob.category)


def action_time_budgets(profile: BalanceProfile | str | None = None) -> dict[str, TimeBudget]:
    """Build the visible action-budget view for one immutable profile."""

    selected = resolve_balance_profile(profile)
    return {
        knob.key: budget
        for knob in selected.duration.action_knobs
        if (budget := _budget_for_knob(knob)) is not None
    }


# Backward-compatible modern view. New callers should pass a profile to
# ``action_time_budget`` or use ``action_time_budgets`` directly.
ACTION_TIME_BUDGETS = action_time_budgets()


def preview_action(
    action_key: str | None,
    start_day: int,
    start_slot: int,
    end_day: int | None = None,
    end_slot: int | None = None,
    profile: BalanceProfile | str | None = None,
    *,
    start_minute_offset: int = 0,
    end_minute_offset: int = 0,
    start_hour: int | None = None,
    end_hour: int | None = None,
    origin: str | None = None,
    destination: str | None = None,
) -> TimeBudget | None:
    """Resolve the exact visible cost before applying an action.

    The optional route endpoints make travel previews use the same direct
    minute table as the travel reducer. A profile may intentionally define a
    zero-minute local walk (the classic mode); that is represented by ``None``
    rather than by a misleading positive fallback duration.
    """

    if (origin is None) != (destination is None):
        raise ValueError("origin and destination must be provided together")

    selected = resolve_balance_profile(profile)

    if origin is not None and destination is not None:
        route_minutes = selected.duration.travel_duration(origin, destination)
        if route_minutes is not None:
            if route_minutes == 0:
                return None
            return _budget(route_minutes, category="elapsed")

    explicit_knob = selected.duration.action(action_key)
    explicit = _budget_for_knob(explicit_knob)
    if end_day is not None and end_slot is not None:
        if start_hour is not None and end_hour is not None:
            elapsed = (
                ((end_day - start_day) * 24 + end_hour - start_hour) * 60
                + end_minute_offset
                - start_minute_offset
            )
            if elapsed < 0:
                raise ValueError("end time must not precede start time")
        else:
            elapsed = elapsed_minutes(
                start_day,
                start_slot,
                end_day,
                end_slot,
                selected,
                start_minute_offset,
                end_minute_offset,
            )
        if elapsed:
            if explicit is not None and explicit.category in {"social", "overnight"}:
                return explicit
            return _budget(elapsed, category="elapsed")
        # A zero-length transition has no visible time cost for movement, but
        # an authored scene still needs its named budget when its reducer did
        # not advance the state itself.
        if elapsed == 0:
            if action_key and action_key.startswith(("scene:", "distraction:")):
                # A reducer that only changes flags/stats still represents a
                # real short conversation.  Keep its named duration when it
                # has one, otherwise use the profile default instead of
                # accidentally making the scene free.
                if explicit_knob is not None and explicit_knob.minutes == 0:
                    return None
                return explicit or _budget(selected.duration.default_dialogue_minutes)
            return None
    if explicit is not None:
        return explicit
    if explicit_knob is not None:
        return None
    if action_key and action_key.startswith(("scene:", "distraction:")):
        return _budget(selected.duration.default_dialogue_minutes)
    return None


def action_time_budget(
    action_key: str | None,
    start_day: int,
    start_slot: int,
    end_day: int | None = None,
    end_slot: int | None = None,
    profile: BalanceProfile | str | None = None,
    *,
    start_minute_offset: int = 0,
    end_minute_offset: int = 0,
    start_hour: int | None = None,
    end_hour: int | None = None,
    origin: str | None = None,
    destination: str | None = None,
) -> TimeBudget | None:
    """Compatibility alias for :func:`preview_action`.

    Existing callers retain the historical name while new code can make the
    preview-vs-application contract explicit.
    """

    return preview_action(
        action_key,
        start_day,
        start_slot,
        end_day,
        end_slot,
        profile,
        start_minute_offset=start_minute_offset,
        end_minute_offset=end_minute_offset,
        start_hour=start_hour,
        end_hour=end_hour,
        origin=origin,
        destination=destination,
    )


def ordinary_budgets_are_balanced(profile: BalanceProfile | str | None = None) -> bool:
    """Keep dialogue budgets short while allowing authored evening events."""

    selected = resolve_balance_profile(profile)
    return all(
        budget.minutes <= selected.duration.max_dialogue_minutes
        for budget in action_time_budgets(selected).values()
        if budget.category == "dialogue"
    )


def calendar_day_number(day: int) -> int:
    """Canonical day number in May 1998 (week runs May 25 to May 30)."""
    return day + 24


def calendar_date_string(day: int, format_type: str = "full") -> str:
    """Canonical formatted date string for visible presentation."""
    day_num = calendar_day_number(day)
    weekdays = ("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
    weekday = weekdays[day - 1] if 1 <= day <= len(weekdays) else f"День {day}"
    if format_type == "short":
        return f"{day_num:02d}.05"
    if format_type == "header":
        return f"{day_num}.05 · {weekday}"
    return f"{day_num} мая · {weekday}"


# Канонические временные затраты на передвижение (0.3-C: временная метрика).
TRAVEL_TIME_MINUTES = MODERN_BALANCE.duration.travel_duration_map()

__all__ = [
    "ACTION_TIME_BUDGETS",
    "DAY_MINUTES",
    "DEFAULT_DIALOGUE_TIME_MINUTES",
    "MAX_AMBIENT_TIME_MINUTES",
    "MAX_DIALOGUE_TIME_MINUTES",
    "SLOT_DURATION_MINUTES",
    "SLOT_HOURS",
    "SLOT_LABELS",
    "TRAVEL_TIME_MINUTES",
    "TimeBudget",
    "absolute_minutes",
    "action_time_budget",
    "action_time_budgets",
    "calendar_date_string",
    "calendar_day_number",
    "elapsed_minutes",
    "format_duration",
    "ordinary_budgets_are_balanced",
    "preview_action",
    "state_absolute_minutes",
    "window_cost_label",
]
