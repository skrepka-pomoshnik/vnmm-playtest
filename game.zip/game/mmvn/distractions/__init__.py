"""Optional side distractions with explicit time and resource trade-offs."""

from dataclasses import replace

from ..balance import BalanceProfile, resolve_balance_profile
from ..constants import TRAVEL_MISHAP_FLAGS, RandomSource
from ..models import GameState
from ..rules.helpers_state import _change_stats, _change_trust, _fail, _ok
from ..rules.helpers_time import _advance_action
from ..rules.types import ActionResult
from ..social_events import (
    SOCIAL_EVENT_LABELS,
    SOCIAL_EVENT_LOCATIONS,
    SOCIAL_EVENTS,
    social_event_available_at,
    social_event_for,
)


def _mark_and_advance(
    state: GameState,
    flag: str,
    action_key: str,
    profile: BalanceProfile | str | None,
) -> GameState:
    selected = resolve_balance_profile(profile)
    return _advance_action(state, action_key, selected).with_flag(flag)


def resolve_distraction(
    state: GameState,
    distraction: str,
    choice: str,
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Resolve one optional side event without touching the narrative layer."""

    if distraction == "dorm_fee":
        if state.location != "dorm" or state.day != 2 or state.slot != 0:
            return _fail(state, "Комендантская квитанция сейчас не лежит на столе.")
        if state.has_flag("dorm_fee_seen"):
            return _fail(state, "С квитанцией уже разобрались.")
        if choice == "resolve":
            next_state = _mark_and_advance(
                state,
                "dorm_fee_seen",
                "distraction:dorm_fee:resolve",
                profile,
            ).with_flag("dorm_fee_resolved")
            return _ok(
                next_state,
                "Квитанцию приняли после короткого разговора.",
            )
        if choice == "pay":
            if state.money < 8:
                return _fail(state, "Для оплаты квитанции не хватает 8 рублей.")
            next_state = _mark_and_advance(
                state,
                "dorm_fee_seen",
                "distraction:dorm_fee:pay",
                profile,
            ).with_flag("dorm_fee_paid")
            next_state = _change_stats(next_state, money=-8)
            return _ok(next_state, "Квитанцию оплатили: −8 ₽.")
        if choice == "defer":
            # RV-H8: вариант «вернуться позже» получил собственную дешёвую
            # семантику: тема закрывается без потери окна и без оплаты.
            # Раньше эта кнопка выполняла тот же resolve, что и оплата.
            next_state = state.with_flag("dorm_fee_seen").with_flag("dorm_fee_deferred")
            return _ok(
                next_state,
                "Квитанцию отложили в ящик стола. Комендантша запомнит.",
            )
        return _fail(state, "Неизвестный ответ коменданту.")

    if distraction == "freshman_linear_algebra":
        if state.location != "faculty" or state.day != 3 or state.slot != 1:
            return _fail(state, "Первокурсница сейчас не ищет объяснение в этом коридоре.")
        if state.has_flag("freshman_encounter_seen"):
            return _fail(state, "Разговор с первокурсницей уже начался.")
        if choice == "explain":
            next_state = _mark_and_advance(
                state,
                "freshman_encounter_seen",
                "distraction:freshman_linear_algebra:explain",
                profile,
            ).with_flag("freshman_helped")
            next_state = _change_trust(next_state, "freshman", 1)
            return _ok(next_state, "Линал занял одно окно. Объяснение получилось понятным.")
        if choice == "leave":
            return _ok(
                _mark_and_advance(
                    state,
                    "freshman_encounter_seen",
                    "distraction:freshman_linear_algebra:leave",
                    profile,
                ),
                "Первокурсница записала номер страницы и осталась с задачей.",
            )
        return _fail(state, "Неизвестный ответ первокурснице.")

    if distraction == "freshman_tea":
        if not state.has_flag("freshman_helped"):
            return _fail(state, "Сначала нужно объяснить линейную алгебру.")
        if state.has_flag("freshman_romance"):
            return _fail(state, "После чая уже есть о чём вспомнить.")
        if choice != "tea":
            return _fail(state, "Неизвестное продолжение разговора.")
        if state.location != "faculty" or state.money < 2:
            return _fail(state, "Для чая нужны место в коридоре и 2 рубля.")
        next_state = _mark_and_advance(
            state,
            "freshman_followup_seen",
            "distraction:freshman_tea:tea",
            profile,
        )
        next_state = _change_stats(next_state, money=-2)
        # There is no separate mood resource in the domain model.  A kind
        # conversation restores a small amount of the existing stamina pool.
        next_state = _change_stats(next_state, stamina=1)
        next_state = _change_trust(next_state, "freshman", 1)
        return _ok(
            next_state.with_flag("freshman_romance").with_flag("freshman_cheered_up"),
            "Чай занял ещё одно окно и 2 ₽. Разговор вернул немного настроя: +1 выносливость.",
        )

    if distraction in {"freshman_notes", "freshman_later"}:
        if not state.has_flag("freshman_helped"):
            return _fail(state, "Сначала нужно объяснить линейную алгебру.")
        if state.location != "faculty":
            return _fail(state, "Лена ищет свободную доску на факультете.")
        if state.has_flag("freshman_followup_seen"):
            return _fail(state, "После первого продолжения уже поздно выбирать другой вариант.")

        if distraction == "freshman_notes":
            if choice != "compare":
                return _fail(state, "Неизвестный способ продолжить разговор.")
            next_state = _mark_and_advance(
                state,
                "freshman_followup_seen",
                "distraction:freshman_notes:compare",
                profile,
            ).with_flag("freshman_notes_shared")
            return _ok(
                next_state.with_flag("freshman_romance"),
                "Сверка конспектов заняла полчаса и открыла отдельную линию разговора.",
            )

        if choice != "promise":
            return _fail(state, "Неизвестный способ продолжить разговор.")
        next_state = _mark_and_advance(
            state,
            "freshman_followup_seen",
            "distraction:freshman_later:promise",
            profile,
        ).with_flag("freshman_later_promised")
        return _ok(
            next_state.with_flag("freshman_romance"),
            "Вы договорились вернуться к разговору позже: 5 минут и обещание, которое придётся помнить.",
        )

    if distraction == "freshman_callback":
        if not state.has_flag("freshman_romance"):
            return _fail(state, "Лена пока не ждёт продолжения этого разговора.")
        if state.location != "faculty" or state.day < 4:
            return _fail(state, "Для этой встречи ещё не наступил подходящий день.")
        if state.has_flag("freshman_romance_callback_seen") or state.has_flag(
            "freshman_callback_choice_seen"
        ):
            return _fail(state, "Этот разговор уже получил продолжение.")

        callback_actions = {
            "walk": ("distraction:freshman_callback:walk", "freshman_callback_walked"),
            "study": ("distraction:freshman_callback:study", "freshman_callback_studied"),
            "honest": ("distraction:freshman_callback:honest", "freshman_callback_honest"),
        }
        action = callback_actions.get(choice)
        if action is None:
            return _fail(state, "Неизвестное продолжение встречи.")
        action_key, outcome_flag = action
        next_state = _mark_and_advance(
            state,
            "freshman_callback_choice_seen",
            action_key,
            profile,
        ).with_flag(outcome_flag)
        return _ok(next_state, "Продолжение разговора заняло своё место в расписании.")

    if distraction == "lost_student_room_09":
        if state.location != "faculty" or not 2 <= state.day <= 5:
            return _fail(state, "Потерявшийся студент сейчас не ищет девятую аудиторию здесь.")
        if state.has_flag("lost_student_room_09_seen"):
            return _fail(state, "Маршрут до аудитории 09 уже разобрали.")
        if choice == "lead":
            next_state = _mark_and_advance(
                state,
                "lost_student_room_09_seen",
                "distraction:lost_student_room_09:lead",
                profile,
            )
            next_state = replace(next_state, group_score=next_state.group_score + 1)
            return _ok(
                next_state.with_flag("lost_student_room_09_helped"),
                "Дверь 09 нашли вместе: 15 минут и +1 к общему делу.",
            )
        if choice == "directions":
            next_state = _mark_and_advance(
                state,
                "lost_student_room_09_seen",
                "distraction:lost_student_room_09:directions",
                profile,
            )
            return _ok(
                next_state.with_flag("lost_student_room_09_directions"),
                "Маршрут по схеме занял 5 минут. Студент записал повороты.",
            )
        if choice == "leave":
            return _ok(
                _mark_and_advance(
                    state,
                    "lost_student_room_09_seen",
                    "distraction:lost_student_room_09:leave",
                    profile,
                ).with_flag("lost_student_room_09_declined"),
                "Студент снова пошёл к лестнице. Это заняло 5 минут.",
            )
        return _fail(state, "Неизвестный ответ потерявшемуся студенту.")

    if distraction == "preference":
        if state.location != "dorm" or state.slot != 3:
            return _fail(state, "Преферансисты собираются после семи в общаге.")
        if state.has_flag("preference_seen"):
            return _fail(state, "Эта партия уже закончилась.")
        if choice == "leave":
            return _ok(
                _mark_and_advance(
                    state,
                    "preference_seen",
                    "distraction:preference:leave",
                    profile,
                ),
                "Герой оставил компанию до раздачи.",
            )
        if choice != "play":
            return _fail(state, "Неизвестный ответ преферансистам.")
        if rng is None:
            return _fail(state, "Для партии нужен явный бросок карт.")

        roll = rng.randint(1, 100)
        next_state = (
            replace(
                _advance_action(
                    state,
                    "distraction:preference:play",
                    resolve_balance_profile(profile),
                ),
                sleep_debt=True,
            )
            .with_flag("preference_seen")
            .with_flag("preference_played")
        )
        if roll <= 40:
            loss = min(10, state.money)
            next_state = _change_stats(next_state, money=-loss)
            if loss < 10:
                next_state = next_state.with_debt("preference")
            return _ok(
                next_state,
                f"Партия закончилась под утро: −{loss} ₽ и долг, если денег не хватило.",
            )
        if roll <= 70:
            return _ok(next_state, "Партия закончилась под утро. Деньги остались при своих.")

        return _ok(
            _change_stats(next_state, money=15),
            "Партия закончилась под утро. Герой выиграл 15 ₽.",
        )

    return _fail(state, "Неизвестное отвлечение.")


__all__ = ["resolve_distraction"]


__all__ = [
    "SOCIAL_EVENTS",
    "SOCIAL_EVENT_LABELS",
    "SOCIAL_EVENT_LOCATIONS",
    "social_event_available_at",
    "social_event_for",
]


# --- Travel mishaps (merged from travel_mishaps.py) ---
"""Small, optional transport mishaps that only consume extra time."""


def maybe_return_trip_mishap(
    before: GameState,
    after: GameState,
    origin: str,
    destination: str,
    rng: RandomSource,
) -> str | None:
    """Choose at most one once-per-run mishap after a successful POMI return."""

    if origin != "pomi" or destination not in {"dorm", "faculty"}:
        return None
    if before.location != "pomi" or after.location != destination:
        return None
    if before.day >= 6 or after.day >= 6:
        return None
    if after.has_flag("final_scene_seen"):
        return None

    if not after.has_flag(
        TRAVEL_MISHAP_FLAGS["martyshkino"]
    ) and rng.random() < return_trip_mishap_probability(before):
        return "martyshkino"

    if not after.has_flag(TRAVEL_MISHAP_FLAGS["remiz"]) and rng.random() < 0.06:
        return "remiz"

    if not after.has_flag(TRAVEL_MISHAP_FLAGS["dogs"]) and rng.random() < 0.08:
        return "dogs"

    return None


def return_trip_mishap_probability(state: GameState) -> float:
    """Return the fatigue-sensitive chance of missing the POMI return stop."""

    probability = 0.04
    if state.sleep_debt:
        probability += 0.15
    if state.health < 30:
        probability += 0.07
    if state.stamina <= 2:
        probability += 0.06
    return min(probability, 0.30)


__all__ = ["maybe_return_trip_mishap", "return_trip_mishap_probability"]
