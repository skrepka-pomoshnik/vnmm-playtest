"""Small, deterministic model of the modern optional-event pressure layer.

The Ren'Py adapter owns the authored prose and scene routing.  This module is
the balance lab's deliberately small numeric counterpart: it lets a seeded
simulation measure how much the random encounters help or hurt a run without
launching the engine or silently changing the story rules.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from mmvn.constants import RandomSource
from mmvn.models import GameState, SubjectProgress

from .profiles import BalanceProfile


@dataclass(frozen=True)
class BalanceRandomEvent:
    """One balance-facing encounter category, not a Ren'Py scene label."""

    event_id: str
    title: str
    positive: bool

    def weight(self, profile: BalanceProfile) -> int:
        return (
            profile.random_event_positive_weight
            if self.positive
            else profile.random_event_negative_weight
        )


@dataclass(frozen=True)
class RandomEventResolution:
    """The immutable effect and accounting data for one selected event."""

    state: GameState
    event_id: str
    title: str
    positive: bool
    health_delta: int = 0
    money_delta: int = 0
    knowledge_delta: int = 0
    task_delta: int = 0


MODERN_RANDOM_EVENTS = (
    BalanceRandomEvent("pasha_hint", "Паша поделился рабочей подсказкой", True),
    BalanceRandomEvent("freshman_help", "Первокурсник подсказал один шаг", True),
    BalanceRandomEvent("sasha_note", "Саша оставила полезную заметку", True),
    BalanceRandomEvent("serge_recovery", "Серж помог перевести дух", True),
    BalanceRandomEvent("train_delay", "Электричка задержалась", False),
    BalanceRandomEvent("printer_jam", "Принтер съел важный лист", False),
)


def _unfinished(state: GameState) -> tuple[SubjectProgress, ...]:
    return tuple(progress for progress in state.subjects if not progress.passed)


def _least_prepared(state: GameState) -> SubjectProgress | None:
    candidates = _unfinished(state)
    return (
        min(candidates, key=lambda item: (item.knowledge, item.tasks_done, item.subject))
        if candidates
        else None
    )


def _least_finished(state: GameState) -> SubjectProgress | None:
    candidates = _unfinished(state)
    return (
        min(candidates, key=lambda item: (item.tasks_done, item.knowledge, item.subject))
        if candidates
        else None
    )


def _available_events(state: GameState, profile: BalanceProfile) -> tuple[BalanceRandomEvent, ...]:
    if profile.profile_id != "modern" or profile.random_event_trigger_percent <= 0:
        return ()
    result: list[BalanceRandomEvent] = []
    for event in MODERN_RANDOM_EVENTS:
        if state.has_flag(f"balance_event:{event.event_id}"):
            continue
        if event.event_id in {"pasha_hint", "sasha_note"} and _least_prepared(state) is None:
            continue
        if event.event_id == "freshman_help" and _least_finished(state) is None:
            continue
        if event.event_id == "serge_recovery" and state.health >= 100:
            continue
        if event.event_id == "train_delay" and state.location == "dorm":
            continue
        result.append(event)
    return tuple(result)


def available_random_events(
    state: GameState,
    profile: BalanceProfile | None,
) -> tuple[BalanceRandomEvent, ...]:
    """Expose eligible modern event categories for tests and reports."""

    if profile is None:
        return ()
    return _available_events(state, profile)


def _weighted_choice(
    events: tuple[BalanceRandomEvent, ...],
    profile: BalanceProfile,
    rng: RandomSource,
) -> BalanceRandomEvent:
    weighted = tuple((event, event.weight(profile)) for event in events)
    total = sum(weight for _event, weight in weighted)
    if total <= 0:
        raise ValueError("modern random event weights must contain a positive value")
    cursor = rng.randrange(total)
    for event, weight in weighted:
        cursor -= weight
        if cursor < 0:
            return event
    return weighted[-1][0]


def _change_health(state: GameState, delta: int) -> GameState:
    return replace(state, stats=replace(state.stats, health=state.health + delta))


def _survivable_health_delta(state: GameState, delta: int) -> int:
    """Keep an optional negative encounter from being an invisible death wall."""

    if delta >= 0:
        return delta
    return -min(-delta, max(0, state.health - 1))


def _add_knowledge(state: GameState) -> tuple[GameState, int]:
    subject = _least_prepared(state)
    if subject is None:
        return state, 0
    updated = replace(subject, knowledge=subject.knowledge + 1)
    return state.with_subject(updated), 1


def _add_task(state: GameState) -> tuple[GameState, int]:
    subject = _least_finished(state)
    if subject is None:
        return state, 0
    tasks = min(subject.required_tasks, subject.tasks_done + 1)
    updated = replace(
        subject,
        tasks_done=tasks,
        passed=tasks >= subject.required_tasks,
        passed_day=state.day if tasks >= subject.required_tasks else subject.passed_day,
    )
    return state.with_subject(updated), tasks - subject.tasks_done


def _apply_event(state: GameState, event: BalanceRandomEvent) -> RandomEventResolution:
    next_state = state.with_flag(f"balance_event:{event.event_id}")
    health_delta = 0
    money_delta = 0
    knowledge_delta = 0
    task_delta = 0

    if event.event_id in {"pasha_hint", "sasha_note"}:
        next_state, knowledge_delta = _add_knowledge(next_state)
    elif event.event_id == "freshman_help":
        next_state, task_delta = _add_task(next_state)
    elif event.event_id == "serge_recovery":
        health_delta = 6
        next_state = _change_health(next_state, health_delta)
    elif event.event_id == "train_delay":
        health_delta = _survivable_health_delta(next_state, -5)
        next_state = _change_health(next_state, health_delta)
    elif event.event_id == "printer_jam":
        health_delta = _survivable_health_delta(next_state, -3)
        next_state = _change_health(next_state, health_delta)
    else:  # pragma: no cover - the catalog is closed above
        raise ValueError(f"unknown modern balance event: {event.event_id}")

    return RandomEventResolution(
        state=next_state,
        event_id=event.event_id,
        title=event.title,
        positive=event.positive,
        health_delta=health_delta,
        money_delta=money_delta,
        knowledge_delta=knowledge_delta,
        task_delta=task_delta,
    )


def resolve_modern_random_event(
    state: GameState,
    profile: BalanceProfile,
    rng: RandomSource,
) -> RandomEventResolution | None:
    """Draw and apply at most one seeded modern event at a route checkpoint."""

    events = _available_events(state, profile)
    if not events or rng.randrange(100) >= profile.random_event_trigger_percent:
        return None
    return _apply_event(state, _weighted_choice(events, profile, rng))


__all__ = (
    "MODERN_RANDOM_EVENTS",
    "BalanceRandomEvent",
    "RandomEventResolution",
    "available_random_events",
    "resolve_modern_random_event",
)
