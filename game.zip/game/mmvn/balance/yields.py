"""BALANCE-02: resource gain per 60 minutes with dominated-option detection.

Measure single actions with the real reducers and publish comparable rates,
then flag strictly dominated menu options: a pricier option with a smaller
(or equal) effect and no separate unlock or payoff is a balance bug.

This module is intentionally *not* re-exported from ``mmvn.balance``:
importing it there would cycle back through ``mmvn.rules``.
"""

from __future__ import annotations

from dataclasses import dataclass

from mmvn.models import GameState
from mmvn.time_budget import state_absolute_minutes

from .profiles.models import FoodOption

__all__ = (
    "ActionYield",
    "find_dominated_options",
    "measure_yield",
    "render_yield_table",
)


@dataclass(frozen=True)
class ActionYield:
    """Measured gain of one action, with per-60-minute rates."""

    name: str
    minutes: int
    dhp: int
    dmoney: int
    dknowledge: int
    dtasks: int

    def _rate(self, delta: int) -> float:
        if self.minutes <= 0:
            return 0.0
        return delta * 60.0 / self.minutes

    @property
    def hp_per_hour(self) -> float:
        """Return health gained per 60 minutes."""

        return self._rate(self.dhp)

    @property
    def money_per_hour(self) -> float:
        """Return money gained per 60 minutes."""

        return self._rate(self.dmoney)

    @property
    def knowledge_per_hour(self) -> float:
        """Return knowledge gained per 60 minutes."""

        return self._rate(self.dknowledge)

    @property
    def tasks_per_hour(self) -> float:
        """Return tasks gained per 60 minutes."""

        return self._rate(self.dtasks)


def measure_yield(name: str, before: GameState, after: GameState) -> ActionYield:
    """Return the measured yield between two immutable states."""

    return ActionYield(
        name=name,
        minutes=state_absolute_minutes(after) - state_absolute_minutes(before),
        dhp=after.health - before.health,
        dmoney=after.money - before.money,
        dknowledge=sum(p.knowledge for p in after.subjects)
        - sum(p.knowledge for p in before.subjects),
        dtasks=sum(p.tasks_done for p in after.subjects)
        - sum(p.tasks_done for p in before.subjects),
    )


def _dominates(candidate: FoodOption, other: FoodOption) -> bool:
    """Return whether ``candidate`` is at least as good on every axis."""

    return (
        candidate.cost <= other.cost
        and candidate.health >= other.health
        and candidate.brain >= other.brain
        and candidate.stamina >= other.stamina
        and candidate.charisma >= other.charisma
        and (
            candidate.cost < other.cost
            or candidate.health > other.health
            or candidate.brain > other.brain
            or candidate.stamina > other.stamina
            or candidate.charisma > other.charisma
        )
    )


def find_dominated_options(
    options: tuple[FoodOption, ...] | list[FoodOption],
) -> tuple[tuple[str, str], ...]:
    """Return ``(dominator, dominated)`` item id pairs within each venue.

    Only options from the same venue are comparable: the venue itself is the
    unlock, so a cross-venue price gap is never domination.
    """

    pairs: list[tuple[str, str]] = []
    venues: dict[str, list[FoodOption]] = {}
    for option in options:
        venues.setdefault(option.venue, []).append(option)
    for menu in venues.values():
        for candidate in menu:
            for other in menu:
                if candidate.item_id != other.item_id and _dominates(candidate, other):
                    pairs.append((candidate.item_id, other.item_id))
    return tuple(pairs)


def render_yield_table(yields: tuple[ActionYield, ...] | list[ActionYield]) -> str:
    """Render measured yields as a markdown table for balance reports."""

    lines = [
        "| action | min | HP/h | ₽/h | know/h | tasks/h |",
        "|---|---|---|---|---|---|",
    ]
    for entry in yields:
        lines.append(
            f"| {entry.name} | {entry.minutes} | {entry.hp_per_hour:.1f} | "
            f"{entry.money_per_hour:.1f} | {entry.knowledge_per_hour:.1f} | "
            f"{entry.tasks_per_hour:.1f} |"
        )
    return "\n".join(lines)
