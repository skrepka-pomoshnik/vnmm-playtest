"""Source-backed classic balance facts and formula adapters."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from math import floor
from types import MappingProxyType
from typing import Final, Protocol


class SourceRandom(Protocol):
    """The small random interface used by the Pascal/JS port formulas."""

    def randrange(self, stop: int, /) -> int: ...


def _source_roll(rng: SourceRandom, stop: int) -> int:
    """Match source ``R(n)`` where non-positive ``n`` returns zero."""

    return rng.randrange(stop) if stop > 0 else 0


def source_roll(rng: SourceRandom, stop: int) -> int:
    """Public adapter for the source ``R(n)`` primitive."""

    return _source_roll(rng, stop)


@dataclass(frozen=True)
class ClassicSubjectReference:
    """One ``SUBJ`` row from the local source port."""

    subject: str
    difficulty: int
    fatigue: int
    tasks: int
    divisor: int
    professor_days: int
    minimum_hours: int
    maximum_hours: int
    locations: tuple[str, ...]


CLASSIC_SOURCE_SUBJECTS: Final[tuple[ClassicSubjectReference, ...]] = (
    ClassicSubjectReference("algebra", 10, 17, 12, 3, 4, 2, 4, ("faculty", "faculty", "pomi")),
    ClassicSubjectReference("matan", 8, 14, 10, 2, 4, 2, 3, ("faculty", "faculty", "faculty")),
    ClassicSubjectReference("geometry", 4, 8, 3, 3, 2, 1, 3, ("faculty", "pomi", "pomi")),
    ClassicSubjectReference("informatics", 5, 6, 2, 3, 2, 1, 2, ("computer_lab",) * 3),
    ClassicSubjectReference("english", 7, 10, 3, 1, 2, 2, 2, ("pomi",) * 3),
    ClassicSubjectReference("pe", 7, 20, 1, 1, 2, 1, 1, ("faculty",) * 3),
)

CLASSIC_SOURCE_SUBJECT_MAP: Final[Mapping[str, ClassicSubjectReference]] = MappingProxyType(
    {item.subject: item for item in CLASSIC_SOURCE_SUBJECTS}
)


# Unlike the train, local movement in the source does not advance the hour.
# Its health penalty is attached to the ordered route, not to the destination.
CLASSIC_LOCAL_TRAVEL_HEALTH_COSTS: Final[Mapping[tuple[str, str], int]] = MappingProxyType(
    {
        ("dorm", "faculty"): 3,
        ("dorm", "mausoleum"): 3,
        ("faculty", "dorm"): 0,
        ("faculty", "computer_lab"): 2,
        ("faculty", "mausoleum"): 3,
        ("computer_lab", "dorm"): 0,
        ("computer_lab", "faculty"): 2,
        ("computer_lab", "mausoleum"): 2,
        ("mausoleum", "dorm"): 0,
        ("mausoleum", "faculty"): 3,
    }
)


def classic_local_travel_health_cost(origin: str, destination: str) -> int:
    """Return the source's HP cost for one non-POMI local move."""

    return CLASSIC_LOCAL_TRAVEL_HEALTH_COSTS.get((origin, destination), 3)


@dataclass(frozen=True)
class ClassicArchetypeReference:
    """Inclusive starting ranges selected by the original archetype menu."""

    archetype: str
    brain: tuple[int, int]
    stamina: tuple[int, int]
    charisma: tuple[int, int]


CLASSIC_SOURCE_ARCHETYPES: Final[tuple[ClassicArchetypeReference, ...]] = (
    ClassicArchetypeReference("random", (4, 6), (4, 6), (4, 6)),
    ClassicArchetypeReference("smart", (5, 9), (2, 4), (2, 4)),
    ClassicArchetypeReference("bold", (2, 4), (5, 9), (2, 4)),
    ClassicArchetypeReference("social", (2, 4), (2, 4), (5, 9)),
)


@dataclass(frozen=True)
class ClassicInitialRoll:
    """One exact source start, including per-subject initial knowledge."""

    archetype: str
    brain: int
    stamina: int
    charisma: int
    health: int
    knowledge: tuple[int, ...]


@dataclass(frozen=True)
class ClassicScheduleEntry:
    """One generated source appointment, with zero-based source day."""

    day: int
    subject: str
    start_hour: int
    end_hour: int
    location: str


def _archetype(archetype: str) -> ClassicArchetypeReference:
    for item in CLASSIC_SOURCE_ARCHETYPES:
        if item.archetype == archetype:
            return item
    raise ValueError(f"unknown classic archetype: {archetype}")


def source_initial_roll(archetype: str, rng: SourceRandom) -> ClassicInitialRoll:
    """Reproduce ``new_game``'s selected-archetype random ranges."""

    selected = _archetype(archetype)

    def roll(bounds: tuple[int, int]) -> int:
        lower, upper = bounds
        return lower + _source_roll(rng, upper - lower + 1)

    brain = roll(selected.brain)
    stamina = roll(selected.stamina)
    charisma = roll(selected.charisma)
    return ClassicInitialRoll(
        archetype=archetype,
        brain=brain,
        stamina=stamina,
        charisma=charisma,
        health=40 + _source_roll(rng, stamina * 2),
        knowledge=tuple(_source_roll(rng, brain) for _ in CLASSIC_SOURCE_SUBJECTS),
    )


def source_schedule(rng: SourceRandom) -> tuple[ClassicScheduleEntry, ...]:
    """Generate the six-day schedule exactly as the local source does."""

    entries: list[ClassicScheduleEntry] = []
    for item in CLASSIC_SOURCE_SUBJECTS:
        used_days: set[int] = set()
        for _ in range(item.professor_days):
            day = _source_roll(rng, 6)
            while day in used_days:
                day = _source_roll(rng, 6)
            used_days.add(day)
            start_hour = 9 + _source_roll(rng, 19 - item.maximum_hours - 9)
            duration = item.minimum_hours + _source_roll(
                rng, item.maximum_hours - item.minimum_hours + 1
            )
            location = item.locations[_source_roll(rng, len(item.locations))]
            entries.append(
                ClassicScheduleEntry(
                    day,
                    item.subject,
                    start_hour,
                    start_hour + duration,
                    location,
                )
            )
    return tuple(sorted(entries, key=lambda entry: (entry.day, entry.start_hour, entry.subject)))


@dataclass(frozen=True)
class SourceExamOutcome:
    """One source exam roll before the surrounding menu/router effects."""

    tasks: int
    knowledge_after: int
    health_loss: int


def source_exam_tasks(
    knowledge: int,
    health: int,
    difficulty: int,
    brain: int,
    stamina: int,
    charisma: int,
    completed_tasks: int,
    *,
    task_limit: int,
    divisor: int,
    fatigue: int,
    rng: SourceRandom,
    train: bool = False,
    geometry_knowledge: int | None = None,
    geometry_gate: bool = False,
) -> SourceExamOutcome:
    """Apply the source ``suffer`` formula once, including its oddities.

    The source's anti-overpreparedness check belongs to geometry only. The
    legacy ``geometry_knowledge`` argument is kept for callers that need to
    supply the already-updated geometry value explicitly; ``geometry_gate``
    applies the check to this action's updated knowledge.
    """

    effective_knowledge = knowledge - difficulty + _source_roll(rng, brain)
    if health <= 5:
        effective_knowledge -= _source_roll(rng, 5 - health)
    raw_tasks = floor(effective_knowledge**0.5 / divisor + 0.5) if effective_knowledge > 0 else 0
    tasks = max(0, min(raw_tasks, task_limit - completed_tasks))
    knowledge_after = max(
        0,
        knowledge + _source_roll(rng, stamina) - _source_roll(rng, difficulty),
    )
    overprepared_knowledge = geometry_knowledge
    if geometry_gate:
        overprepared_knowledge = knowledge_after
    if overprepared_knowledge is not None and charisma * 2 + 26 < overprepared_knowledge:
        tasks = 0
    health_roll_size = stamina * 2 // 3 if train else stamina
    health_loss = max(fatigue - _source_roll(rng, health_roll_size), 0)
    return SourceExamOutcome(tasks, knowledge_after, health_loss)


def _source_roll_values(stop: int) -> tuple[int, ...]:
    """Return every outcome of source ``R(stop)`` without a random draw."""

    return tuple(range(stop)) if stop > 0 else (0,)


def source_exam_task_distribution(
    knowledge: int,
    health: int,
    difficulty: int,
    brain: int,
    stamina: int,
    charisma: int,
    completed_tasks: int,
    *,
    task_limit: int,
    divisor: int,
    geometry_gate: bool = False,
) -> tuple[tuple[int, float], ...]:
    """Return the exact source distribution for tasks closed by one attempt.

    This is the probability model behind the classic forecast. It enumerates
    the small finite ``R(n)`` space used by ``suffer`` and deliberately omits
    the final health roll because it cannot change the number of tasks. The
    function consumes no RNG and is therefore safe for planner prediction.
    """

    brain_rolls = _source_roll_values(brain)
    low_health_rolls = _source_roll_values(5 - health) if health <= 5 else (0,)
    stamina_rolls = _source_roll_values(stamina)
    difficulty_rolls = _source_roll_values(difficulty)
    remaining = max(0, task_limit - completed_tasks)
    counts: dict[int, int] = {}

    for brain_roll in brain_rolls:
        for low_health_roll in low_health_rolls:
            effective_knowledge = knowledge - difficulty + brain_roll - low_health_roll
            raw_tasks = (
                floor(effective_knowledge**0.5 / divisor + 0.5) if effective_knowledge > 0 else 0
            )
            raw_tasks = max(0, min(raw_tasks, remaining))
            for stamina_roll in stamina_rolls:
                for difficulty_roll in difficulty_rolls:
                    tasks = raw_tasks
                    if geometry_gate:
                        knowledge_after = max(
                            0,
                            knowledge + stamina_roll - difficulty_roll,
                        )
                        if charisma * 2 + 26 < knowledge_after:
                            tasks = 0
                    counts[tasks] = counts.get(tasks, 0) + 1

    total = sum(counts.values())
    return tuple((tasks, count / total) for tasks, count in sorted(counts.items()))


def source_exam_close_probability(
    knowledge: int,
    health: int,
    difficulty: int,
    brain: int,
    stamina: int,
    charisma: int,
    completed_tasks: int,
    *,
    task_limit: int,
    divisor: int,
    geometry_gate: bool = False,
) -> float:
    """Return the exact source chance of closing a subject this attempt."""

    remaining = max(0, task_limit - completed_tasks)
    if remaining == 0:
        return 1.0
    return sum(
        probability
        for tasks, probability in source_exam_task_distribution(
            knowledge,
            health,
            difficulty,
            brain,
            stamina,
            charisma,
            completed_tasks,
            task_limit=task_limit,
            divisor=divisor,
            geometry_gate=geometry_gate,
        )
        if tasks >= remaining
    )


def source_controller_catch_probability(charisma: int) -> float:
    """Return ``P(charisma < R(10))`` from the source train branch."""

    return max(0.0, min(1.0, (9 - charisma) / 10)) if charisma < 10 else 0.0


def source_study_health_cost_range(
    stamina: int,
    hour: int,
    *,
    has_notes: bool = False,
) -> tuple[int, int]:
    """Return the exact inclusive HP range of one source study action."""

    if stamina <= 0:
        lower = upper = 10
    else:
        lower, upper = 11 - stamina, 10
    if has_notes:
        lower = upper = 0
    if hour > 21 or hour < 4:
        lower += 12
        upper += 12
    return lower, upper


def source_study_gain_range(
    brain: int,
    health: int,
    hour: int,
    *,
    has_notes: bool = False,
) -> tuple[int, int]:
    """Return the exact inclusive knowledge range of one study action."""

    base = brain if hour < 19 else brain * 2 // 3
    random_stat = max(0, brain // 2)
    random_health = max(0, health // 18)
    lower = base - max(0, random_stat - 1)
    upper = base
    upper += max(0, random_health - 1)
    if has_notes:
        lower += 10
        upper += 10
    return lower, upper


def source_exam_hp_loss_range(
    stamina: int, fatigue: int, *, train: bool = False
) -> tuple[int, int]:
    """Return the exact HP-loss interval for one normal source exam."""

    roll_size = stamina * 2 // 3 if train else stamina
    maximum_roll = max(0, roll_size - 1)
    return max(fatigue - maximum_roll, 0), fatigue


def source_sleep_health_gain_range(health: int) -> tuple[int, int]:
    """Return the min/max HP gain over the source's ``R(20)`` sleep roll."""

    gains = tuple(min(health + 15 + roll, 50) - health for roll in range(20))
    return min(gains), max(gains)


def source_score(
    passed: Sequence[bool],
    passed_days: Sequence[int],
    completed_tasks: Sequence[int],
    *,
    terkom: bool = False,
) -> int:
    """Calculate the source end score without printing or mutating state."""

    if not (
        len(passed) == len(passed_days) == len(completed_tasks) == len(CLASSIC_SOURCE_SUBJECTS)
    ):
        raise ValueError("source score expects six subject entries")
    score = sum(
        (6 - passed_days[index])
        * (CLASSIC_SOURCE_SUBJECTS[index].tasks + CLASSIC_SOURCE_SUBJECTS[index].difficulty)
        * 2
        // 3
        for index, is_passed in enumerate(passed)
        if is_passed
    )
    algebra_index = 0
    matan_index = 1
    geometry_index = 2
    if not passed[algebra_index]:
        score = max(
            0,
            score
            - (CLASSIC_SOURCE_SUBJECTS[algebra_index].tasks - completed_tasks[algebra_index]) * 4,
        )
    if not passed[matan_index]:
        score = score * 2 // 3
    if not passed[geometry_index]:
        score = score * 2 // 3
    if terkom:
        score = score * 2 // 3
    return score
