"""BALANCE-01: reachable resource-cycle analyzer over the real reducers.

Enumerate short geographically closed action cycles (``A -> B -> ... -> A``)
from probe states and report net ``HP / money / knowledge / tasks / time``.
Positive recovery alone is not an error; a cycle that gains money, tasks,
knowledge or HP while spending no time (or going back in time) is arbitrage.

Boundaries (same as the availability resolver):
- Only deterministic money and time are compared; stochastic effect sizes
  (controller damage, classic rolls) are executed with an explicit seeded RNG
  and never predicted.
- The analyzer never mutates state: every step uses the immutable reducers.
- This module is intentionally *not* re-exported from ``mmvn.balance``:
  importing it there would cycle back through ``mmvn.rules``.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from mmvn.constants import RandomSource
from mmvn.models import GameState
from mmvn.rules.types import ActionResult
from mmvn.time_budget import state_absolute_minutes

from . import MODERN_BALANCE
from .profiles import BalanceProfile

__all__ = (
    "ActionCycle",
    "CycleDeltas",
    "CycleReport",
    "default_repertoire",
    "find_cycles",
)

ActionFn = Callable[[GameState, RandomSource], ActionResult]


@dataclass(frozen=True)
class CycleDeltas:
    """Net resource change of one closed action cycle."""

    dhp: int = 0
    dmoney: int = 0
    dknowledge: int = 0
    dtasks: int = 0
    dminutes: int = 0

    @property
    def is_arbitrage(self) -> bool:
        """Return whether the cycle gains resources for free.

        Any gain paired with zero or negative elapsed time is arbitrage.
        Gains paired with spent time (work pay, recovery loops) are not.
        """

        if self.dminutes > 0:
            return False
        return self.dhp > 0 or self.dmoney > 0 or self.dknowledge > 0 or self.dtasks > 0


@dataclass(frozen=True)
class ActionCycle:
    """One executable closed cycle with its measured net deltas."""

    actions: tuple[str, ...]
    deltas: CycleDeltas


@dataclass(frozen=True)
class CycleReport:
    """All closed cycles found plus the arbitrage subset (normally empty)."""

    cycles: tuple[ActionCycle, ...]
    arbitrage: tuple[ActionCycle, ...]


def _deltas(before: GameState, after: GameState) -> CycleDeltas:
    return CycleDeltas(
        dhp=after.health - before.health,
        dmoney=after.money - before.money,
        dknowledge=sum(p.knowledge for p in after.subjects)
        - sum(p.knowledge for p in before.subjects),
        dtasks=sum(p.tasks_done for p in after.subjects)
        - sum(p.tasks_done for p in before.subjects),
        dminutes=state_absolute_minutes(after) - state_absolute_minutes(before),
    )


def default_repertoire(
    profile: BalanceProfile | str | None = None,
) -> tuple[tuple[str, ActionFn], ...]:
    """Return the repeatable actions the analyzer may chain.

    Every ``work_options`` entry is included, not just the shortest shift: work
    is the only money source in the ruleset, so covering one of three shifts
    leaves the income loop unaudited (AUDIT-07). Actions that cannot execute
    from a given probe are skipped by the search itself.
    """

    from mmvn.rules import eat_food, rest, sleep, study, travel_to, wait, work_terkom

    selected = profile if isinstance(profile, BalanceProfile) else MODERN_BALANCE
    shifts = tuple(
        (
            f"work:{option.option_id}",
            lambda state, rng, oid=option.option_id: work_terkom(
                state, profile=profile, option_id=oid, rng=rng
            ),
        )
        for option in selected.work_options
    )

    return (
        ("wait", lambda state, rng: wait(state, profile=profile)),
        ("rest:dorm", lambda state, rng: rest(state, "dorm", profile=profile, rng=rng)),
        ("rest:cafe", lambda state, rng: rest(state, "cafe", profile=profile, rng=rng)),
        ("food:cola", lambda state, rng: eat_food(state, "cola", profile=profile, rng=rng)),
        ("food:soup", lambda state, rng: eat_food(state, "soup", profile=profile, rng=rng)),
        *shifts,
        ("study:algebra", lambda state, rng: study(state, "algebra", profile=profile, rng=rng)),
        ("sleep", lambda state, rng: sleep(state, profile=profile, rng=rng)),
        ("travel:dorm", lambda state, rng: travel_to(state, "dorm", profile=profile, rng=rng)),
        (
            "travel:faculty",
            lambda state, rng: travel_to(state, "faculty", profile=profile, rng=rng),
        ),
        ("travel:pomi", lambda state, rng: travel_to(state, "pomi", profile=profile, rng=rng)),
        (
            "travel:computer_lab",
            lambda state, rng: travel_to(state, "computer_lab", profile=profile, rng=rng),
        ),
        (
            "travel:mausoleum",
            lambda state, rng: travel_to(state, "mausoleum", profile=profile, rng=rng),
        ),
    )


def find_cycles(
    states: tuple[GameState, ...] | list[GameState],
    repertoire: tuple[tuple[str, ActionFn], ...] | None = None,
    *,
    max_length: int = 3,
    rng: RandomSource,
) -> CycleReport:
    """Execute every action chain up to ``max_length`` and keep closed cycles.

    A chain is kept when every step returns ``ok`` and the final location
    matches the starting location. Every stochastic roll draws from the one
    caller-provided RNG in fixed traversal order, so reports are reproducible
    for a fixed RNG seed. The domain layer never imports ``random`` itself.
    """

    actions = repertoire if repertoire is not None else default_repertoire(MODERN_BALANCE)
    found: dict[tuple[str, ...], ActionCycle] = {}

    def attempt(state: GameState, fn: ActionFn) -> GameState | None:
        result = fn(state, rng)
        if result.ok:
            return result.state
        return None

    def visit(start: GameState, cursor: GameState, names: tuple[str, ...]) -> None:
        if names and cursor.location == start.location and names not in found:
            found[names] = ActionCycle(actions=names, deltas=_deltas(start, cursor))
        if len(names) >= max_length:
            return
        for name, fn in actions:
            advanced = attempt(cursor, fn)
            if advanced is not None:
                visit(start, advanced, (*names, name))

    for start in states:
        visit(start, start, ())

    cycles = tuple(found.values())
    return CycleReport(
        cycles=cycles,
        arbitrage=tuple(cycle for cycle in cycles if cycle.deltas.is_arbitrage),
    )
