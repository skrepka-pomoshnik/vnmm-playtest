"""Balance target vectors and classic calibration summaries."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Final

from .reference_source import (
    CLASSIC_SOURCE_SUBJECTS,
    source_controller_catch_probability,
    source_exam_hp_loss_range,
    source_sleep_health_gain_range,
    source_study_health_cost_range,
)


@dataclass(frozen=True)
class MetricBand:
    """A named target interval used by the balance report."""

    metric: str
    minimum: float
    maximum: float
    unit: str = ""
    rationale: str = ""
    maximum_inclusive: bool = True

    def contains(self, value: float) -> bool:
        """Return whether ``value`` satisfies this interval.

        The modern six-of-six target is deliberately an open upper bound:
        ``5%`` is a ceiling, not a value that passes by rounding.  Keeping
        that detail on the band avoids duplicating comparison rules in every
        report writer.
        """

        if value < self.minimum:
            return False
        if self.maximum_inclusive:
            return value <= self.maximum
        return value < self.maximum

    def as_dict(self) -> dict[str, object]:
        return {
            "minimum": self.minimum,
            "maximum": self.maximum,
            "unit": self.unit,
            "rationale": self.rationale,
            "maximum_inclusive": self.maximum_inclusive,
        }


@dataclass(frozen=True)
class BalanceTarget:
    """A vector of independently checked targets, not a magic score."""

    profile_id: str
    difficulty_id: str
    description: str
    metrics: tuple[MetricBand, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "profile_id": self.profile_id,
            "difficulty_id": self.difficulty_id,
            "description": self.description,
            "metrics": {metric.metric: metric.as_dict() for metric in self.metrics},
        }


@dataclass(frozen=True)
class ClassicReferenceMetrics:
    """Exact structural and distributional facts recovered from the source."""

    subject_count: int
    week_days: int
    week_hours: int
    schedule_appointments: int
    task_load: int
    difficulty_sum: int
    fatigue_sum: int
    start_hour_range: tuple[int, int]
    study_day_hp_cost_at_stamina_6: tuple[int, int]
    study_night_hp_cost_at_stamina_6: tuple[int, int]
    exam_hp_loss_ranges: tuple[tuple[str, tuple[int, int]], ...]
    sleep_health_gain_at_hp_30: tuple[int, int]
    work_income_range: tuple[int, int]
    paid_pomi_round_trip_minutes: int
    paid_pomi_round_trip_fare: int
    local_travel_minutes: int
    nested_game_minutes: int
    unpaid_train_health_loss_range: tuple[int, int]
    controller_catch_probability_at_charisma: tuple[tuple[int, float], ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "subject_count": self.subject_count,
            "week_days": self.week_days,
            "week_hours": self.week_hours,
            "schedule_appointments": self.schedule_appointments,
            "task_load": self.task_load,
            "difficulty_sum": self.difficulty_sum,
            "fatigue_sum": self.fatigue_sum,
            "start_hour_range": self.start_hour_range,
            "study_day_hp_cost_at_stamina_6": self.study_day_hp_cost_at_stamina_6,
            "study_night_hp_cost_at_stamina_6": self.study_night_hp_cost_at_stamina_6,
            "exam_hp_loss_ranges": dict(self.exam_hp_loss_ranges),
            "sleep_health_gain_at_hp_30": self.sleep_health_gain_at_hp_30,
            "work_income_range": self.work_income_range,
            "paid_pomi_round_trip_minutes": self.paid_pomi_round_trip_minutes,
            "paid_pomi_round_trip_fare": self.paid_pomi_round_trip_fare,
            "local_travel_minutes": self.local_travel_minutes,
            "nested_game_minutes": self.nested_game_minutes,
            "unpaid_train_health_loss_range": self.unpaid_train_health_loss_range,
            "controller_catch_probability_at_charisma": self.controller_catch_probability_at_charisma,
        }


def classic_reference_metrics() -> ClassicReferenceMetrics:
    """Return the source-derived vector used to judge ``classic`` fidelity."""

    normal_exam_ranges = tuple(
        (
            item.subject,
            source_exam_hp_loss_range(6, item.fatigue),
        )
        for item in CLASSIC_SOURCE_SUBJECTS
    )
    return ClassicReferenceMetrics(
        subject_count=len(CLASSIC_SOURCE_SUBJECTS),
        week_days=6,
        week_hours=6 * 24,
        schedule_appointments=sum(item.professor_days for item in CLASSIC_SOURCE_SUBJECTS),
        task_load=sum(item.tasks for item in CLASSIC_SOURCE_SUBJECTS),
        difficulty_sum=sum(item.difficulty for item in CLASSIC_SOURCE_SUBJECTS),
        fatigue_sum=sum(item.fatigue for item in CLASSIC_SOURCE_SUBJECTS),
        start_hour_range=(9, 18 - min(item.maximum_hours for item in CLASSIC_SOURCE_SUBJECTS)),
        study_day_hp_cost_at_stamina_6=source_study_health_cost_range(6, 12),
        study_night_hp_cost_at_stamina_6=source_study_health_cost_range(6, 22),
        exam_hp_loss_ranges=normal_exam_ranges,
        sleep_health_gain_at_hp_30=source_sleep_health_gain_range(30),
        work_income_range=(1, 4),
        paid_pomi_round_trip_minutes=120,
        paid_pomi_round_trip_fare=10,
        local_travel_minutes=0,
        nested_game_minutes=60,
        unpaid_train_health_loss_range=(0, 18),
        controller_catch_probability_at_charisma=tuple(
            (charisma, source_controller_catch_probability(charisma)) for charisma in (0, 3, 6, 9)
        ),
    )


CLASSIC_REFERENCE_TARGET: Final = BalanceTarget(
    profile_id="classic",
    difficulty_id="source",
    description="Точная цель по локальному исходнику: сохранять формулы и диапазоны, а не среднее число HP.",
    metrics=(
        MetricBand("task_load", 31, 31, "tasks", "SUBJ[*][5]"),
        MetricBand("difficulty_sum", 41, 41, "points", "SUBJ[*][3]"),
        MetricBand("fatigue_sum", 75, 75, "HP pressure", "SUBJ[*][4]"),
        MetricBand("schedule_appointments", 16, 16, "appointments", "SUBJ[*][7]"),
        MetricBand("paid_pomi_round_trip_minutes", 120, 120, "minutes", "one source hour each way"),
        MetricBand(
            "paid_pomi_round_trip_fare",
            10,
            10,
            "roubles",
            "10 ₽ for a source ticket covering both ways",
        ),
        MetricBand(
            "local_travel_minutes", 0, 0, "minutes", "local movement does not call hour_pass"
        ),
        MetricBand("nested_game_minutes", 60, 60, "minutes", "one source hour for play_mmheroes"),
        MetricBand("controller_catch_at_charisma_6", 0.3, 0.3, "probability", "P(6 < R(10))"),
    ),
)


REALISTIC_STANDARD_TARGET: Final = BalanceTarget(
    profile_id="modern",
    difficulty_id="standard",
    description="Основной режим: 6/6 должен встречаться реже 5%, а внимательный игрок обычно закрывает 4–5 предметов.",
    metrics=(
        MetricBand(
            "precision_six_of_six_rate",
            0.0,
            0.05,
            "rate",
            "diagnostic prepared route must keep 6/6 below 5%",
            maximum_inclusive=False,
        ),
        MetricBand(
            "attentive_six_of_six_rate",
            0.0,
            0.05,
            "rate",
            "attentive route must keep the ideal result below 5%",
            maximum_inclusive=False,
        ),
        MetricBand(
            "attentive_four_to_five_rate",
            0.45,
            0.70,
            "rate",
            "most attentive runs should finish at four or five passes",
        ),
        MetricBand(
            "attentive_median_passed",
            4,
            5,
            "subjects",
            "the central attentive outcome is four to five subjects",
        ),
        MetricBand("mistake_budget", 2, 3, "mistakes", "plausible expensive choices"),
        MetricBand(
            "newcomer_median_passed", 1, 2, "subjects", "one or two passes is a useful first run"
        ),
        MetricBand(
            "newcomer_replayable_rate",
            0.60,
            0.85,
            "rate",
            "finish alive with 1–2 passes and a reason to replay",
        ),
        MetricBand("death_rate", 0.0, 0.10, "rate", "no invisible early death wall"),
    ),
)


REALISTIC_GENTLE_TARGET: Final = BalanceTarget(
    profile_id="modern",
    difficulty_id="gentle",
    description="Мягкая неделя: больше восстановления, но 6/6 всё ещё должен оставаться результатом реже 5%.",
    metrics=(
        MetricBand(
            "precision_six_of_six_rate",
            0.0,
            0.05,
            "rate",
            "prepared route remains an exceptional result",
            maximum_inclusive=False,
        ),
        MetricBand(
            "attentive_six_of_six_rate",
            0.0,
            0.05,
            "rate",
            "attentive route remains below the 5% ceiling",
            maximum_inclusive=False,
        ),
        MetricBand("attentive_four_to_five_rate", 0.55, 0.85, "rate", "gentle onboarding"),
        MetricBand("attentive_median_passed", 4, 5, "subjects", "attentive player target"),
        MetricBand("mistake_budget", 3, 3, "mistakes", "all authored reference mistakes"),
        MetricBand(
            "newcomer_median_passed", 1, 2, "subjects", "one or two passes is a useful first run"
        ),
        MetricBand(
            "newcomer_replayable_rate",
            0.65,
            0.85,
            "rate",
            "finish alive with 1–2 passes and a reason to replay",
        ),
        MetricBand("death_rate", 0.0, 0.05, "rate", "gentle onboarding"),
    ),
)


REALISTIC_CHALLENGING_TARGET: Final = BalanceTarget(
    profile_id="modern",
    difficulty_id="challenging",
    description="Тяжёлый realistic: восстановление остаётся доступным, но цена подготовки и ошибок выше; 6/6 — реже 5%.",
    metrics=(
        MetricBand(
            "precision_six_of_six_rate",
            0.0,
            0.05,
            "rate",
            "prepared route remains an exceptional result",
            maximum_inclusive=False,
        ),
        MetricBand(
            "attentive_six_of_six_rate",
            0.0,
            0.05,
            "rate",
            "challenging route also keeps the ideal result below 5%",
            maximum_inclusive=False,
        ),
        MetricBand("attentive_four_to_five_rate", 0.15, 0.45, "rate", "hard-mode attentive band"),
        MetricBand("attentive_median_passed", 3, 4, "subjects", "hard mode costs roughly one pass"),
        MetricBand("mistake_budget", 0, 2, "mistakes", "classic-like error margin"),
        MetricBand("newcomer_median_passed", 1, 2, "subjects", "still playable blind"),
        MetricBand(
            "newcomer_replayable_rate",
            0.35,
            0.65,
            "rate",
            "some first runs end with 1–2 passes and remain replayable",
        ),
        MetricBand("death_rate", 0.0, 0.25, "rate", "death remains contextual and legible"),
    ),
)


BALANCE_TARGETS: Final[Mapping[tuple[str, str], BalanceTarget]] = MappingProxyType(
    {
        (
            CLASSIC_REFERENCE_TARGET.profile_id,
            CLASSIC_REFERENCE_TARGET.difficulty_id,
        ): CLASSIC_REFERENCE_TARGET,
        (
            REALISTIC_GENTLE_TARGET.profile_id,
            REALISTIC_GENTLE_TARGET.difficulty_id,
        ): REALISTIC_GENTLE_TARGET,
        (
            REALISTIC_STANDARD_TARGET.profile_id,
            REALISTIC_STANDARD_TARGET.difficulty_id,
        ): REALISTIC_STANDARD_TARGET,
        (
            REALISTIC_CHALLENGING_TARGET.profile_id,
            REALISTIC_CHALLENGING_TARGET.difficulty_id,
        ): REALISTIC_CHALLENGING_TARGET,
    }
)


def balance_target(profile_id: str, difficulty_id: str = "standard") -> BalanceTarget:
    """Return the explicit target vector for a report row."""

    key = ("modern" if profile_id == "realistic" else profile_id, difficulty_id)
    if key == ("classic", "standard"):
        key = ("classic", "source")
    try:
        return BALANCE_TARGETS[key]
    except KeyError as error:
        raise ValueError(f"no balance target for {profile_id}/{difficulty_id}") from error
