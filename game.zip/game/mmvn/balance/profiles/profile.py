"""Immutable profile object and its lookup methods."""

from __future__ import annotations

from dataclasses import dataclass

from .models import DurationConfig, FoodOption, WorkOption


@dataclass(frozen=True)
class BalanceProfile:
    """A complete, immutable set of gameplay knobs used by the core."""

    profile_id: str
    label: str
    description: str
    duration: DurationConfig
    study_base_health_cost: int
    study_night_health_cost: int
    study_stamina_divisor: int
    rest_health: tuple[tuple[str, int], ...]
    rest_cafe_cost: int
    sleep_health_gain: int
    sleep_stamina_gain: int
    food_options: tuple[FoodOption, ...]
    travel_fares: tuple[tuple[str, int], ...]
    travel_health_costs: tuple[tuple[str, int], ...]
    travel_controlled_health_cost: int
    controller_base_threshold: int
    controller_charisma_floor: int
    controller_charisma_step: int
    controller_max_bonus: int
    subject_difficulties: tuple[tuple[str, int], ...]
    exam_subject_fatigue: tuple[tuple[str, int], ...]
    task_requirements: tuple[tuple[str, int], ...]
    reference_task_counts: tuple[tuple[str, int], ...]
    exam_health_offset: int
    exam_stamina_multiplier: int
    exam_min_health_cost: int
    exam_push_health_cost: int
    exam_talk_health_cost: int
    teacher_last_chance_health_cost: int
    work_money_gain: int
    work_health_cost: int
    work_options: tuple[WorkOption, ...]
    stipend_amount: int
    stipend_ticket_uses: int
    pasha_ticket_grant: int
    nested_first_health_cost: int
    nested_second_health_cost: int
    exam_probability_base: float = 0.70
    exam_probability_step: float = 0.08
    exam_tactic_probability_bonus: float = 0.05
    exam_probability_floor: float = 0.25
    exam_probability_cap: float = 0.98
    difficulty_id: str = "standard"
    # ``continuous`` is the modern minute clock; ``hourly`` is classic only.
    calendar_mode: str = "continuous"
    knowledge_limit: int = 6
    # The optional encounter layer is a profile knob rather than a hidden
    # global.  Classic keeps it at zero; modern variants can trade pressure
    # for recovery opportunities without changing the authored route graph.
    random_event_trigger_percent: int = 0
    random_event_positive_weight: int = 0
    random_event_negative_weight: int = 0

    def __post_init__(self) -> None:
        if not self.profile_id:
            raise ValueError("balance profile must have an id")
        if self.study_stamina_divisor <= 0:
            raise ValueError("study stamina divisor must be positive")
        numeric_fields = (
            self.study_base_health_cost,
            self.study_night_health_cost,
            self.rest_cafe_cost,
            self.sleep_health_gain,
            self.sleep_stamina_gain,
            self.travel_controlled_health_cost,
            self.controller_base_threshold,
            self.controller_charisma_floor,
            self.controller_charisma_step,
            self.controller_max_bonus,
            self.exam_health_offset,
            self.exam_stamina_multiplier,
            self.exam_min_health_cost,
            self.exam_push_health_cost,
            self.exam_talk_health_cost,
            self.teacher_last_chance_health_cost,
            self.work_money_gain,
            self.work_health_cost,
            self.stipend_amount,
            self.stipend_ticket_uses,
            self.pasha_ticket_grant,
            self.nested_first_health_cost,
            self.nested_second_health_cost,
            self.random_event_trigger_percent,
            self.random_event_positive_weight,
            self.random_event_negative_weight,
        )
        if any(value < 0 for value in numeric_fields):
            raise ValueError("balance values must not be negative")
        probability_values = (
            self.exam_probability_base,
            self.exam_probability_step,
            self.exam_tactic_probability_bonus,
            self.exam_probability_floor,
            self.exam_probability_cap,
        )
        if any(value < 0 or value > 1 for value in probability_values):
            raise ValueError("exam probabilities must be between zero and one")
        if self.exam_probability_floor > self.exam_probability_cap:
            raise ValueError("exam probability floor must not exceed the cap")
        if not self.work_options:
            raise ValueError("balance profile must have a work option")
        if self.calendar_mode not in {"continuous", "hourly"}:
            raise ValueError("balance profile has an unknown calendar mode")
        if self.knowledge_limit <= 0:
            raise ValueError("knowledge limit must be positive")
        if self.random_event_trigger_percent > 100:
            raise ValueError("random event trigger must not exceed 100")
        if (
            self.random_event_trigger_percent > 0
            and self.random_event_positive_weight + self.random_event_negative_weight <= 0
        ):
            raise ValueError("enabled random events need a positive category weight")
        task_ids = tuple(subject for subject, _ in self.task_requirements)
        if len(set(task_ids)) != len(task_ids):
            raise ValueError("task requirement subjects must be unique")
        if any(tasks <= 0 for _, tasks in self.task_requirements):
            raise ValueError("task requirements must be positive")

    @staticmethod
    def _lookup(values: tuple[tuple[str, int], ...], key: str, label: str) -> int:
        for item_id, value in values:
            if item_id == key:
                return value
        raise KeyError(f"unknown {label}: {key}")

    def rest_gain(self, venue: str) -> int:
        return self._lookup(self.rest_health, venue, "rest venue")

    def travel_fare(self, destination: str) -> int:
        return self._lookup(self.travel_fares, destination, "travel destination")

    def travel_health(self, destination: str) -> int:
        return self._lookup(self.travel_health_costs, destination, "travel destination")

    def travel_health_for_route(self, origin: str, destination: str) -> int:
        """Return the health cost for a concrete modern train route.

        The profile stores the train cost under ``pomi`` because fares and
        health pressure are destination-based in the balance data.  A return
        trip still uses the same train, so the continuous calendar must charge
        that cost when leaving POMI as well.  The source-backed hourly profile
        keeps its own random return-loss rule in the classic reducer.
        """

        if self.calendar_mode != "hourly" and origin == "pomi" and destination != "pomi":
            return self.travel_health("pomi")
        return self.travel_health(destination)

    def subject_difficulty(self, subject: str) -> int:
        return self._lookup(self.subject_difficulties, subject, "subject")

    def subject_fatigue(self, subject: str) -> int | None:
        for subject_id, value in self.exam_subject_fatigue:
            if subject_id == subject:
                return value
        return None

    def subject_requirement(self, subject: str) -> int:
        """Return the playable task count for a subject in this profile."""

        return self._lookup(self.task_requirements, subject, "subject")

    def work_option(self, option_id: str | None = None) -> WorkOption:
        """Return a shift option, defaulting to the longest/source option."""

        if option_id is None:
            return self.work_options[-1]
        for option in self.work_options:
            if option.option_id == option_id:
                return option
        raise KeyError(f"unknown work option: {option_id}")


__all__ = ("BalanceProfile",)
