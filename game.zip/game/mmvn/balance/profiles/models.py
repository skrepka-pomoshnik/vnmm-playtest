"""Immutable value objects shared by balance profile definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

DAY_MINUTES = 24 * 60
WINDOW_COUNT = 4

# Explicit balance points for consecutive cramming sessions.  The first
# attempt is reliable; after the second the student can make one desperate
# extra attempt, after which a change of location is required.
STUDY_SUCCESS_PERCENTAGES: Final = (100, 90, 60, 30, 10, 0)
STUDY_FATIGUE_STREAK: Final = 2
STUDY_FRESH_AIR_STREAK: Final = 3


def study_success_percent(consecutive_sessions: int) -> int:
    """Return the knowledge-retention chance for the current cram attempt."""

    if consecutive_sessions <= 1:
        return STUDY_SUCCESS_PERCENTAGES[0]
    index = min(consecutive_sessions - 1, len(STUDY_SUCCESS_PERCENTAGES) - 1)
    return STUDY_SUCCESS_PERCENTAGES[index]


@dataclass(frozen=True)
class FoodOption:
    """A visible food trade-off, kept in the balance profile."""

    item_id: str
    label: str
    venue: str
    cost: int
    health: int
    brain: int = 0
    stamina: int = 0
    charisma: int = 0


@dataclass(frozen=True)
class WorkOption:
    """One visible TERKOM shift variant.

    The shift is played on the faculty, not in the computer lab: `work_terkom`
    gates on ``state.location != "faculty"``. `duration_key` names a `DurationKnob`
    in the profile.
    """

    option_id: str
    label: str
    duration_key: str
    money_gain: int
    health_cost: int

    def __post_init__(self) -> None:
        if not self.option_id or not self.duration_key:
            raise ValueError("work option identifiers must not be empty")
        if self.money_gain < 0 or self.health_cost < 0:
            raise ValueError("work option resource values must not be negative")


@dataclass(frozen=True)
class DurationKnob:
    """One named duration on the continuous gameplay clock.

    ``slots`` is retained as inert metadata for alpha profile readers.  It is
    not a cost and must never be consulted by a reducer.
    """

    key: str
    minutes: int
    category: str = "dialogue"
    display: str | None = None
    slots: int = 0

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("duration knob must have a key")
        if self.minutes < 0:
            raise ValueError("duration must not be negative")
        if self.slots < 0:
            raise ValueError("duration slots must not be negative")
        if self.minutes == 0 and self.display:
            raise ValueError("zero duration must not have a player-facing label")


@dataclass(frozen=True)
class DifficultyVariant:
    """Named pressure preset applied on top of the realistic profile."""

    difficulty_id: str
    label: str
    description: str

    def __post_init__(self) -> None:
        if not self.difficulty_id:
            raise ValueError("difficulty variant must have an id")


@dataclass(frozen=True)
class DurationConfig:
    """All tunable durations for one balance profile.

    ``window_minutes`` and ``travel_slots`` are legacy presentation/source
    reference tables.  They do not define modern action costs. Runtime
    actions use only ``DurationKnob.minutes`` and ``travel_minutes`` on the
    continuous clock.
    """

    window_minutes: tuple[int, ...]
    default_dialogue_minutes: int
    max_dialogue_minutes: int
    max_ambient_minutes: int
    action_knobs: tuple[DurationKnob, ...]
    travel_minutes: tuple[tuple[str, int], ...]
    travel_slots: tuple[tuple[str, int], ...]

    def __post_init__(self) -> None:
        if len(self.window_minutes) != WINDOW_COUNT:
            raise ValueError("the modern calendar must have exactly four windows")
        if any(minutes <= 0 for minutes in self.window_minutes):
            raise ValueError("calendar windows must be positive")
        if sum(self.window_minutes) != DAY_MINUTES:
            raise ValueError("calendar windows must cover exactly one day")
        if self.default_dialogue_minutes < 0:
            raise ValueError("default dialogue duration must not be negative")
        if self.max_dialogue_minutes < self.default_dialogue_minutes:
            raise ValueError("maximum dialogue duration must cover the default")
        if self.max_ambient_minutes < 0:
            raise ValueError("maximum ambient duration must not be negative")
        action_keys = tuple(knob.key for knob in self.action_knobs)
        if len(set(action_keys)) != len(action_keys):
            raise ValueError("duration knob keys must be unique")
        if any(minutes < 0 for _, minutes in self.travel_minutes):
            raise ValueError("travel durations must not be negative")
        if any(slots < 0 for _, slots in self.travel_slots):
            raise ValueError("travel window costs must not be negative")

    def action(self, key: str | None) -> DurationKnob | None:
        """Return a named action duration without exposing mutable config."""

        if not key:
            return None
        return next((knob for knob in self.action_knobs if knob.key == key), None)

    def action_slots(self, key: str | None, fallback: int = 1) -> int:
        """Return calendar windows for an action, including explicit zero."""

        knob = self.action(key)
        return fallback if knob is None else knob.slots

    def travel_duration(self, origin: str, destination: str) -> int | None:
        """Return the authored minute duration for an origin/destination pair."""

        key = f"{origin}_to_{destination}"
        direct = dict(self.travel_minutes)
        if key in direct:
            return direct[key]
        if destination == "pomi":
            return direct.get("to_pomi")
        if origin == "pomi":
            return direct.get("from_pomi")
        return None

    def travel_duration_map(self) -> dict[str, int]:
        """Return a compatibility copy for legacy callers and adapters."""

        return dict(self.travel_minutes)

    def travel_action_slots(self, origin: str, destination: str) -> int:
        """Return calendar windows for a route, including minute-based walks."""

        key = f"{origin}_to_{destination}"
        direct = dict(self.travel_slots)
        if key in direct:
            return direct[key]
        if destination == "pomi":
            return direct.get("to_pomi", self.action_slots("travel", 1))
        if origin == "pomi":
            return direct.get("from_pomi", self.action_slots("travel", 1))
        return self.action_slots("travel", 1)


__all__ = (
    "DAY_MINUTES",
    "STUDY_FATIGUE_STREAK",
    "STUDY_FRESH_AIR_STREAK",
    "STUDY_SUCCESS_PERCENTAGES",
    "WINDOW_COUNT",
    "DifficultyVariant",
    "DurationConfig",
    "DurationKnob",
    "FoodOption",
    "WorkOption",
    "study_success_percent",
)
