"""Public balance profile API assembled from focused definitions."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from types import MappingProxyType

from .catalog import CLASSIC_BALANCE, DIFFICULTY_VARIANTS, MODERN_BALANCE
from .durations import CLASSIC_DURATION, MODERN_DURATION
from .models import (
    DAY_MINUTES,
    STUDY_FATIGUE_STREAK,
    STUDY_FRESH_AIR_STREAK,
    STUDY_SUCCESS_PERCENTAGES,
    WINDOW_COUNT,
    DifficultyVariant,
    DurationConfig,
    DurationKnob,
    FoodOption,
    WorkOption,
    study_success_percent,
)
from .profile import BalanceProfile

BALANCE_PROFILES: Mapping[str, BalanceProfile] = MappingProxyType(
    {
        MODERN_BALANCE.profile_id: MODERN_BALANCE,
        CLASSIC_BALANCE.profile_id: CLASSIC_BALANCE,
    }
)


def difficulty_variant_label(difficulty_id: str) -> str:
    """Return the Russian label for a named pressure preset."""

    variant = DIFFICULTY_VARIANTS.get(difficulty_id)
    return variant.label if variant is not None else DIFFICULTY_VARIANTS["standard"].label


def difficulty_variant_description(difficulty_id: str) -> str:
    """Return the short explanation for a named pressure preset."""

    variant = DIFFICULTY_VARIANTS.get(difficulty_id)
    return (
        variant.description if variant is not None else DIFFICULTY_VARIANTS["standard"].description
    )


def available_difficulty_ids(profile: BalanceProfile | str | None = None) -> tuple[str, ...]:
    """Return difficulty choices valid for a base profile."""

    if isinstance(profile, BalanceProfile):
        profile_id = profile.profile_id
    else:
        profile_id = "modern" if profile in (None, "realistic") else str(profile)
        if profile_id.startswith("modern_"):
            profile_id = "modern"
    return ("standard",) if profile_id == "classic" else tuple(DIFFICULTY_VARIANTS)


def with_difficulty(
    profile: BalanceProfile | str | None = None,
    difficulty_id: str = "standard",
) -> BalanceProfile:
    """Derive an immutable pressure variant without changing event durations."""

    if difficulty_id not in DIFFICULTY_VARIANTS:
        raise ValueError(f"unknown difficulty variant: {difficulty_id}")

    if isinstance(profile, BalanceProfile):
        selected = profile
        if difficulty_id == selected.difficulty_id:
            return selected
        base = (
            MODERN_BALANCE
            if selected.profile_id == MODERN_BALANCE.profile_id
            else CLASSIC_BALANCE
            if selected.profile_id == CLASSIC_BALANCE.profile_id
            else selected
        )
    else:
        base = resolve_balance_profile(profile)
        if base.difficulty_id != "standard":
            base = MODERN_BALANCE if base.profile_id == "modern" else CLASSIC_BALANCE

    if base.profile_id == "classic" and difficulty_id != "standard":
        raise ValueError("classic balance has one source-backed difficulty")
    if difficulty_id == "standard":
        return base

    if difficulty_id == "gentle":
        study_delta = -1
        night_study_delta = -3
        rest_delta = 3
        sleep_delta = 5
        exam_offset_delta = -2
        exam_min_delta = -1
        exam_push_delta = -2
        exam_talk_delta = -1
        teacher_delta = -1
        travel_delta = -1
        work_delta = -2
        nested_delta = -2
        # Standard is already calibrated near the 5% 6/6 ceiling.  Gentle
        # should widen recovery margins without making a perfect result
        # common, so it moves only one small probability step.
        probability_delta = 0.02
        event_trigger = min(100, base.random_event_trigger_percent + 7)
        event_positive_weight = base.random_event_positive_weight + 2
        event_negative_weight = base.random_event_negative_weight
    else:
        # Challenging is deliberately a narrow-margin pressure profile.
        study_delta = 1
        night_study_delta = 3
        # Keep the public cafe recovery route intact in the hard preset.
        # Difficulty should come from extra preparation/exam pressure, not
        # from making every readable recovery action fail at a one-HP
        # threshold. Dorm recovery still loses one point, preserving the
        # variant's narrower margin and the profile's existing contract.
        rest_delta = -1
        sleep_delta = -6
        exam_offset_delta = 1
        exam_min_delta = 0
        exam_push_delta = 1
        exam_talk_delta = 0
        teacher_delta = 2
        travel_delta = 0
        work_delta = 3
        nested_delta = 3
        probability_delta = -0.12
        event_trigger = max(0, base.random_event_trigger_percent - 8)
        event_positive_weight = max(0, base.random_event_positive_weight - 1)
        event_negative_weight = base.random_event_negative_weight + 2

    rest_health = tuple(
        (
            venue,
            max(
                0,
                gain + (0 if difficulty_id == "challenging" and venue == "cafe" else rest_delta),
            ),
        )
        for venue, gain in base.rest_health
    )
    travel_health = tuple(
        (destination, max(0, cost + travel_delta)) for destination, cost in base.travel_health_costs
    )
    work_options = tuple(
        replace(option, health_cost=max(0, option.health_cost + work_delta))
        for option in base.work_options
    )
    return replace(
        base,
        rest_health=rest_health,
        sleep_health_gain=max(0, base.sleep_health_gain + sleep_delta),
        study_base_health_cost=max(1, base.study_base_health_cost + study_delta),
        study_night_health_cost=max(1, base.study_night_health_cost + night_study_delta),
        exam_health_offset=max(0, base.exam_health_offset + exam_offset_delta),
        exam_min_health_cost=max(0, base.exam_min_health_cost + exam_min_delta),
        exam_push_health_cost=max(0, base.exam_push_health_cost + exam_push_delta),
        exam_talk_health_cost=max(0, base.exam_talk_health_cost + exam_talk_delta),
        teacher_last_chance_health_cost=max(
            0, base.teacher_last_chance_health_cost + teacher_delta
        ),
        travel_health_costs=travel_health,
        work_options=work_options,
        nested_first_health_cost=max(0, base.nested_first_health_cost + nested_delta),
        nested_second_health_cost=max(0, base.nested_second_health_cost + nested_delta),
        exam_probability_base=min(
            base.exam_probability_cap,
            max(base.exam_probability_floor, base.exam_probability_base + probability_delta),
        ),
        random_event_trigger_percent=event_trigger,
        random_event_positive_weight=event_positive_weight,
        random_event_negative_weight=event_negative_weight,
        difficulty_id=difficulty_id,
    )


def resolve_balance_profile(
    profile: BalanceProfile | str | None = None,
    difficulty_id: str | None = None,
) -> BalanceProfile:
    """Resolve a base profile and optional explicit realistic difficulty."""

    if isinstance(profile, BalanceProfile):
        if difficulty_id is None:
            return profile
        return with_difficulty(profile, difficulty_id)

    requested = "modern" if profile is None or profile == "realistic" else profile
    embedded_difficulty = None
    for suffix in ("_gentle", "_standard", "_challenging"):
        if requested.endswith(suffix):
            requested = requested[: -len(suffix)]
            embedded_difficulty = suffix[1:]
            break
    selected = BALANCE_PROFILES.get(requested, MODERN_BALANCE)
    return with_difficulty(selected, difficulty_id or embedded_difficulty or "standard")


def balance_profile_label(profile: BalanceProfile | str | None = None) -> str:
    """Return the stable Russian label used by the Settings screen."""

    selected = resolve_balance_profile(profile)
    if selected.difficulty_id == "standard":
        return selected.label
    return f"{selected.label} · {difficulty_variant_label(selected.difficulty_id)}"


def balance_profile_description(profile: BalanceProfile | str | None = None) -> str:
    """Return the short explanation shown below the profile toggle."""

    selected = resolve_balance_profile(profile)
    if selected.difficulty_id == "standard":
        return selected.description
    return f"{selected.description} {difficulty_variant_description(selected.difficulty_id)}"


def toggle_balance_profile_id(profile: BalanceProfile | str | None = None) -> str:
    """Return the other built-in profile id for a settings toggle."""

    current = resolve_balance_profile(profile)
    return "classic" if current.profile_id == "modern" else "modern"


__all__ = (
    "BALANCE_PROFILES",
    "CLASSIC_BALANCE",
    "CLASSIC_DURATION",
    "DAY_MINUTES",
    "DIFFICULTY_VARIANTS",
    "MODERN_BALANCE",
    "MODERN_DURATION",
    "STUDY_FATIGUE_STREAK",
    "STUDY_FRESH_AIR_STREAK",
    "STUDY_SUCCESS_PERCENTAGES",
    "WINDOW_COUNT",
    "BalanceProfile",
    "DifficultyVariant",
    "DurationConfig",
    "DurationKnob",
    "FoodOption",
    "WorkOption",
    "available_difficulty_ids",
    "balance_profile_description",
    "balance_profile_label",
    "difficulty_variant_description",
    "difficulty_variant_label",
    "resolve_balance_profile",
    "study_success_percent",
    "toggle_balance_profile_id",
    "with_difficulty",
)
