"""Calendar and action duration tables for the built-in balance profiles."""

from __future__ import annotations

from typing import Final

from .models import DurationConfig, DurationKnob

_ACTION_KNOBS: Final = (
    # Every value here is an exact elapsed duration on the one gameplay clock.
    DurationKnob("scene:misha:play", 45),
    DurationKnob("scene:misha:rules", 15),
    DurationKnob("scene:misha:decline", 5),
    DurationKnob("scene:misha_rematch:play", 45),
    DurationKnob("scene:misha_rematch:leave", 5),
    DurationKnob("scene:nil_archive:buy", 15),
    DurationKnob("scene:nil_archive:leave", 5),
    DurationKnob("scene:andrew_repay:teach", 30),
    DurationKnob("scene:andrew_repay:notes", 15),
    DurationKnob("scene:andrew_repay:refuse", 5),
    DurationKnob("scene:lore:baobab", 15),
    DurationKnob("scene:lore:terkom", 15),
    DurationKnob("scene:lore:geometry_rumor", 15),
    DurationKnob("scene:lore:international_students", 15),
    DurationKnob("scene:dorm_fuse:fix", 15),
    DurationKnob("scene:dorm_fuse:sleep", 5),
    DurationKnob("scene:travel_dogs:garages", 5),
    DurationKnob("scene:travel_dogs:brave", 5),
    DurationKnob("scene:social_evening:hour", 60),
    DurationKnob("scene:social_evening:full", 180, "social", "весь вечер"),
    DurationKnob("scene:social_evening:refuse", 5),
    # A preference game lasts until morning and does advance the calendar.
    DurationKnob("distraction:preference:play", 240, "overnight", "4 часа"),
    DurationKnob("distraction:preference:leave", 5),
    DurationKnob("distraction:freshman_linear_algebra:explain", 45, "elapsed"),
    DurationKnob("distraction:freshman_linear_algebra:leave", 5),
    DurationKnob("distraction:freshman_tea:tea", 45, "elapsed"),
    DurationKnob("distraction:freshman_notes:compare", 30, "elapsed"),
    DurationKnob("distraction:freshman_later:promise", 5, "elapsed"),
    DurationKnob("distraction:freshman_callback:walk", 30, "elapsed"),
    DurationKnob("distraction:freshman_callback:study", 45, "elapsed"),
    DurationKnob("distraction:freshman_callback:honest", 5, "elapsed"),
    DurationKnob("distraction:lost_student_room_09:lead", 15),
    DurationKnob("distraction:lost_student_room_09:directions", 5),
    DurationKnob("distraction:lost_student_room_09:leave", 5),
    DurationKnob("distraction:dorm_fee:resolve", 45, "elapsed"),
    DurationKnob("distraction:dorm_fee:pay", 5),
    # Reducer actions. Their minute value is authoritative; no reducer rounds
    # it to a daily band.
    DurationKnob("study", 45, "elapsed"),
    DurationKnob("rest", 45, "elapsed"),
    DurationKnob("rest:dorm", 60, "elapsed"),
    DurationKnob("food", 45, "elapsed"),
    DurationKnob("travel", 180, "elapsed"),
    DurationKnob("exam", 90, "elapsed"),
    DurationKnob("exam:patch", 90, "elapsed"),
    DurationKnob("work", 240, "elapsed"),
    DurationKnob("work:short", 240, "elapsed"),
    DurationKnob("work:standard", 300, "elapsed"),
    DurationKnob("work:long", 360, "elapsed"),
    DurationKnob("internet", 45, "elapsed"),
    DurationKnob("nested", 45, "elapsed"),
    DurationKnob("wait", 15, "elapsed", "15 минут"),
    DurationKnob("travel_delay", 60, "elapsed"),
    DurationKnob("sleep", 480, "overnight", "8 часов"),
)

_TRAVEL_MINUTES: Final = (
    ("dorm_to_faculty", 15),
    ("faculty_to_dorm", 15),
    ("dorm_to_mausoleum", 15),
    ("mausoleum_to_dorm", 15),
    ("faculty_to_mausoleum", 15),
    ("mausoleum_to_faculty", 15),
    ("dorm_to_computer_lab", 15),
    ("computer_lab_to_dorm", 15),
    ("faculty_to_computer_lab", 10),
    ("computer_lab_to_faculty", 10),
    ("mausoleum_to_computer_lab", 15),
    ("computer_lab_to_mausoleum", 15),
    ("to_pomi", 120),
    ("from_pomi", 120),
)

MODERN_DURATION = DurationConfig(
    window_minutes=(180, 240, 240, 780),
    default_dialogue_minutes=15,
    max_dialogue_minutes=60,
    max_ambient_minutes=45,
    action_knobs=_ACTION_KNOBS,
    travel_minutes=_TRAVEL_MINUTES,
    travel_slots=(
        ("dorm_to_faculty", 0),
        ("faculty_to_dorm", 0),
        ("dorm_to_mausoleum", 0),
        ("mausoleum_to_dorm", 0),
        ("faculty_to_mausoleum", 0),
        ("mausoleum_to_faculty", 0),
        ("dorm_to_computer_lab", 0),
        ("computer_lab_to_dorm", 0),
        ("faculty_to_computer_lab", 0),
        ("computer_lab_to_faculty", 0),
        ("mausoleum_to_computer_lab", 0),
        ("computer_lab_to_mausoleum", 0),
        ("to_pomi", 1),
        ("from_pomi", 1),
    ),
)

_CLASSIC_ACTION_KNOBS: Final = (
    # Classic keeps the source's hourly clock.  A local move is an immediate
    # location change in MMHEROES (the source charges its route HP penalty in
    # the scene, but does not call ``hour_pass``), while a train and an action
    # consume one source hour.
    DurationKnob("scene:misha:play", 60),
    DurationKnob("scene:misha:rules", 5),
    DurationKnob("scene:misha:decline", 5),
    DurationKnob("scene:misha_rematch:play", 60),
    DurationKnob("scene:misha_rematch:leave", 5),
    DurationKnob("scene:nil_archive:buy", 15),
    DurationKnob("scene:nil_archive:leave", 5),
    DurationKnob("scene:andrew_repay:teach", 30),
    DurationKnob("scene:andrew_repay:notes", 15),
    DurationKnob("scene:andrew_repay:refuse", 5),
    DurationKnob("scene:lore:baobab", 15),
    DurationKnob("scene:lore:terkom", 15),
    DurationKnob("scene:lore:geometry_rumor", 15),
    DurationKnob("scene:lore:international_students", 15),
    DurationKnob("scene:dorm_fuse:fix", 15),
    DurationKnob("scene:dorm_fuse:sleep", 5),
    DurationKnob("scene:travel_dogs:garages", 5),
    DurationKnob("scene:travel_dogs:brave", 5),
    DurationKnob("scene:social_evening:hour", 60),
    DurationKnob("scene:social_evening:full", 240, "social", "3–5 часов"),
    DurationKnob("scene:social_evening:refuse", 5),
    DurationKnob("distraction:preference:play", 240, "overnight", "4 часа"),
    DurationKnob("distraction:preference:leave", 5),
    DurationKnob("distraction:freshman_linear_algebra:explain", 45),
    DurationKnob("distraction:freshman_linear_algebra:leave", 5),
    DurationKnob("distraction:freshman_tea:tea", 45),
    DurationKnob("distraction:freshman_notes:compare", 30),
    DurationKnob("distraction:freshman_later:promise", 5),
    DurationKnob("distraction:freshman_callback:walk", 30),
    DurationKnob("distraction:freshman_callback:study", 45),
    DurationKnob("distraction:freshman_callback:honest", 5),
    DurationKnob("distraction:lost_student_room_09:lead", 15),
    DurationKnob("distraction:lost_student_room_09:directions", 5),
    DurationKnob("distraction:lost_student_room_09:leave", 5),
    DurationKnob("distraction:dorm_fee:resolve", 15),
    DurationKnob("distraction:dorm_fee:pay", 5),
    DurationKnob("study", 60, "elapsed"),
    DurationKnob("rest", 60, "elapsed"),
    DurationKnob("rest:dorm", 60, "elapsed"),
    DurationKnob("food", 60, "elapsed"),
    DurationKnob("travel", 60, "elapsed"),
    DurationKnob("exam", 60, "elapsed"),
    DurationKnob("exam:patch", 60, "elapsed"),
    DurationKnob("work", 60, "elapsed"),
    # The source has one work branch.  These aliases keep the profile schema
    # uniform while the UI exposes only the source-like standard option.
    DurationKnob("work:short", 60, "elapsed"),
    DurationKnob("work:standard", 60, "elapsed"),
    DurationKnob("work:long", 60, "elapsed"),
    DurationKnob("internet", 60, "elapsed"),
    # Launching the embedded program is a real player action in the planner.
    DurationKnob("nested", 60, "elapsed"),
    DurationKnob("wait", 60, "elapsed", "1 час"),
    DurationKnob("travel_delay", 60, "elapsed"),
    DurationKnob("sleep", 540, "overnight", "9 часов"),
)

_CLASSIC_TRAVEL_MINUTES: Final = (
    # Local movement has zero elapsed time in the source.  The source scene
    # still applies its location-specific HP penalty; that belongs to the
    # travel reducer, not to this duration table.
    ("dorm_to_faculty", 0),
    ("faculty_to_dorm", 0),
    ("dorm_to_mausoleum", 0),
    ("mausoleum_to_dorm", 0),
    ("faculty_to_mausoleum", 0),
    ("mausoleum_to_faculty", 0),
    ("dorm_to_computer_lab", 0),
    ("computer_lab_to_dorm", 0),
    ("faculty_to_computer_lab", 0),
    ("computer_lab_to_faculty", 0),
    ("mausoleum_to_computer_lab", 0),
    ("computer_lab_to_mausoleum", 0),
    ("to_pomi", 60),
    ("from_pomi", 60),
)

_CLASSIC_TRAVEL_SLOTS: Final = (
    ("dorm_to_faculty", 0),
    ("faculty_to_dorm", 0),
    ("dorm_to_mausoleum", 0),
    ("mausoleum_to_dorm", 0),
    ("faculty_to_mausoleum", 0),
    ("mausoleum_to_faculty", 0),
    ("dorm_to_computer_lab", 0),
    ("computer_lab_to_dorm", 0),
    ("faculty_to_computer_lab", 0),
    ("computer_lab_to_faculty", 0),
    ("mausoleum_to_computer_lab", 0),
    ("computer_lab_to_mausoleum", 0),
    ("to_pomi", 1),
    ("from_pomi", 1),
)

CLASSIC_DURATION = DurationConfig(
    window_minutes=(180, 240, 240, 780),
    default_dialogue_minutes=15,
    max_dialogue_minutes=60,
    max_ambient_minutes=45,
    action_knobs=_CLASSIC_ACTION_KNOBS,
    travel_minutes=_CLASSIC_TRAVEL_MINUTES,
    travel_slots=_CLASSIC_TRAVEL_SLOTS,
)


__all__ = ("CLASSIC_DURATION", "MODERN_DURATION")
