"""Built-in modern and classic balance profile definitions."""

from __future__ import annotations

from types import MappingProxyType
from typing import Final

from .durations import CLASSIC_DURATION, MODERN_DURATION
from .models import DifficultyVariant, FoodOption, WorkOption
from .profile import BalanceProfile

DIFFICULTY_VARIANTS: Final = MappingProxyType(
    {
        "gentle": DifficultyVariant(
            "gentle",
            "Мягкая неделя",
            "Больше запаса на восстановление и ошибки; расписание и длительности не меняются.",
        ),
        "standard": DifficultyVariant(
            "standard",
            "Обычная неделя",
            "Основной realistic-профиль: внимательный игрок может закрыть неделю, но цена ошибок видна.",
        ),
        "challenging": DifficultyVariant(
            "challenging",
            "Напряжённая неделя",
            "Общежитие восстанавливает меньше, ночная учёба и работа быстро съедают здоровье, а зачёты оставляют узкий запас для ошибки; кафе остаётся рабочей альтернативой.",
        ),
    }
)

_FOOD_OPTIONS: Final = (
    FoodOption("cola", "Кола", "mausoleum", 4, 4, stamina=1),
    FoodOption("soup", "Суп", "mausoleum", 6, 10, stamina=1),
    FoodOption("beer", "Пиво", "mausoleum", 8, 5, brain=-1, charisma=1),
    FoodOption("sit", "Просто посидеть", "mausoleum", 0, 2),
    FoodOption("coffee", "Кофе", "cafe", 2, 3, brain=1),
    FoodOption("pie", "Корж", "cafe", 4, 7, stamina=1),
    FoodOption("coffee_pie", "Кофе с выпечкой", "cafe", 6, 11, brain=1, stamina=1),
)

_TRAVEL_FARES: Final = (
    ("dorm", 0),
    ("faculty", 0),
    ("pomi", 10),
    ("computer_lab", 0),
    ("mausoleum", 0),
)
_TRAVEL_HEALTH_COSTS: Final = (
    ("dorm", 0),
    ("faculty", 0),
    ("pomi", 10),
    ("computer_lab", 0),
    ("mausoleum", 0),
)
_CLASSIC_TRAVEL_FARES: Final = (
    ("dorm", 0),
    ("faculty", 0),
    ("pomi", 10),
    ("computer_lab", 0),
    ("mausoleum", 0),
)
_CLASSIC_TRAVEL_HEALTH_COSTS: Final = (
    ("dorm", 0),
    ("faculty", 0),
    ("pomi", 10),
    ("computer_lab", 0),
    ("mausoleum", 0),
)
_REST_HEALTH: Final = (
    ("dorm", 8),
    ("cafe", 12),
    ("mausoleum", 8),
    ("serge", 6),
)

MODERN_BALANCE: Final = BalanceProfile(
    profile_id="modern",
    label="Реалистичный баланс",
    description="Реалистичный профиль расширенной версии: бытовые маршруты и восстановление сбалансированы.",
    duration=MODERN_DURATION,
    study_base_health_cost=7,
    study_night_health_cost=15,
    study_stamina_divisor=2,
    rest_health=_REST_HEALTH,
    rest_cafe_cost=8,
    sleep_health_gain=24,
    sleep_stamina_gain=2,
    food_options=_FOOD_OPTIONS,
    travel_fares=_TRAVEL_FARES,
    travel_health_costs=_TRAVEL_HEALTH_COSTS,
    travel_controlled_health_cost=15,
    controller_base_threshold=50,
    controller_charisma_floor=2,
    controller_charisma_step=5,
    controller_max_bonus=30,
    subject_difficulties=(
        ("algebra", 6),
        ("matan", 7),
        ("geometry", 5),
        ("informatics", 5),
        ("english", 4),
        ("pe", 3),
    ),
    exam_subject_fatigue=(),
    task_requirements=(
        ("algebra", 4),
        ("matan", 4),
        ("geometry", 3),
        ("informatics", 3),
        ("english", 2),
        ("pe", 2),
    ),
    reference_task_counts=(
        ("algebra", 4),
        ("matan", 4),
        ("geometry", 3),
        ("informatics", 3),
        ("english", 2),
        ("pe", 2),
    ),
    exam_health_offset=10,
    exam_stamina_multiplier=2,
    exam_min_health_cost=3,
    exam_push_health_cost=6,
    exam_talk_health_cost=2,
    teacher_last_chance_health_cost=5,
    work_money_gain=10,
    work_health_cost=12,
    work_options=(
        WorkOption("short", "3 часа", "work:short", 6, 8),
        WorkOption("standard", "5 часов", "work:standard", 10, 14),
        WorkOption("long", "8 часов", "work:long", 18, 22),
    ),
    stipend_amount=50,
    stipend_ticket_uses=2,
    pasha_ticket_grant=2,
    nested_first_health_cost=10,
    nested_second_health_cost=15,
    # Calibrated against the 64-seed target vector: a prepared route can still
    # reach 6/6, but it remains an exceptional result while an attentive first
    # run clusters at four to five passes.  These remain profile knobs so the
    # balance lab can sweep them without editing the resolver formula.
    exam_probability_base=0.28,
    exam_probability_step=0.04,
    exam_tactic_probability_bonus=0.02,
    exam_probability_floor=0.20,
    exam_probability_cap=0.96,
    random_event_trigger_percent=38,
    random_event_positive_weight=7,
    random_event_negative_weight=3,
)

CLASSIC_BALANCE: Final = BalanceProfile(
    profile_id="classic",
    label="Классический баланс",
    description="Профиль по локальному mmheroes: 50 ₽ без бесплатных билетов, дорогая электричка и строгие зачёты.",
    duration=CLASSIC_DURATION,
    study_base_health_cost=10,
    study_night_health_cost=22,
    study_stamina_divisor=1,
    rest_health=(("dorm", 16), ("cafe", 20), ("mausoleum", 9), ("serge", 8)),
    rest_cafe_cost=8,
    sleep_health_gain=15,
    sleep_stamina_gain=0,
    food_options=_FOOD_OPTIONS,
    travel_fares=_CLASSIC_TRAVEL_FARES,
    travel_health_costs=_CLASSIC_TRAVEL_HEALTH_COSTS,
    travel_controlled_health_cost=10,
    # mmheroes checks ``charisma < R(10)``.  With the core's 1..100 roll this
    # is the equivalent success threshold ``(charisma + 1) * 10``.
    controller_base_threshold=10,
    controller_charisma_floor=0,
    controller_charisma_step=10,
    controller_max_bonus=90,
    subject_difficulties=(
        ("algebra", 10),
        ("matan", 8),
        ("geometry", 4),
        ("informatics", 5),
        ("english", 7),
        ("pe", 7),
    ),
    # SUBJ[*][4] in mmheroes: expected health pressure at an exam before
    # stamina reduces it.  The current immutable core keeps one deterministic
    # result per action, so the profile uses the conservative lower bound.
    exam_subject_fatigue=(
        ("algebra", 17),
        ("matan", 14),
        ("geometry", 8),
        ("informatics", 6),
        ("english", 10),
        ("pe", 20),
    ),
    task_requirements=(
        ("algebra", 12),
        ("matan", 10),
        ("geometry", 3),
        ("informatics", 2),
        ("english", 3),
        ("pe", 1),
    ),
    # SUBJ[*][5] remains duplicated as an explicit source-reference vector so
    # reports can distinguish runtime requirements from provenance.
    reference_task_counts=(
        ("algebra", 12),
        ("matan", 10),
        ("geometry", 3),
        ("informatics", 2),
        ("english", 3),
        ("pe", 1),
    ),
    exam_health_offset=13,
    exam_stamina_multiplier=2,
    exam_min_health_cost=4,
    exam_push_health_cost=8,
    exam_talk_health_cost=2,
    teacher_last_chance_health_cost=4,
    # ``earn()`` in mmheroes normally yields 1-4 ₽ and the work branch burns
    # a random amount of HP.  The headless core uses midpoint pressure.
    work_money_gain=3,
    work_health_cost=3,
    work_options=(WorkOption("standard", "1 час", "work", 3, 3),),
    stipend_amount=50,
    stipend_ticket_uses=0,
    pasha_ticket_grant=0,
    nested_first_health_cost=0,
    nested_second_health_cost=0,
    # Keep the full game's more volatile closing roll in classic mode.
    exam_probability_base=0.46,
    exam_probability_step=0.105,
    exam_tactic_probability_bonus=0.06,
    exam_probability_floor=0.20,
    exam_probability_cap=0.98,
    calendar_mode="hourly",
    knowledge_limit=100,
    random_event_trigger_percent=0,
    random_event_positive_weight=0,
    random_event_negative_weight=0,
)


__all__ = ("CLASSIC_BALANCE", "DIFFICULTY_VARIANTS", "MODERN_BALANCE")
