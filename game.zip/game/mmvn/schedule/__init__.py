"""Fixed teacher appointments and schedule-variant transitions."""

from dataclasses import replace

from ..balance import BalanceProfile, resolve_balance_profile
from ..balance.reference import source_initial_roll, source_schedule
from ..constants import (
    HERO_TYPE_STATS,
    INITIAL_MONEY,
    SUBJECTS,
    TEACHERS,
    RandomSource,
    seed_rng,
)
from ..models import Appointment, GameState, Stats, SubjectProgress

SCHEDULE_A_ROWS = (
    (1, 1, "english", "faculty"),
    (1, 2, "pe", "faculty"),
    # The morning train to POMI consumes 08:00-11:00 on the continuous clock;
    # leave the first possible arrival band free for this appointment.
    (2, 1, "algebra", "pomi"),
    (2, 1, "matan", "faculty"),
    (2, 2, "geometry", "pomi"),
    (3, 0, "informatics", "computer_lab"),
    (3, 1, "english", "faculty"),
    (3, 2, "algebra", "faculty"),
    (4, 0, "matan", "pomi"),
    (4, 1, "geometry", "faculty"),
    (4, 2, "informatics", "computer_lab"),
    (4, 3, "pe", "faculty"),
    (5, 0, "algebra", "pomi"),
    (5, 1, "geometry", "pomi"),
    (5, 2, "matan", "faculty"),
    (5, 2, "informatics", "computer_lab"),
    (6, 0, "english", "faculty"),
    (6, 1, "pe", "faculty"),
    (6, 1, "informatics", "computer_lab"),
)

SCHEDULE_B_ROWS = (
    (1, 1, "english", "faculty"),
    (1, 2, "pe", "faculty"),
    (2, 1, "algebra", "pomi"),
    (2, 1, "matan", "faculty"),
    (2, 2, "geometry", "pomi"),
    (3, 0, "informatics", "computer_lab"),
    (3, 1, "english", "faculty"),
    (3, 2, "algebra", "faculty"),
    (4, 0, "matan", "pomi"),
    (4, 1, "geometry", "faculty"),
    (4, 2, "informatics", "computer_lab"),
    (4, 3, "pe", "faculty"),
    (5, 0, "geometry", "pomi"),
    (5, 1, "informatics", "computer_lab"),
    (5, 2, "matan", "faculty"),
    (5, 3, "pe", "faculty"),
    (6, 0, "matan", "pomi"),
    (6, 1, "algebra", "faculty"),
    (6, 2, "geometry", "faculty"),
    (6, 2, "informatics", "computer_lab"),
)

SCHEDULE_ROWS = {"A": SCHEDULE_A_ROWS, "B": SCHEDULE_B_ROWS}
RESERVE_DAY = 6
RESERVE_SLOT = 2
RESERVE_LOCATION = "faculty"
RESERVE_SUBJECTS = ("algebra", "matan", "geometry")


def _appointments(
    rows: tuple[tuple[int, int, str, str], ...],
    task_requirements: dict[str, int],
) -> tuple[Appointment, ...]:
    return tuple(
        Appointment(
            subject=subject,
            day=day,
            slot=slot,
            location=location,
            teacher=TEACHERS[subject],
            required_tasks=task_requirements[subject],
            start_hour=9 if slot == 0 else None,
            start_minute_offset=30 if slot == 0 else 0,
        )
        for day, slot, subject, location in rows
    )


def _source_appointments(
    rng: RandomSource,
    task_requirements: dict[str, int],
) -> tuple[Appointment, ...]:
    """Translate the source's zero-based hourly schedule to runtime rows."""

    return tuple(
        Appointment(
            subject=entry.subject,
            day=entry.day + 1,
            slot=GameState._hourly_slot(entry.start_hour),
            location=entry.location,
            teacher=TEACHERS[entry.subject],
            required_tasks=task_requirements[entry.subject],
            start_hour=entry.start_hour,
            end_hour=entry.end_hour,
        )
        for entry in source_schedule(rng)
    )


def generate_schedule(
    rng: RandomSource,
    days: int = 6,
    variant: str = "A",
    profile: BalanceProfile | str | None = None,
) -> tuple[Appointment, ...]:
    """Return the authored schedule with the selected profile's task limits."""

    if days < 1:
        raise ValueError("days must be positive")
    if variant not in SCHEDULE_ROWS:
        raise ValueError("unknown schedule variant")

    selected = resolve_balance_profile(profile)
    task_requirements = dict(selected.task_requirements)
    if selected.calendar_mode == "hourly":
        return tuple(
            appointment
            for appointment in _source_appointments(rng, task_requirements)
            if appointment.day <= days
        )
    return tuple(
        appointment
        for appointment in _appointments(SCHEDULE_ROWS[variant], task_requirements)
        if appointment.day <= days
    )


def new_game(
    rng: RandomSource,
    seed: int = 220508,
    hero_type: str = "universal",
    profile: BalanceProfile | str | None = None,
) -> GameState:
    """Create a reproducible initial state using the caller's RNG."""

    if hero_type not in HERO_TYPE_STATS:
        raise ValueError("unknown hero type")

    selected = resolve_balance_profile(profile)
    seed_rng(rng, seed)
    if selected.calendar_mode == "hourly":
        source_archetype = {
            "universal": "random",
            "theorist": "smart",
            "survivor": "bold",
            "connector": "social",
        }[hero_type]
        initial = source_initial_roll(source_archetype, rng)
        stats = Stats(
            health=initial.health,
            brain=initial.brain,
            stamina=initial.stamina,
            charisma=initial.charisma,
            money=INITIAL_MONEY,
        )
        subjects = tuple(
            SubjectProgress(
                subject=subject,
                knowledge=initial.knowledge[index],
                task_limit=selected.subject_requirement(subject),
                knowledge_limit=selected.knowledge_limit,
            )
            for index, subject in enumerate(SUBJECTS)
        )
        return GameState(
            hero_type=hero_type,
            seed=seed,
            calendar_mode=selected.calendar_mode,
            clock_hour=8,
            stats=stats,
            subjects=subjects,
            schedule=generate_schedule(rng, profile=selected),
            event_flags=frozenset(("has_gradebook",)),
        )
    stats = Stats(**HERO_TYPE_STATS[hero_type], money=INITIAL_MONEY)
    return GameState(
        hero_type=hero_type,
        seed=seed,
        stats=stats,
        subjects=tuple(
            SubjectProgress(subject=subject, task_limit=selected.subject_requirement(subject))
            for subject in SUBJECTS
        ),
        schedule=generate_schedule(rng, profile=selected),
        # The gradebook starts in inventory; losing it is separate future content.
        event_flags=frozenset(("has_gradebook",)),
    )


def current_time_appointments(state: GameState) -> tuple[Appointment, ...]:
    """Return every appointment active at the current date and time.

    Location is intentionally ignored here. The planner uses this view to
    explain why an exam is unavailable while the action reducer uses the
    location-filtered :func:`current_appointments` view.
    """

    current_minute = state.hour * 60 + state.minute
    appointments = tuple(
        appointment
        for appointment in state.schedule
        if (
            appointment.day == state.day
            and appointment.start_minute <= current_minute < appointment.end_minute
        )
    )
    if state.day == RESERVE_DAY and state.slot == RESERVE_SLOT:
        appointments = ()
        if state.reserve_all:
            allowed = SUBJECTS
        elif state.schedule_variant == "B":
            allowed = ("geometry", "informatics")
        else:
            allowed = RESERVE_SUBJECTS
        if state.has_flag("kuzmenko_window") and "informatics" not in allowed:
            allowed = (*allowed, "informatics")
        if state.reserve_subject is not None:
            allowed = (state.reserve_subject,)
        appointments += tuple(
            Appointment(
                subject=subject,
                day=RESERVE_DAY,
                slot=RESERVE_SLOT,
                location=RESERVE_LOCATION,
                teacher="Комиссия",
                required_tasks=progress.required_tasks,
            )
            for subject in allowed
            if (progress := state.subject(subject)) is not None and not progress.passed
        )
    return appointments


def current_appointments(state: GameState) -> tuple[Appointment, ...]:
    """Return appointments active at the current date, time and location."""

    return tuple(
        appointment
        for appointment in current_time_appointments(state)
        if appointment.location == state.location
    )


def future_appointments(state: GameState) -> tuple[Appointment, ...]:
    current = (state.day, state.hour * 60 + state.minute)
    return tuple(
        appointment
        for appointment in state.schedule
        if (appointment.day, appointment.start_minute) > current
    )


def appointment_status(state: GameState, appointment: Appointment) -> str:
    """Classify a row relative to the exact current clock and location."""

    appointment_start = (appointment.day, appointment.start_minute)
    current = (state.day, state.hour * 60 + state.minute)
    if appointment_start > current:
        status = "future"
    elif appointment.day != state.day or current[1] >= appointment.end_minute:
        status = "past"
    else:
        status = "current"
    if status == "past":
        return "past"
    if status == "future":
        return "future"
    if appointment.location == state.location:
        return "current"
    return "elsewhere"


def regenerate_future_schedule(
    state: GameState,
    rng: RandomSource | None,
    variant: str = "B",
) -> tuple[Appointment, ...]:
    """Keep the past fixed and replace only future rows with authored variant B."""

    if state.calendar_mode == "hourly":
        if rng is None:
            raise ValueError("classic schedule regeneration needs an explicit RNG")
        task_requirements = {
            subject: (
                progress.required_tasks if (progress := state.subject(subject)) is not None else 0
            )
            for subject in SUBJECTS
        }
        regenerated = _source_appointments(rng, task_requirements)
        # mmheroes reinitialises only days after the current day.  The whole
        # current day remains the player's already observed timetable.
        past = tuple(appointment for appointment in state.schedule if appointment.day <= state.day)
        future = tuple(appointment for appointment in regenerated if appointment.day > state.day)
        return tuple(
            sorted(
                past + future,
                key=lambda item: (item.day, item.start_minute, item.subject),
            )
        )

    if variant not in SCHEDULE_ROWS:
        raise ValueError("unknown schedule variant")
    current = (state.day, state.hour * 60 + state.minute)
    past = tuple(
        appointment
        for appointment in state.schedule
        if (appointment.day, appointment.start_minute) <= current
    )
    task_requirements = {
        subject: (
            progress.required_tasks if (progress := state.subject(subject)) is not None else 0
        )
        for subject in SUBJECTS
    }
    future = tuple(
        appointment
        for appointment in _appointments(SCHEDULE_ROWS[variant], task_requirements)
        if (appointment.day, appointment.start_minute) > current
    )
    return tuple(
        sorted(past + future, key=lambda item: (item.day, item.start_minute, item.subject))
    )


def generate_chaos_schedule(
    rng: RandomSource, base: tuple[Appointment, ...]
) -> tuple[Appointment, ...]:
    """Shuffle Schedule A across days/slots with safety constraints.

    Constraints: every subject keeps its canonical slot position; only the
    day assignment is shuffled within the week. Reserve day (6) is preserved.
    """

    # Group appointments by slot (canonical time window).
    by_slot: dict[int, list[Appointment]] = {}
    for appt in base:
        if appt.day != RESERVE_DAY:
            by_slot.setdefault(appt.slot, []).append(appt)

    # Shuffle day assignments within valid range (days 1-5).
    shuffled: list[Appointment] = []
    used_subjects: set[str] = set()
    for slot in sorted(by_slot):
        entries = by_slot[slot][:]
        while entries:
            appt = entries.pop(rng.randint(0, len(entries) - 1))
            new_day = rng.randint(1, 5)
            attempts = 0
            while appt.subject in used_subjects and any(
                a.subject == appt.subject and a.day == new_day for a in shuffled
            ):
                new_day = rng.randint(1, 5)
                attempts += 1
                if attempts > 20:
                    break
            used_subjects.add(appt.subject)
            shuffled.append(replace(appt, day=new_day))

    # Preserve reserve-day appointments.
    for appt in base:
        if appt.day == RESERVE_DAY:
            shuffled.append(appt)

    return tuple(sorted(shuffled, key=lambda a: (a.day, a.slot)))
