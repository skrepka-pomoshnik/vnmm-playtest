"""Read-only presence queries shared by runtime screens and QA samplers."""

from ..models import GameState
from . import PRESENCE_ROTATION, _current_appointments_anywhere, _presence_priority, npc_locations


def present_characters_by_location(
    state: GameState, include_mantra: bool = False
) -> tuple[tuple[str, tuple[str, ...]], ...]:
    """Calculate the visible crowd for every known location in one pass.

    The planner normally asks for one location, but QA samplers and a few
    overview screens need the whole map. NPC geography is independent of the
    requested location, so sharing that calculation avoids repeatedly walking
    the same movement rules without changing the visible ordering.
    """

    active = _current_appointments_anywhere(state)
    today = tuple(appointment for appointment in state.schedule if appointment.day == state.day)
    locations = dict(npc_locations(state, active=active, today=today))
    result: list[tuple[str, tuple[str, ...]]] = []
    for location in PRESENCE_ROTATION:
        candidates = tuple(
            character
            for character, character_location in locations.items()
            if character_location == location
        )
        visible = tuple(
            character
            for character in sorted(
                candidates,
                key=lambda item: _presence_priority(state, item, active=active),
            )[:3]
        )
        if include_mantra and location == "faculty" and state.slot in (0, 2):
            visible = (*visible, "mantra")
        result.append((location, tuple(dict.fromkeys(visible))))
    return tuple(result)


__all__ = ["present_characters_by_location"]
