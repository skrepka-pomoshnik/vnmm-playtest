"""Seeded NPC geography, ambient presence, and short non-blocking barks.

NPC movement deliberately does not use the gameplay RNG.  A position is a
pure function of the saved seed and the current calendar point, so rollback
and replay reproduce the same encounter without shifting an exam roll.
"""

from functools import lru_cache

from ..constants import PRESENCE_LABELS
from ..models import GameState

FUNDAMENTAL_SUBJECTS = frozenset(("algebra", "matan", "geometry"))

MOVING_CHARACTERS = (
    "kolya",
    "pasha",
    "shuler",
    "rai",
    "misha",
    "serge",
    "sasha",
    "nil",
    "kuzmenko",
    "djug",
    "andrew",
    "grisha",
)

# Subject fingerprints are intentionally asymmetric.  They describe where a
# person is likely to follow a class, not a new attendance subsystem.
MODERN_FOLLOW_SUBJECTS: dict[str, frozenset[str]] = {
    "pasha": frozenset(("algebra", "matan", "geometry")),
    "sasha": frozenset(("algebra", "matan", "geometry", "english")),
    "kolya": frozenset(("algebra", "matan", "geometry")),
    "shuler": frozenset(("informatics",)),
    "rai": frozenset(("algebra", "matan")),
    "misha": frozenset(("english", "pe")),
    "serge": frozenset(("pe", "informatics")),
    "kuzmenko": frozenset(("informatics", "geometry")),
    "djug": frozenset(("geometry", "algebra")),
    "andrew": frozenset(("matan", "geometry")),
    "nil": frozenset(("english", "informatics")),
    "grisha": frozenset(("english", "pe")),
}

# The fallback route is a weighted preference, not a fixed schedule.  The
# route is later adjusted for the time of day and the day's appointments.
MODERN_ROUTES: dict[str, tuple[tuple[str, int], ...]] = {
    "pasha": (("faculty", 5), ("dorm", 2), ("pomi", 1), ("mausoleum", 1)),
    "sasha": (("faculty", 4), ("dorm", 3), ("mausoleum", 2), ("pomi", 1)),
    "kolya": (("mausoleum", 6), ("pomi", 2), ("faculty", 1)),
    "shuler": (("computer_lab", 7), ("faculty", 2), ("dorm", 1)),
    "rai": (("faculty", 4), ("computer_lab", 3), ("pomi", 1), ("dorm", 1)),
    "misha": (("dorm", 4), ("faculty", 2), ("pomi", 2), ("mausoleum", 1)),
    "serge": (("faculty", 3), ("mausoleum", 2), ("dorm", 2), ("pomi", 1)),
    "kuzmenko": (("computer_lab", 6), ("faculty", 3), ("dorm", 1)),
    "djug": (("pomi", 5), ("faculty", 2), ("mausoleum", 1)),
    "andrew": (("faculty", 3), ("computer_lab", 2), ("pomi", 1), ("dorm", 1)),
    "nil": (("faculty", 3), ("pomi", 2), ("computer_lab", 1), ("mausoleum", 1)),
    "grisha": (("mausoleum", 3), ("computer_lab", 2), ("faculty", 2), ("dorm", 1)),
}


@lru_cache(maxsize=16384)
def _movement_prefix_value(
    seed: int,
    day: int,
    slot: int,
    hour: int,
    minute: int,
) -> int:
    """Hash the calendar prefix once before applying a movement key.

    Presence queries ask for many named rolls at the same calendar point.  The
    complete payload intentionally remains the same FNV-1a stream as before;
    only its reusable prefix is cached.  This keeps movement deterministic
    while avoiding repeated formatting/encoding of the date for QA samplers
    and frequently redrawn planner screens.
    """

    value = 2166136261
    for byte in f"{seed}:{day}:{slot}:{hour}:{minute}:".encode("ascii"):
        value ^= byte
        value = (value * 16777619) & 0xFFFFFFFF
    return value


def movement_roll(state: GameState, key: str, sides: int) -> int:
    """Return a stable pseudo-random roll for NPC geography.

    This is a separate deterministic stream.  It must never call the RNG
    supplied to gameplay reducers: changing who happens to be in a hallway
    must not change an exam or travel roll later in the same route.
    """

    if sides <= 0:
        raise ValueError("movement roll sides must be positive")
    # FNV-1a over a small ASCII key is stable across processes and Python
    # versions, unlike the built-in hash().  Classic movement is sampled on
    # its source-compatible hourly clock; modern movement reacts to the exact
    # minute on the continuous clock.
    minute = 0 if state.calendar_mode == "hourly" else state.minute
    value = _movement_prefix_value(state.seed, state.day, state.slot, state.hour, minute)
    for byte in key.encode("ascii"):
        value ^= byte
        value = (value * 16777619) & 0xFFFFFFFF
    return value % sides


def _current_day_appointments(state: GameState) -> tuple:
    return tuple(appointment for appointment in state.schedule if appointment.day == state.day)


def _current_appointments_anywhere(state: GameState) -> tuple:
    appointments = _current_day_appointments(state)
    if state.calendar_mode == "hourly":
        return tuple(
            appointment
            for appointment in appointments
            if appointment.start_hour is not None
            and appointment.end_hour is not None
            and appointment.start_hour <= state.hour < appointment.end_hour
        )
    current_minute = state.hour * 60 + state.minute
    return tuple(
        appointment
        for appointment in appointments
        if appointment.start_minute <= current_minute < appointment.end_minute
    )


def _appointment_location(
    appointments: tuple,
    subjects: frozenset[str],
) -> str | None:
    for appointment in appointments:
        if appointment.subject in subjects:
            return appointment.location
    return None


def _classic_wander(
    state: GameState,
    character: str,
    subjects: tuple[str, ...],
    base: str,
) -> str:
    """Mirror the source's ``wander`` fingerprints without its RNG side effects."""

    location = base
    appointments = _current_day_appointments(state)
    for index, subject in enumerate(subjects):
        subject_appointments = tuple(
            appointment for appointment in appointments if appointment.subject == subject
        )
        if (
            subject_appointments
            and movement_roll(
                state,
                f"classic:wander:{character}:{index}:{subject}",
                10,
            )
            > 5
        ):
            location = subject_appointments[-1].location
    return location


def _classic_npc_locations(state: GameState) -> dict[str, str]:
    """Return source-shaped NPC positions for the hourly classic profile."""

    daylight = 8 < state.hour < 20
    social_base = "faculty" if daylight else "dorm"
    locations = {
        # ``neighbor`` is a modern project character, not a source NPC.
        "kolya": "mausoleum" if daylight else "dorm",
        "pasha": _classic_wander(state, "pasha", ("algebra", "matan", "geometry"), social_base),
        "shuler": "computer_lab" if daylight else "dorm",
        "misha": _classic_wander(
            state, "misha", ("english", "geometry", "matan", "algebra"), social_base
        ),
        "serge": _classic_wander(
            state,
            "serge",
            ("pe", "informatics", "geometry", "matan", "algebra", "english"),
            social_base,
        ),
        "sasha": (
            "faculty"
            if daylight and movement_roll(state, "classic:sasha:faculty", 4) == 0
            else "dorm"
        ),
        "nil": _classic_wander(state, "nil", ("algebra", "matan", "geometry"), "dorm"),
        "kuzmenko": (
            "computer_lab"
            if daylight and movement_roll(state, "classic:kuzmenko:computer_lab", 4) == 0
            else "dorm"
        ),
        "djug": "pomi",
        "andrew": "faculty",
        "grisha": (
            "mausoleum" if movement_roll(state, "classic:grisha:mausoleum", 3) == 0 else "dorm"
        ),
    }

    current = _current_appointments_anywhere(state)
    active_algebra = _appointment_location(current, frozenset(("algebra",)))
    active_matan = _appointment_location(current, frozenset(("matan",)))
    locations["rai"] = active_algebra or active_matan or ("computer_lab" if daylight else "dorm")
    return locations


@lru_cache(maxsize=128)
def _modern_route_options_cached(
    day: int,
    slot: int,
    hour: int,
    character: str,
) -> tuple[tuple[str, int], ...]:
    weights = {location: weight for location, weight in MODERN_ROUTES[character]}
    if slot == 0:
        weights["faculty"] = weights.get("faculty", 0) + 1
        weights["computer_lab"] = weights.get("computer_lab", 0) + 1
    if hour >= 19 or hour < 4:
        weights["dorm"] = weights.get("dorm", 0) + 2
        weights["mausoleum"] = weights.get("mausoleum", 0) + 1
    if day >= 5:
        weights["faculty"] = weights.get("faculty", 0) + 1
    return tuple(weights.items())


def _modern_route_options(state: GameState, character: str) -> tuple[tuple[str, int], ...]:
    """Return route weights, reusing the calendar-only calculation."""

    return _modern_route_options_cached(state.day, state.slot, state.hour, character)


def _weighted_route(
    state: GameState,
    character: str,
    options: tuple[tuple[str, int], ...],
) -> str:
    total = sum(weight for _, weight in options)
    pick = movement_roll(state, f"modern:route:{character}", total)
    for location, weight in options:
        if pick < weight:
            return location
        pick -= weight
    return options[-1][0]


def _modern_npc_location(
    state: GameState,
    character: str,
    active: tuple,
    today: tuple,
) -> str:
    if character == "neighbor":
        return "dorm"

    follow_subjects = MODERN_FOLLOW_SUBJECTS[character]
    current_location = _appointment_location(active, follow_subjects)
    if current_location is not None:
        focused = character in {"pasha", "rai"}
        follow_chance = 100 if focused else 78 if character in {"shuler", "kuzmenko"} else 58
        if movement_roll(state, f"modern:current:{character}", 100) < follow_chance:
            return current_location

    # A person can head toward the next relevant class before it starts, but
    # this is deliberately weaker than following a class already in progress.
    next_location = _appointment_location(today, follow_subjects)
    if next_location is not None and movement_roll(state, f"modern:next:{character}", 100) < 22:
        return next_location
    return _weighted_route(state, character, _modern_route_options(state, character))


def npc_locations(
    state: GameState,
    *,
    active: tuple | None = None,
    today: tuple | None = None,
) -> tuple[tuple[str, str], ...]:
    """Return the full seeded geography used by presence and encounters."""

    if state.calendar_mode == "hourly":
        locations = _classic_npc_locations(state)
    else:
        active = _current_appointments_anywhere(state) if active is None else active
        today = _current_day_appointments(state) if today is None else today
        locations = {
            character: _modern_npc_location(state, character, active, today)
            for character in MOVING_CHARACTERS
        }
        locations["neighbor"] = "dorm"
    return tuple(
        (character, locations[character])
        for character in ("neighbor", *MOVING_CHARACTERS)
        if character in locations
    )


def _presence_priority(
    state: GameState,
    character: str,
    active: tuple | None = None,
) -> tuple[int, int]:
    """Return ordering priority, reusing an already computed active window."""

    if character == "neighbor" and state.location == "dorm":
        return -1, 0
    if active is None:
        active = _current_appointments_anywhere(state)
    follows = MODERN_FOLLOW_SUBJECTS.get(character, frozenset())
    relevant = 0 if _appointment_location(active, follows) is not None else 1
    order = ("neighbor", *MOVING_CHARACTERS).index(character)
    return relevant, order


# Each location has a four-window rotation. The day offsets the rotation so a
# player does not see the same pair in the same place every day.
PRESENCE_ROTATION: dict[str, tuple[tuple[str, ...], ...]] = {
    "dorm": (
        ("neighbor", "sasha"),
        ("neighbor", "misha"),
        ("neighbor", "pasha"),
        ("neighbor", "serge"),
    ),
    "faculty": (
        ("pasha", "rai"),
        ("sasha", "andrew"),
        ("kuzmenko", "djug"),
        ("nil", "serge"),
    ),
    "pomi": (
        ("kolya", "djug"),
        ("rai", "andrew"),
        ("sasha", "kuzmenko"),
        ("pasha", "djug"),
    ),
    "computer_lab": (
        ("shuler", "kuzmenko"),
        ("misha", "grisha"),
        ("shuler", "andrew"),
        ("kuzmenko", "nil"),
    ),
    "mausoleum": (
        ("kolya", "serge"),
        ("grisha", "nil"),
        ("kolya", "pasha"),
        ("misha", "rai"),
    ),
}


BARK_POOL: dict[str, tuple[str, ...]] = {
    "neighbor": (
        "В комнате тихо. Все спорят о расписании в коридоре.",
        "Если пойдёшь на факультет, захвати мою кружку у Сержа.",
        "Я поставил чайник. Вода общая, сахар, кажется, Пашин.",
        "Будильник на завтра завёл? Сначала проверь, какой завтра день.",
        "Два зачёта закрыл. Поэтому сегодня лежу и никому не мешаю.",
        "В душ записываются на двери. Я поставил тебя после человека без фамилии.",
    ),
    "pasha": (
        "Я оставил копию списка на Баобабе. Сверь время перед выходом.",
        "До обеда два окна. В одно ещё можно успеть без электрички.",
        "Десять рублей на дорогу оставь отдельно, а то опять всё съешь.",
        "Зачётка при тебе? Покажи карман, я тебе уже не верю.",
        "Кто-то опять переписал расписание. Почерк тот же, время другое.",
        "Я обещал передать деньги Саше. Если увидишь его, напомни мне, пожалуйста.",
        "Ручку возьму на минуту. Вернуть могу забыть, так что напомни сразу.",
        "Три фамилии на два места. Сейчас узнаю, у кого есть другое окно.",
        "На Баобабе теперь новый список. Старый тоже мой, но по нему уже никто никуда не успеет.",
    ),
    "sasha": (
        "Нужная теорема на сорок седьмой странице. Я отметил угол карандашом.",
        "Здесь потеряно условие. Остальное пока не переписывай.",
        "Конспект возьми до вечера. Завтра он нужен мне самому.",
        "В старой записи лишняя строка. Хочу сначала сверить её с лекцией.",
        "Если садишься, придержи этот край. От окна страницы листает.",
        "Моя синяя ручка опять у кого-то. Если найдёшь, просто положи на тетрадь.",
        "Возле окна страницы отсырели. Приходится придерживать их ладонью.",
        "Я помню номер аудитории, но не помню, на каком листе его записал.",
        "Это третья копия конспекта. Условие потерялось, зато здесь разборчивее номер электрички.",
    ),
    "kolya": (
        "В Мавзолее два супа осталось. Один я уже взял.",
        "Покажи условие. Решение потом.",
        "Очередь кончилась. Преподаватель пока здесь.",
        "Если денег мало, бери чай. Суп сегодня шесть.",
        "Алгебру можно вечером. Преподавателя — только сейчас.",
        "В Мавзолее сегодня очередь до двери. Можно подождать, если есть чем.",
        "Дай другую ручку. Эта перестала писать на знаке равенства.",
        "Сначала закончу его задачу. Моя лежит под кружкой.",
        "Под тарелкой мой черновик. Если принесут суп, переложи его под чужой.",
    ),
    "shuler": (
        "Курсор мигает. Ввода программа не ждёт — я проверил.",
        "В каталоге есть файл на завтра. Сегодняшний создался позже.",
        "Расписание я не правил. Сохранил копию и сравнил строки.",
        "Дискету кто-то переложил. В журнале этого действия нет.",
        "После финального экрана программа снова открывает меню. Так не было задумано.",
        "Не вытаскивай дискету, пока горит лампочка. Второй копии пока нет.",
        "На свободной машине табличка «НЕ РАБОТАЕТ». Вчера она была на соседней.",
        "Если компьютер завис, сначала запиши, что ты нажал. Потом можно перезагружать.",
        "Кузьменко спрашивал, кто опять оставил файл без расширения.",
        "Вентилятор шумит громче обычного. Если погаснет экран, позови меня.",
        "Принтер выдал три пустых листа. Не выбрасывай: сначала выясню, чей файл.",
    ),
    "rai": (
        "У меня просьба по третьей задаче. Сначала посмотри один переход.",
        "Если объяснишь начало, дальше я допишу сам.",
        "Мы делим работу. Я хочу заранее договориться, кто потом объясняет.",
        "Ты сегодня занят? Тогда скажи сразу, я найду другого человека.",
        "На листе два почерка. Второй автор сейчас отошёл за мелом.",
        "Тетрадь одна на троих. Если забираешь, оставь хотя бы условие.",
    ),
    "nil": (
        "За вторую задачу могу заплатить сейчас. Объяснение обсудим отдельно.",
        "Мне нужен ход решения. Ответ у меня уже есть, и он подозрительный.",
        "Сначала покажи, где ошибка. Если быстро, успеем до очереди.",
        "Я помню, кому должна. Паша записал на обороте списка.",
        "Если просто поговорить, денег не дам. Чай могу купить.",
        "За десять рублей мне нужен ход решения, а не настроение автора.",
    ),
    "misha": (
        "Сначала реши, что важнее до обеда. После обеда пересчитаем.",
        "Можно сыграть одну партию. Ровно одну, я засеку.",
        "Положение плохое, но ход ещё есть. Покажи расписание.",
        "Ты не понял задачу, ты просто устал на неё смотреть.",
        "До ПОМИ два маршрута. Запасной длиннее, зато без пересадки.",
        "На кухне опять спорят из-за сахара. Это уже второй конфликт за сегодня.",
        "В электричке можно читать два часа. Главное — выйти раньше, чем конспект станет интересным.",
    ),
    "serge": (
        "Принимающего по информатике видели утром. Кто видел, уже ушёл.",
        "Кефир возьми. Когда руки дрожат, определения всё равно не читаются.",
        "Прокси снова работает. Адрес запиши на бумагу.",
        "Очередь движется. Если собираешься есть, попроси подержать место.",
        "Я знаю дорогу через парк. После дождя там придётся идти медленнее.",
        "На улице теплее, чем в аудитории. Для физры это ничего не меняет.",
        "В Сачке чай, в Мавзолее очередь. Выбирай по тому, сколько у тебя осталось времени.",
    ),
    "kuzmenko": (
        "Преподаватель был здесь утром. В пятницу попробуйте прийти до девяти.",
        "Дополнительное окно записали карандашом. Перепишите себе время.",
        "Список кабинетов старый. Спросите у дежурного, прежде чем идти наверх.",
        "Файл называется «старое», но исправляли его сегодня.",
        "Спросите у человека за третьей машиной. Он эту ошибку уже видел.",
        "У третьей машины список. Верхней строке не верьте, её писали до перерыва.",
    ),
    "djug": (
        "Рисунок аккуратный. Теперь покажите, где этот объект дан в условии.",
        "Говорите медленнее. Уверенность не заменяет обоснование перехода.",
        "Проверьте, принадлежит ли эта точка множеству. На рисунке это не видно.",
        "Нужная аудитория наверху. Эта лестница ведёт только до второго этажа.",
        "У вас получился частный случай. Общий пока не называйте.",
        "Чужая пометка на полях не является частью условия, даже если написана уверенно.",
    ),
    "andrew": (
        "Я почти понял. Подожди, объясню с начала, где именно почти.",
        "Решение есть. Теперь нужен комментарий к третьей строке.",
        "Я думаю вслух. Если мешает, скажи — буду говорить тише.",
        "Поставь сегодняшнюю дату. Этот лист ещё будут передавать.",
        "Решение длиннее условия, потому что я дважды начал сначала.",
        "Я взял лист у NiL на пять минут. Четыре уже прошли.",
        "У меня три черновика. В каждом есть хороший переход, но пока не один и тот же.",
    ),
    "grisha": (
        "В ТЕРКОМе нужна смена. Платят двадцать, сидеть придётся до вечера.",
        "Ксерокс сегодня работает. Бумагу лучше принести свою.",
        "Бесплатный чай остался в Сачке. Кружку бери отсюда.",
        "Деньги на зачёт не влияют. На билет до города — вполне.",
        "За компьютером сейчас свободное место. Работа там тоже найдётся.",
        "В Сачке остался чай. Если Мавзолей далеко, этого иногда достаточно.",
        "Ксерокс жуёт последний лист. Если это твой конспект, запоминай сейчас.",
    ),
    "mantra": (
        "Я почти закончил разбор случая. Саму теорему пока не обещаю.",
        "У меня был карандаш. Посмотри под листами, я не хочу их снова смешивать.",
        "Сегодня обедал. Кофе не считается, поэтому пришлось вспомнить.",
        "Большую часть листа зачеркнул. Контрпример всё равно остался.",
        "Мне нужен Паша. Хочу сверить дату на этой странице.",
        "Пишу карандашом. После вчерашнего доказательства так быстрее исправлять.",
        "В старой копии доказательство полнее, зато последняя страница от другого предмета.",
    ),
}


GARLIC_BARKS: dict[str, tuple[str, ...]] = {
    "neighbor": (
        "Ты чеснок ел? Я не осуждаю, просто дверь открыта.",
        "Запах до кухни дошёл раньше тебя. Это новый вид расписания.",
    ),
    "pasha": (
        "Список расписания можно сверять, а запах — пока нет.",
        "До следующего окна запах должен уйти. Если нет, садись подальше от людей.",
    ),
    "sasha": (
        "Я бы дала тебе конспект, но сначала проветрим листы.",
        "Это не новая теорема. Просто очень уверенный чеснок.",
    ),
    "kolya": (
        "В Мавзолее чеснок никого не удивляет. Но ты постарайся не спорить с очередью.",
        "Запах хороший. Для зачёта бесполезный, для супа — наоборот.",
    ),
    "serge": (
        "На физкультуре запах выветривается быстрее. Бежать всё равно придётся.",
        "Не задерживай дыхание на разминке. Это уже другая тактика.",
    ),
}


NPC_CONVERSATION_FOLLOWUP_BARKS: dict[str, dict[str, tuple[str, ...]]] = {
    "pasha_serge": {
        "pasha": ("Серж опять спорит с секундомером. Значит, день ещё можно поправить.",),
        "serge": ("Паша нашёл твой маршрут? Он теперь у меня на обороте списка.",),
    },
    "sasha_rai": {
        "sasha": ("Рай всё ещё считает, что объяснение можно начать с третьей строки.",),
        "rai": ("Саша оставил мне страницу. Верну её до следующего окна.",),
    },
    "shuler_kuzmenko": {
        "shuler": ("Кузьменко записал имя файла. Теперь его хотя бы можно искать.",),
        "kuzmenko": ("Шулер опять проверяет дату файла. Я ещё раз сверю список кабинетов.",),
    },
    "kolya_grisha": {
        "kolya": ("Гриша считает смену отдыхом. Я считаю суп.",),
        "grisha": ("Коля обещал задачу. Сначала дождусь, пока он доест.",),
    },
    "andrew_nil": {
        "andrew": ("NiL взяла мой черновик на пять минут. Прошло уже четыре.",),
        "nil": ("Эндрю опять начал объяснение с места, где у меня кончается лист.",),
    },
    "pasha_student": {
        "pasha": (
            "Студент записал матан. Теперь осталось выяснить, в какой аудитории он его сдаёт.",
        ),
    },
    "sasha_kolya": {
        "sasha": ("Коля вернул тетрадь. На нужной странице теперь пятно от чая.",),
        "kolya": ("Саша знает, где лежит тетрадь. Я знаю, под какой газетой она лежит.",),
    },
    "djug_student": {
        "djug": ("Студент снова спрашивает, кто последний. Вопрос стал точнее.",),
    },
}


def present_characters(state: GameState, include_mantra: bool = False) -> tuple[str, ...]:
    """Return people whose seeded positions put them in this location.

    The screen intentionally shows at most three names, but the full
    geography remains available through :func:`npc_locations`.  This keeps
    crowd size readable while ensuring that an encounter is a consequence of
    movement rather than a second unrelated random selector.
    """

    return dict(present_characters_by_location(state, include_mantra=include_mantra)).get(
        state.location, ()
    )


def present_characters_by_location(
    state: GameState, include_mantra: bool = False
) -> tuple[tuple[str, tuple[str, ...]], ...]:
    """Return the batched presence query without importing the query module eagerly."""

    from .queries import present_characters_by_location as batch_query

    return batch_query(state, include_mantra=include_mantra)


def get_bark(
    character: str,
    day: int,
    state: GameState,
    include_mantra: bool = False,
    previous: str | None = None,
    visible: tuple[str, ...] | None = None,
) -> str:
    """Return one context-valid deterministic bark for the current presence."""

    current_presence = (
        visible if visible is not None else present_characters(state, include_mantra=include_mantra)
    )
    if character not in current_presence:
        return "Сейчас этого человека здесь нет."

    options = None
    for conversation_id, character_barks in NPC_CONVERSATION_FOLLOWUP_BARKS.items():
        if state.has_flag(f"npc_conversation_{conversation_id}_seen") and not state.has_flag(
            f"npc_followup_{conversation_id}_seen"
        ):
            options = character_barks.get(character)
            if options:
                break

    # A callback describes a specific earlier conversation, so it has
    # priority over generic mishap context for this one delivery.
    if not options:
        if character == "neighbor" and state.has_flag("mishap_martyshkino_seen"):
            return "Ты вчера во сколько вернулся? Мартышкино? Зачем?"
        if character == "pasha" and state.has_flag("mishap_martyshkino_seen"):
            return "Ты вчера окно пропустил. Причину в список не записываю."
        if character == "grisha" and state.has_flag("mishap_remiz_seen"):
            return "На Ремиз уехал? Бывает."
        if character == "kolya" and state.has_flag("mishap_remiz_seen"):
            return "Ты вчера не пришёл. Заячий Ремиз? Далеко."

    if not options:
        options = GARLIC_BARKS.get(character) if state.has_flag("garlic_smell") else None
    if not options:
        options = BARK_POOL.get(character)
    if not options:
        return "Сейчас разговора не получается."

    if previous in options and len(options) > 1:
        options = tuple(option for option in options if option != previous)

    context_shift = state.inception * 13
    if state.health <= 20:
        context_shift += 1
    if state.has_debt(character):
        context_shift += 2
    if state.has_flag("has_disk"):
        context_shift += 3
    index = (state.seed + day * 11 + state.slot * 7 + context_shift) % len(options)
    return options[index]


__all__ = [
    "BARK_POOL",
    "GARLIC_BARKS",
    "MODERN_FOLLOW_SUBJECTS",
    "MODERN_ROUTES",
    "MOVING_CHARACTERS",
    "NPC_CONVERSATION_FOLLOWUP_BARKS",
    "PRESENCE_LABELS",
    "PRESENCE_ROTATION",
    "get_bark",
    "movement_roll",
    "npc_locations",
    "present_characters",
    "present_characters_by_location",
]
