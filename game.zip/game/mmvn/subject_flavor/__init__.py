"""Small subject-related selectors that affect domain outcomes, not prose."""

from __future__ import annotations

from ..models import GameState

FAIRY_OUTCOMES = ("money", "brain", "transfer", "nothing", "garlic")
EXAM_ATTEMPT_OUTCOMES = (
    "clean_success",
    "success_with_cost",
    "fail-forward",
    "ordinary_not_passed",
)


def exam_attempt_outcome(
    subject: str,
    before: GameState,
    after: GameState,
    tactic: str = "as_is",
) -> str:
    """Classify a scheduled exam into one of four authored outcome bands.

    The ordinary attempt cost does not make a success costly. Extra tactic,
    health, or lost-opportunity costs do. Failed attempts advance when they
    retain task or knowledge progress, or when a weak preparation explicitly
    identifies a remaining gap. ``hard_fail`` remains exclusive to
    self-contained computer quests.
    """

    from mmvn.rules.domain.exams.exam_beats import exam_challenge_outcome
    from mmvn.rules.domain.exams.exam_projection import english_exam_tactic_spec

    after_progress = after.subject(subject)
    if after_progress is None:
        return "ordinary_not_passed"

    challenge_outcome = exam_challenge_outcome(before, subject)
    if after_progress.passed:
        tactic_spec = english_exam_tactic_spec(tactic)
        effective_tactic = tactic_spec.base_tactic if tactic_spec is not None else tactic
        pending_applies = before.pending_exam_subject == subject
        extra_cost = (
            effective_tactic != "as_is"
            or (
                pending_applies
                and (before.pending_exam_health_cost > 0 or before.pending_exam_penalty > 0)
            )
            or challenge_outcome in {"cost", "fail-forward"}
        )
        return "success_with_cost" if extra_cost else "clean_success"

    before_progress = before.subject(subject)
    retained_progress = before_progress is not None and (
        after_progress.tasks_done > before_progress.tasks_done
        or after_progress.knowledge > before_progress.knowledge
    )
    if retained_progress or challenge_outcome == "fail-forward":
        return "fail-forward"
    return "ordinary_not_passed"


def english_fairy_outcome(state: GameState) -> str:
    """Pick the optional English after-effect without global randomness."""

    index = (state.seed + state.day * 7 + state.slot * 3 + state.inception) % len(FAIRY_OUTCOMES)
    return FAIRY_OUTCOMES[index]


__all__ = (
    "EXAM_ATTEMPT_OUTCOMES",
    "FAIRY_OUTCOMES",
    "english_fairy_outcome",
    "exam_attempt_outcome",
)
