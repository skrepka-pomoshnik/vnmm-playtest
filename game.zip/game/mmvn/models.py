"""Immutable data structures shared by the Ren'Py adapter and tests."""

from collections.abc import Mapping
from dataclasses import dataclass, field, replace

from .constants import (
    CHARACTERS,
    HERO_TYPE_LABELS,
    MAX_HEALTH,
    MAX_KNOWLEDGE,
    MAX_STAMINA,
    REQUIRED_TASKS,
    SLOT_HOURS,
    SUBJECTS,
)


@dataclass(frozen=True)
class Stats:
    health: int = 65
    brain: int = 6
    stamina: int = 6
    charisma: int = 6
    money: int = 0

    def __post_init__(self) -> None:
        object.__setattr__(self, "health", min(MAX_HEALTH, max(0, self.health)))
        object.__setattr__(self, "brain", max(0, self.brain))
        object.__setattr__(self, "stamina", min(MAX_STAMINA, max(0, self.stamina)))
        object.__setattr__(self, "charisma", max(0, self.charisma))
        object.__setattr__(self, "money", max(0, self.money))


@dataclass(frozen=True)
class SubjectProgress:
    subject: str
    knowledge: int = 0
    tasks_done: int = 0
    passed: bool = False
    passed_day: int | None = None
    has_notes: bool = False
    # ``None`` means that a caller did not select a profile explicitly.  It is
    # a construction-time modern default, not a migration path for old saves.
    task_limit: int | None = None
    # Classic knowledge is intentionally wider than the modern six-point HUD.
    # ``None`` keeps the ordinary modern construction default.
    knowledge_limit: int | None = None

    def __post_init__(self) -> None:
        knowledge_limit = (
            self.knowledge_limit if self.knowledge_limit is not None else MAX_KNOWLEDGE
        )
        if knowledge_limit <= 0:
            raise ValueError("knowledge limit must be positive")
        knowledge = min(knowledge_limit, max(0, self.knowledge))
        task_limit = (
            self.task_limit if self.task_limit is not None else REQUIRED_TASKS.get(self.subject, 0)
        )
        if task_limit < 0:
            raise ValueError("task limit must not be negative")
        tasks_done = min(task_limit, max(0, self.tasks_done))
        object.__setattr__(self, "knowledge", knowledge)
        object.__setattr__(self, "knowledge_limit", self.knowledge_limit)
        object.__setattr__(self, "tasks_done", tasks_done)
        passed = bool(self.passed and tasks_done >= task_limit)
        object.__setattr__(self, "passed", passed)
        if not passed:
            object.__setattr__(self, "passed_day", None)
        elif self.passed_day is not None:
            object.__setattr__(self, "passed_day", max(1, self.passed_day))

    @property
    def required_tasks(self) -> int:
        """Return the profile-specific limit or the modern default."""

        task_limit = getattr(self, "task_limit", None)
        return task_limit if task_limit is not None else REQUIRED_TASKS.get(self.subject, 0)


@dataclass(frozen=True)
class RelationshipState:
    character: str
    trust: int = 0
    debt: int = 0
    irritation: int = 0


@dataclass(frozen=True)
class TabletRecord:
    """One end-of-week result recorded on the in-game board.

    Results are gameplay progress, so they live in ``GameState`` and travel in
    ordinary saves. Keeping them here instead of in ``persistent`` means a
    board only ever shows the current playthrough.
    """

    ending: str
    score: int
    passed: int
    day: int
    inception: int
    seed: int
    passed_days: tuple[tuple[str, int], ...] = ()

    def as_row(self) -> dict[str, object]:
        return {
            # The player character remains unnamed and is addressed directly.
            "name": "Вы",
            "ending": self.ending,
            "score": self.score,
            "passed": self.passed,
            "day": self.day,
            "inception": self.inception,
            "seed": self.seed,
            "passed_days": dict(self.passed_days),
        }


@dataclass(frozen=True)
class Appointment:
    subject: str
    day: int
    slot: int
    location: str
    teacher: str
    required_tasks: int
    start_hour: int | None = None
    end_hour: int | None = None
    # Modern authored appointments can begin halfway through a presentation
    # band.  Keep the hour fields for classic/source rows, but retain the
    # exact minute at the boundary for the continuous clock.
    start_minute_offset: int = 0
    end_minute_offset: int = 0

    @property
    def hour(self) -> int:
        """Return the hour at which the appointment starts."""

        return self.start_minute // 60

    @property
    def start_minute(self) -> int:
        """Return the absolute minute of the appointment's start."""

        hour = self.start_hour if self.start_hour is not None else SLOT_HOURS[self.slot]
        return hour * 60 + self.start_minute_offset

    @property
    def end_minute(self) -> int:
        """Return the exclusive absolute minute of the appointment's end."""

        if self.end_hour is not None:
            return self.end_hour * 60 + self.end_minute_offset
        if self.slot + 1 < len(SLOT_HOURS):
            return SLOT_HOURS[self.slot + 1] * 60
        return 24 * 60


def default_subjects(
    task_requirements: Mapping[str, int] | None = None,
    knowledge_limit: int | None = None,
) -> tuple[SubjectProgress, ...]:
    """Create subject progress with optional profile-specific task limits."""

    return tuple(
        SubjectProgress(
            subject=subject,
            task_limit=None if task_requirements is None else task_requirements[subject],
            knowledge_limit=knowledge_limit,
        )
        for subject in SUBJECTS
    )


def default_relationships() -> tuple[RelationshipState, ...]:
    return tuple(RelationshipState(character=character) for character in CHARACTERS)


@dataclass(frozen=True)
class GameState:
    day: int = 1
    slot: int = 0
    minute_offset: int = 0
    # Modern sessions use the one continuous minute clock.  ``hourly`` is
    # reserved for the source-compatible classic ruleset.
    calendar_mode: str = "continuous"
    clock_hour: int | None = None
    location: str = "dorm"
    hero_type: str = "universal"
    stats: Stats = field(default_factory=Stats)
    subjects: tuple[SubjectProgress, ...] = field(default_factory=default_subjects)
    schedule: tuple[Appointment, ...] = ()
    relationships: tuple[RelationshipState, ...] = field(default_factory=default_relationships)
    event_flags: frozenset[str] = frozenset()
    debts: tuple[str, ...] = ()
    notes: frozenset[str] = frozenset()
    group_score: int = 0
    memory_shards: int = 0
    inception: int = 0
    schedule_variant: str = "A"
    work_shifts: int = 0
    pomi_ticket_uses: int = 0
    reserve_all: bool = False
    ending_tags: frozenset[str] = frozenset()
    # Results of this playthrough only. Stored as records rather than dicts so
    # the state stays hashable, rollback-safe and save-safe.
    tablets: tuple[TabletRecord, ...] = ()
    sleep_debt: bool = False
    garlic_windows: int = 0
    # Exact remaining duration of the temporary garlic status.  The old
    # ``garlic_windows`` field remains in its original position for alpha
    # construction compatibility; gameplay never decrements it.
    garlic_minutes: int = 0
    reserve_subject: str | None = None
    note_subject: str | None = None
    pending_exam_subject: str | None = None
    pending_exam_bonus: int = 0
    pending_exam_penalty: int = 0
    pending_exam_health_cost: int = 0
    last_exam_subject: str | None = None
    seed: int = 220508
    last_health_cause: str = "exhaustion"
    # Consecutive study sessions since the last actual change of location.
    # Appended fields preserve old positional construction and get safe
    # defaults when an older save is loaded.
    study_streak: int = 0
    fresh_air_required: bool = False
    # Temporary study edge from a brain-sharpening drink. Decided 02.10.2026:
    # coffee used to raise `brain` permanently, and since the study gain keyed
    # off `brain >= 7` a single 2-RUB drink doubled every later session for the
    # rest of the week, while 8-RUB beer undid it. The boost is now counted in
    # study sessions instead, so it always expires. Appended with a safe default
    # for older saves.
    study_boost_sessions: int = 0
    # Source MMHEROES marks the computer as unavailable after a failed
    # TERKOM allocation until the next hour.  Keep that bit in the immutable
    # state so classic runs can reproduce the same local loop.
    terkom_free: bool = True
    # Three short, optional exam beats belong to the realistic presentation
    # layer.  They are cleared when the corresponding attempt is resolved.
    exam_challenge_subject: str | None = None
    exam_challenge_step: int = 0
    exam_challenge_score: int = 0
    # Absolute minute timestamp (state_absolute_minutes) of the player's last meal.
    # None indicates no meal consumed yet. Prevents infinite eating loops within cooldown.
    last_meal_at: int | None = None

    def __post_init__(self) -> None:
        if self.day < 1:
            raise ValueError("day must be positive")
        if not 0 <= self.slot < len(SLOT_HOURS):
            raise ValueError("slot must be a valid daily window")
        if self.minute_offset < 0:
            raise ValueError("minute offset must not be negative")
        if self.calendar_mode not in {"continuous", "hourly"}:
            raise ValueError("calendar mode must be continuous or hourly")
        if self.clock_hour is not None and not 0 <= self.clock_hour < 24:
            raise ValueError("clock hour must be between 00:00 and 23:00")
        # ``clock_hour`` and the minute component are the canonical position
        # for both profiles.  Constructors written before the continuous
        # clock migration may still pass an offset relative to a four-window
        # slot; normalize that representation once at the boundary.
        clock_hour = self.clock_hour
        raw_minute = self.minute_offset
        if (
            clock_hour is None
            or raw_minute >= 60
            or (clock_hour in SLOT_HOURS and self.slot != self._hourly_slot(clock_hour))
        ):
            clock_hour = SLOT_HOURS[self.slot] + raw_minute // 60
        day_delta, clock_hour = divmod(clock_hour, 24)
        object.__setattr__(self, "day", self.day + day_delta)
        object.__setattr__(self, "clock_hour", clock_hour)
        object.__setattr__(self, "slot", self._hourly_slot(clock_hour))
        object.__setattr__(self, "minute_offset", raw_minute % 60)
        if self.hero_type not in HERO_TYPE_LABELS:
            raise ValueError("unknown hero type")
        object.__setattr__(self, "group_score", max(0, self.group_score))
        object.__setattr__(self, "memory_shards", max(0, self.memory_shards))
        object.__setattr__(self, "inception", max(0, self.inception))
        garlic_minutes = max(0, self.garlic_minutes)
        if not garlic_minutes and self.garlic_windows:
            # Alpha-only construction compatibility.  Reducers write the
            # exact field from this point onward.
            garlic_minutes = self.garlic_windows * 60
        object.__setattr__(self, "garlic_minutes", garlic_minutes)
        object.__setattr__(self, "garlic_windows", max(0, self.garlic_windows))
        object.__setattr__(self, "work_shifts", max(0, self.work_shifts))
        object.__setattr__(self, "pomi_ticket_uses", max(0, self.pomi_ticket_uses))
        object.__setattr__(self, "pending_exam_bonus", max(0, self.pending_exam_bonus))
        object.__setattr__(self, "pending_exam_penalty", max(0, self.pending_exam_penalty))
        object.__setattr__(self, "pending_exam_health_cost", max(0, self.pending_exam_health_cost))
        object.__setattr__(self, "study_streak", max(0, self.study_streak))
        object.__setattr__(self, "fresh_air_required", bool(self.fresh_air_required))
        object.__setattr__(self, "study_boost_sessions", max(0, self.study_boost_sessions))
        object.__setattr__(self, "terkom_free", bool(self.terkom_free))
        if self.exam_challenge_subject is not None and self.exam_challenge_subject not in SUBJECTS:
            raise ValueError("unknown exam challenge subject")
        if not 0 <= self.exam_challenge_step <= 3:
            raise ValueError("exam challenge step must be between zero and three")
        if not 0 <= self.exam_challenge_score <= 6:
            raise ValueError("exam challenge score must be between zero and six")
        if self.exam_challenge_subject is None and (
            self.exam_challenge_step or self.exam_challenge_score
        ):
            raise ValueError("exam challenge progress requires a subject")

    @property
    def health(self) -> int:
        return self.stats.health

    @property
    def hour(self) -> int:
        """Return the current hour on the single continuous clock."""

        return self.clock_hour if self.clock_hour is not None else SLOT_HOURS[self.slot]

    @property
    def minute(self) -> int:
        """Return the exact minute within the current hour."""

        return self.minute_offset % 60

    @property
    def slot_label(self) -> str:
        return f"{self.hour:02d}:{self.minute:02d}"

    @staticmethod
    def _hourly_slot(hour: int) -> int:
        if 8 <= hour < 11:
            return 0
        if 11 <= hour < 15:
            return 1
        if 15 <= hour < 19:
            return 2
        return 3

    @property
    def brain(self) -> int:
        return self.stats.brain

    @property
    def stamina(self) -> int:
        return self.stats.stamina

    @property
    def charisma(self) -> int:
        return self.stats.charisma

    @property
    def money(self) -> int:
        return self.stats.money

    @property
    def passed_count(self) -> int:
        return sum(progress.passed for progress in self.subjects)

    @property
    def nested_runs(self) -> int:
        """Compatibility alias for the legacy HUD."""

        return self.inception

    def subject(self, name: str) -> SubjectProgress | None:
        for progress in self.subjects:
            if progress.subject == name:
                return progress
        return None

    def with_subject(self, updated: SubjectProgress) -> "GameState":
        subjects = tuple(
            updated if progress.subject == updated.subject else progress
            for progress in self.subjects
        )
        return replace(self, subjects=subjects)

    def relationship(self, character: str) -> RelationshipState | None:
        for relation in self.relationships:
            if relation.character == character:
                return relation
        return None

    def with_canonical_relationships(self) -> "GameState":
        """Back-fill canonical characters missing from a loaded save.

        Adding a character to ``CHARACTERS`` changes the save schema.  Older
        saves would otherwise fail ``state_invariant_errors`` and any code
        reaching for the new relationship would get ``None``.  Filling the gap
        with a default relationship is gameplay-neutral: the character did not
        exist in that playthrough yet.  Existing relationships keep their order
        and values, and nothing is removed.
        """

        present = {relation.character for relation in self.relationships}
        if present.issuperset(CHARACTERS):
            return self
        known = tuple(
            relation for relation in self.relationships if relation.character in CHARACTERS
        )
        extra = tuple(
            relation for relation in self.relationships if relation.character not in CHARACTERS
        )
        missing = tuple(
            RelationshipState(character=character)
            for character in CHARACTERS
            if character not in present
        )
        return replace(self, relationships=known + missing + extra)

    def with_relationship(self, updated: RelationshipState) -> "GameState":
        relationships = tuple(
            updated if relation.character == updated.character else relation
            for relation in self.relationships
        )
        return replace(self, relationships=relationships)

    def has_flag(self, flag: str) -> bool:
        return flag in self.event_flags

    def with_flag(self, flag: str) -> "GameState":
        return replace(self, event_flags=self.event_flags | frozenset((flag,)))

    def has_note(self, subject: str) -> bool:
        return subject in self.notes

    def with_note(self, subject: str) -> "GameState":
        return replace(self, notes=self.notes | frozenset((subject,)))

    def with_ending_tag(self, tag: str) -> "GameState":
        return replace(self, ending_tags=self.ending_tags | frozenset((tag,)))

    def with_debt(self, debt: str) -> "GameState":
        if debt in self.debts:
            return self
        return replace(self, debts=(*self.debts, debt))

    def without_debt(self, debt: str) -> "GameState":
        return replace(self, debts=tuple(item for item in self.debts if item != debt))

    def has_debt(self, debt: str) -> bool:
        return debt in self.debts
