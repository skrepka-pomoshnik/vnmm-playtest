"""State-dependent dream system calculating nighttime reflection from daily pressure."""

from collections.abc import Sequence
from dataclasses import dataclass

from .models import GameState


@dataclass(frozen=True)
class DreamDefinition:
    id: str
    tier: int
    tags: tuple[str, ...]
    weight: int = 1


DREAM_REGISTRY: tuple[DreamDefinition, ...] = (
    DreamDefinition("train_quiet", tier=0, tags=("peaceful", "train", "sasha"), weight=3),
    DreamDefinition("mausoleum_soup", tier=0, tags=("peaceful", "mausoleum", "kolya"), weight=3),
    DreamDefinition("baobab_schedule", tier=1, tags=("pasha", "schedule", "absurd"), weight=3),
    DreamDefinition("train_horse", tier=1, tags=("train", "conductor", "absurd"), weight=3),
    DreamDefinition("imaginary_i", tier=1, tags=("math", "lecture", "absurd"), weight=2),
    DreamDefinition("last_theorem", tier=2, tags=("lecture", "train", "sasha", "time"), weight=3),
    DreamDefinition("cold_auditorium", tier=2, tags=("cold", "math", "sasha"), weight=3),
    DreamDefinition("service_train", tier=2, tags=("train", "pasha", "time"), weight=3),
    DreamDefinition("pe_no_judge", tier=2, tags=("pe", "serge", "sport"), weight=3),
    DreamDefinition("exam_ticket", tier=3, tags=("exam", "failure", "math"), weight=4),
    DreamDefinition("exam_queue_years", tier=3, tags=("queue", "pomi", "time"), weight=3),
    DreamDefinition("printer_exam", tier=3, tags=("computer", "diamond", "failure"), weight=3),
    DreamDefinition("empty_faculty", tier=3, tags=("faculty", "lonely", "time"), weight=3),
    DreamDefinition(
        "train_no_stop", tier=4, tags=("train", "conductor", "loop", "fever"), weight=4
    ),
    DreamDefinition("all_exams", tier=4, tags=("exam", "pasha", "teachers", "fever"), weight=4),
    DreamDefinition(
        "baobab_grows", tier=4, tags=("baobab", "schedule", "kolya", "fever"), weight=4
    ),
    DreamDefinition(
        "theorem_never_ends", tier=4, tags=("lecture", "math", "train", "fever"), weight=4
    ),
    DreamDefinition("sasha_notebook", tier=1, tags=("sasha", "notes", "personal"), weight=2),
    DreamDefinition("kolya_debt", tier=1, tags=("kolya", "debt", "personal"), weight=2),
    DreamDefinition("pasha_schedules", tier=1, tags=("pasha", "schedule", "personal"), weight=2),
    DreamDefinition("mantra_proof", tier=1, tags=("mantra", "logic", "personal"), weight=2),
    DreamDefinition("gamma_replay", tier=3, tags=("inception", "glitch", "loop"), weight=3),
)


def calculate_dream_pressure(
    state: GameState,
    slept_hour: int = 0,
    forced_sleep: bool = False,
    passed_today: int = 0,
    failed_today: int = 0,
    study_streak: int = 0,
    mishap_occurred: bool = False,
) -> int:
    """Calculate psychological and physical dream pressure on a 0..4 scale."""
    pressure = 0
    if slept_hour >= 24 or slept_hour < 6:
        pressure += 1
    if slept_hour >= 26 or (2 <= slept_hour < 6):
        pressure += 1
    if forced_sleep:
        pressure += 2
    if state.health < 40:
        pressure += 1
    if state.health < 20:
        pressure += 1
    if failed_today >= 1:
        pressure += 1
    if failed_today >= 2:
        pressure += 1
    if study_streak >= 3:
        pressure += 1
    if mishap_occurred:
        pressure += 1
    if passed_today >= 1:
        pressure -= 1
    if passed_today >= 2:
        pressure -= 1
    return max(0, min(4, pressure))


def select_dream(
    state: GameState,
    pressure: int,
    seen_dreams: Sequence[str] = (),
    context_tags: Sequence[str] = (),
    rng_seed: int = 0,
) -> str:
    """Deterministically select a dream matching the tier and daily context."""
    if (
        state.inception >= 2
        and (state.seed + state.day) % 4 == 0
        and "gamma_replay" not in seen_dreams
    ):
        return "gamma_replay"

    eligible = [
        d
        for d in DREAM_REGISTRY
        if abs(d.tier - pressure) <= 1 and d.id not in seen_dreams and d.id != "gamma_replay"
    ]
    if not eligible:
        eligible = [d for d in DREAM_REGISTRY if d.id != "gamma_replay"]

    scored_candidates: list[tuple[int, str]] = []
    for d in eligible:
        score = d.weight
        for tag in context_tags:
            if tag in d.tags:
                score += 3
        scored_candidates.append((score, d.id))

    total = sum(score for score, _ in scored_candidates)
    roll = (state.seed * 31 + state.day * 17 + state.slot * 13 + rng_seed + pressure * 7) % total
    current = 0
    selected_id = scored_candidates[0][1]
    for score, dream_id in scored_candidates:
        current += score
        if roll < current:
            selected_id = dream_id
            break
    return selected_id
