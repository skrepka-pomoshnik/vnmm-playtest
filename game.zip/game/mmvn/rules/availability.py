"""WORLD-01: one allowed / reason / cost / duration answer per action.

The planner, story labels and the AI playtester must use this resolver
instead of duplicating checks with separate ``if`` statements. Every branch
repeats the guard of the matching reducer in the same order and with the
same denial text, so ``allowed == True`` means calling the reducer with the
same arguments returns ``ok``.

Boundaries:
- The check never mutates state and never spends RNG.
- The reducers' "pass an explicit RNG" requirements are not repeated here:
  Ren'Py, tests and lab always pass RNG explicitly per the project rule.
- Stochastic effect sizes (controller damage, classic rolls) are not
  predicted; only deterministic money and time are previewed.
"""

from __future__ import annotations

from dataclasses import dataclass

from mmvn.balance import STUDY_FRESH_AIR_STREAK, resolve_balance_profile
from mmvn.constants import STUDY_LOCATIONS, SUBJECTS
from mmvn.models import GameState
from mmvn.schedule import current_appointments
from mmvn.time_budget import state_absolute_minutes

from .domain.exams import (
    english_exam_tactic_spec,
    exam_projection,
    field_standing_shortfall,
)
from .domain.time import (
    _sleep_end_absolute,
    cafe_open_now,
    food_options,
    mausoleum_open_now,
    meal_cooldown_active,
    meal_cooldown_remaining,
)
from .helpers_state import _study_streak, require_gradebook, task_requirement

__all__ = (
    "ActionAvailability",
    "check_action",
)


@dataclass(frozen=True)
class ActionAvailability:
    """One availability answer about an action for UI, story and playtester."""

    allowed: bool
    reason: str
    money_cost: int
    duration_minutes: int


def _deny(reason: str) -> ActionAvailability:
    return ActionAvailability(allowed=False, reason=reason, money_cost=0, duration_minutes=0)


def _allow(money_cost: int = 0, duration_minutes: int = 0) -> ActionAvailability:
    return ActionAvailability(
        allowed=True, reason="", money_cost=money_cost, duration_minutes=duration_minutes
    )


def _action_minutes(selected, key: str) -> int:
    knob = selected.duration.action(key)
    return knob.minutes if knob is not None else 60


def _check_study(state: GameState, selected, subject: str | None) -> ActionAvailability:
    progress = state.subject(subject) if subject else None
    if progress is None or subject not in SUBJECTS:
        return _deny("Такого предмета нет в учебном плане.")
    if progress.passed:
        return _deny("Этот предмет уже закрыт.")
    if state.location not in STUDY_LOCATIONS:
        return _deny("Здесь невозможно нормально заниматься.")
    if state.health <= 0:
        return _deny("Герой уже не может учиться.")
    if selected.calendar_mode == "hourly":
        if state.location != "dorm":
            return _deny("В классическом режиме готовятся в общаге.")
    elif (
        getattr(state, "fresh_air_required", False)
        and _study_streak(state) >= STUDY_FRESH_AIR_STREAK
    ):
        return _deny("Голова ватная после зубрёжки: сначала нужна прогулка в другую локацию.")
    return _allow(duration_minutes=_action_minutes(selected, "study"))


def _check_night_study(state: GameState, selected, subject: str | None) -> ActionAvailability:
    if not (state.hour >= 19 or state.hour < 4):
        return _deny("Ночная зубрёжка доступна после 19:00.")
    return _check_study(state, selected, subject)


def _check_rest(state: GameState, selected, venue: str | None) -> ActionAvailability:
    venue = venue or "dorm"
    if selected.calendar_mode == "hourly":
        if venue not in {"dorm", "mausoleum"}:
            return _deny("В классическом режиме отдыхают в общаге или Мавзолее.")
        if venue == "dorm" and state.location != "dorm":
            return _deny("Отдыхать в комнате можно только в общежитии.")
        if venue == "mausoleum" and state.location != "mausoleum":
            return _deny("Коля отдыхает только в Мавзолее.")
        return _allow(duration_minutes=_action_minutes(selected, "rest"))
    try:
        selected.rest_gain(venue)
    except KeyError:
        return _deny("Такого варианта отдыха нет.")
    if venue == "dorm" and state.location != "dorm":
        return _deny("Отдыхать в комнате можно только в общежитии.")
    if venue == "mausoleum" and state.location != "mausoleum":
        return _deny("Коля отдыхает только в Мавзолее.")
    if venue == "cafe" and state.location != "mausoleum":
        return _deny("Кафе находится в Мавзолее.")
    if venue == "cafe" and not cafe_open_now(state):
        return _deny("Комплексный обед подают с 10:00 до 18:00.")
    if venue == "serge" and not state.has_flag("serge_help_available"):
        return _deny("Помощь Сержа сейчас недоступна.")
    if venue == "cafe" and state.money < selected.rest_cafe_cost:
        return _deny(f"В кафе не хватает {selected.rest_cafe_cost} рублей.")
    dorm_rest_flag = f"dorm_rest_used:{state.day}"
    if venue == "dorm" and state.has_flag(dorm_rest_flag):
        return _deny("Сегодня отдых в общаге уже использован.")
    action_key = "rest:dorm" if venue == "dorm" else "rest"
    money = selected.rest_cafe_cost if venue == "cafe" else 0
    return _allow(money_cost=money, duration_minutes=_action_minutes(selected, action_key))


def _check_food(state: GameState, selected, item_id: str | None) -> ActionAvailability:
    option = next(
        (candidate for candidate in food_options(state, selected) if candidate.item_id == item_id),
        None,
    )
    if option is None:
        return _deny("Здесь нет такого варианта еды.")
    if (
        selected.calendar_mode != "hourly"
        and state.location == "mausoleum"
        and not mausoleum_open_now(state)
    ):
        return _deny("Мавзолей закрыт. Часы работы: с 10:00 до 18:00.")
    if selected.calendar_mode != "hourly" and item_id != "sit" and meal_cooldown_active(state):
        remaining = meal_cooldown_remaining(state)
        return _deny(f"Герой ещё не проголодался (сыт ещё {remaining} мин.).")
    if state.money < option.cost:
        return _deny(f"На {option.label.lower()} не хватает {option.cost} рублей.")
    return _allow(money_cost=option.cost, duration_minutes=_action_minutes(selected, "food"))


def _check_sleep(state: GameState, selected) -> ActionAvailability:
    if state.location != "dorm":
        return _deny("Спать до утра можно только в общежитии.")
    if selected.calendar_mode == "hourly":
        if state.day >= 6:
            return _allow()
        if 3 < state.hour < 20:
            return _deny("Тебя чего-то не тянет по-спать днём.")
        return _allow(duration_minutes=_action_minutes(selected, "sleep"))
    if 4 <= state.hour < 19:
        return _deny("Сейчас ещё не время ложиться спать.")
    sleep_knob = selected.duration.action("sleep")
    configured = sleep_knob.minutes if sleep_knob is not None else 8 * 60
    minutes = _sleep_end_absolute(state, configured) - state_absolute_minutes(state)
    return _allow(duration_minutes=minutes)


def _check_travel(
    state: GameState, selected, destination: str | None, mode: str
) -> ActionAvailability:
    if not destination:
        return _deny("Не выбрано место назначения.")
    if destination not in dict(selected.travel_fares):
        return _deny("Такого места нет на карте.")
    if destination == state.location:
        return _allow()
    minutes = selected.duration.travel_duration(state.location, destination)
    if minutes is None:
        minutes = _action_minutes(selected, "travel")
    if selected.calendar_mode == "hourly":
        if destination == "pomi" and state.hour > 20:
            return _deny("ПОМИ уже закрывается: ехать туда поздно.")
        if destination == "pomi":
            if mode not in {"ticket", "stowaway"}:
                return _deny("Неизвестный способ поездки в ПОМИ.")
            money = 10 if mode == "ticket" and state.money >= 10 else 0
            return _allow(money_cost=money, duration_minutes=minutes)
        if state.location == "pomi":
            if state.pomi_ticket_uses:
                return _allow(duration_minutes=minutes)
            if state.money >= 5 and mode == "ticket":
                return _allow(money_cost=5, duration_minutes=minutes)
            if mode == "stowaway":
                return _allow(duration_minutes=minutes)
            return _deny("На обратный билет из ПОМИ нужно 5 ₽.")
        return _allow(duration_minutes=minutes)
    if destination != "pomi" and mode != "ticket":
        return _deny("Особый способ поездки доступен только до ПОМИ.")
    if destination == "pomi" and mode not in {"ticket", "stowaway"}:
        return _deny("Неизвестный способ поездки в ПОМИ.")
    if mode == "stowaway":
        return _allow(duration_minutes=minutes)
    fare = selected.travel_fare(destination)
    if state.pomi_ticket_uses and (destination == "pomi" or state.location == "pomi"):
        fare = 0
    if state.money < fare:
        return _deny("Не хватает денег на дорогу.")
    return _allow(money_cost=fare, duration_minutes=minutes)


def _check_work(state: GameState, selected, option_id: str | None) -> ActionAvailability:
    if state.location != "faculty":
        return _deny("Работа в ТЕРКОМе начинается на факультете.")
    if not state.has_flag("terkom_unlocked"):
        return _deny("Сначала нужно поговорить с Гришей.")
    try:
        option = selected.work_option(option_id)
    except KeyError:
        return _deny("Такого варианта смены сейчас нет.")
    return _allow(duration_minutes=_action_minutes(selected, option.duration_key))


def _check_internet(state: GameState, selected, outcome: str | None) -> ActionAvailability:
    if state.location != "computer_lab":
        return _deny("Интернет доступен только в компьютерном классе.")
    if not state.has_flag("has_internet"):
        return _deny("Сначала нужно поговорить с Гришей.")
    if selected.calendar_mode == "hourly":
        if outcome not in {"classic", "informatics", "memory"}:
            return _deny("В классическом режиме Inet предлагает одну услугу.")
        return _allow(duration_minutes=_action_minutes(selected, "internet"))
    outcome_flags = {
        "informatics": "internet_informatics_used",
        "memory": "internet_memory_used",
        "schedule": "internet_schedule_used",
    }
    if outcome not in outcome_flags:
        return _deny("Неизвестный результат интернет-сцены.")
    if state.has_flag(outcome_flags[outcome]):
        return _deny("Этот результат уже проверен через интернет.")
    return _allow(duration_minutes=_action_minutes(selected, "internet"))


def _check_nested(state: GameState, selected) -> ActionAvailability:
    if state.location != "computer_lab":
        return _deny("Дискету можно запустить только в компьютерном классе.")
    if not state.has_flag("has_disk"):
        return _deny("Для запуска нужна дискета Шулера.")
    if state.inception >= 2:
        return _deny("Следующий запуск возможен только в финальной сцене.")
    if state.inception == 1 and state.day < 5:
        return _deny("Второй запуск доступен только с пятого дня.")
    return _allow(duration_minutes=_action_minutes(selected, "nested"))


def _check_mmheroes(state: GameState, selected) -> ActionAvailability:
    if state.location != "computer_lab":
        return _deny("Компьютерные программы доступны только в компьютерном классе.")
    return _allow(duration_minutes=_action_minutes(selected, "nested"))


def _check_final(state: GameState, selected) -> ActionAvailability:
    if state.inception != 2 or state.day < 6 or not state.has_flag("has_disk"):
        return _deny("Финальный запуск доступен только на шестом дне после двух запусков.")
    return _allow(duration_minutes=_action_minutes(selected, "nested"))


def _check_wait(state: GameState, selected) -> ActionAvailability:
    return _allow(duration_minutes=_action_minutes(selected, "wait"))


def _check_exam(state: GameState, selected, subject: str | None, tactic: str) -> ActionAvailability:
    if selected.calendar_mode == "hourly":
        if tactic != "as_is":
            return _deny("В классическом режиме тактики зачёта отсутствуют.")
        progress = state.subject(subject) if subject else None
        if progress is None or progress.passed:
            return _deny("Этот зачёт уже закрыт.")
        if subject not in tuple(appointment.subject for appointment in current_appointments(state)):
            return _deny("Преподаватель сейчас не принимает этот предмет.")
        try:
            selected.subject_difficulty(subject)
        except KeyError:
            return _deny("Такого предмета нет в классическом расписании.")
        return _allow(duration_minutes=_action_minutes(selected, "exam"))
    progress = state.subject(subject) if subject else None
    if progress is None or subject is None:
        return _deny("Такого предмета нет в учебном плане.")
    if progress.passed:
        return _deny("Этот зачёт уже закрыт.")
    blocked = require_gradebook(state)
    if blocked is not None:
        return _deny(blocked.message)
    if subject == "informatics" and not state.has_flag("informatics_teacher_found"):
        return _deny("Сначала нужно найти преподавателя информатики.")
    tactic_spec = english_exam_tactic_spec(tactic) if subject == "english" else None
    effective_tactic = tactic_spec.base_tactic if tactic_spec is not None else tactic
    if tactic_spec is not None and state.charisma < tactic_spec.charisma_required:
        return _deny("Для такого устного ответа нужна большая уверенность в разговоре.")
    if subject == "english" and tactic.startswith("english_") and tactic_spec is None:
        return _deny("Неизвестный формат ответа по английскому.")
    appointments = tuple(
        appointment for appointment in current_appointments(state) if appointment.subject == subject
    )
    if not appointments:
        return _deny("Преподаватель сейчас не принимает этот предмет.")
    if appointments[0].required_tasks != task_requirement(state, subject):
        return _deny("Требование зачёта расходится между расписанием и планом предмета.")
    shortfall = field_standing_shortfall(state)
    if shortfall > 0:
        # The top band is bought with people, and it asks for a different shape
        # of network at each step, so the refusal names the missing shape.
        return _deny(
            f"Пятый зачёт открывают двое знакомых: не хватает ещё {shortfall}."
            if state.passed_count == 4
            else f"Шестой зачёт открывает один, кому ты доверяешь дважды: не хватает {shortfall}."
        )
    projection = exam_projection(state, subject, 0, selected)
    if projection is None:
        return _deny("Для этого предмета не удалось построить прогноз.")
    if tactic not in {"as_is", "push", "talk"} and tactic_spec is None:
        return _deny("Неизвестная тактика зачёта.")
    if effective_tactic == "push" and not projection.can_push:
        return _deny("Дожим недоступен при здоровье 12 и ниже.")
    if effective_tactic == "talk" and not projection.can_talk:
        return _deny("Преподавателя нельзя разговорить с текущей харизмой.")
    return _allow(duration_minutes=_action_minutes(selected, "exam"))


def check_action(
    state: GameState,
    action: str,
    *,
    profile=None,
    subject: str | None = None,
    venue: str | None = None,
    item_id: str | None = None,
    destination: str | None = None,
    mode: str = "ticket",
    option_id: str | None = None,
    outcome: str | None = None,
    tactic: str = "as_is",
) -> ActionAvailability:
    """Answer allowed / reason / cost / duration for one player action.

    ``action`` is a stable ASCII id: ``study``, ``night_study``, ``rest``,
    ``sleep``, ``food``, ``travel``, ``work``, ``internet``, ``nested``,
    ``mmheroes``, ``final``, ``wait`` or ``exam``.  Extra parameters select
    the variant exactly like the matching reducer arguments.
    """

    selected = resolve_balance_profile(profile)
    if action == "study":
        return _check_study(state, selected, subject)
    if action == "night_study":
        return _check_night_study(state, selected, subject)
    if action == "rest":
        return _check_rest(state, selected, venue)
    if action == "sleep":
        return _check_sleep(state, selected)
    if action == "food":
        return _check_food(state, selected, item_id)
    if action == "travel":
        return _check_travel(state, selected, destination, mode)
    if action == "work":
        return _check_work(state, selected, option_id)
    if action == "internet":
        return _check_internet(state, selected, outcome)
    if action == "nested":
        return _check_nested(state, selected)
    if action == "mmheroes":
        return _check_mmheroes(state, selected)
    if action == "final":
        return _check_final(state, selected)
    if action == "wait":
        return _check_wait(state, selected)
    if action == "exam":
        return _check_exam(state, selected, subject, tactic)
    return _deny(f"Неизвестное действие: {action}.")
