"""Social scene reducers."""

from __future__ import annotations

from mmvn.balance import BalanceProfile
from mmvn.models import GameState
from mmvn.rules.types import ActionResult
from mmvn.time_budget import format_duration

from . import context as _ctx


def resolve_pasha_schedule(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("pasha_schedule_seen"):
        return _ctx._fail(state, "Паша уже объяснил, что происходит с расписаниями.")
    next_state = state.with_flag("pasha_schedule_seen")
    if choice == "share":
        next_state = _ctx._change_trust(next_state, "pasha", 1)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(next_state, "Паша записал наблюдения. Общая схема стала чуть честнее.")
    if choice == "ticket":
        selected = _ctx.resolve_balance_profile(profile)
        ticket_count = selected.pasha_ticket_grant
        next_state = _ctx.replace(
            next_state,
            pomi_ticket_uses=next_state.pomi_ticket_uses + ticket_count,
        )
        if ticket_count:
            return _ctx._ok(next_state, "Паша выдал два билета в ПОМИ.")
        return _ctx._ok(
            next_state,
            "Паша записал просьбу о билете, но в классической версии билетов нет.",
        )
    if choice == "self":
        return _ctx._ok(next_state, "Паша кивнул. Самоспасение тоже числится в расписании.")
    return _ctx._fail(state, "Неизвестный вариант разговора с Пашей.")


def resolve_social_evening(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("social_evening_seen"):
        return _ctx._fail(state, "Социальное окно этой недели уже прошло.")
    if state.slot != 3:
        return _ctx._fail(state, "Социальный вечер начинается после семи.")
    if not _ctx.social_event_available_at(state):
        return _ctx._fail(state, "Эта встреча проходит в другой локации.")
    next_state = state.with_flag("social_evening_seen")
    if choice == "hour":
        next_state = _ctx._advance_action(next_state, "scene:social_evening:hour", profile)
        next_state = _ctx._change_stats(next_state, health=-4, charisma=1, health_cause="social")
        next_state = next_state.with_flag("social_evening_attended")
        return _ctx._ok(next_state, "Один час социальной жизни: −4 здоровья, +1 харизма.")
    if choice == "full":
        next_state = _ctx._advance_action(next_state, "scene:social_evening:full", profile)
        next_state = _ctx._change_stats(
            next_state, health=-8, charisma=2, brain=-1, health_cause="social"
        )
        next_state = next_state.with_flag("social_evening_attended")
        return _ctx._ok(next_state, "Вечер затянулся: −8 здоровья, +2 харизма, −1 мозги.")
    if choice == "refuse":
        next_state = _ctx._grant_study_boost(next_state)
        return _ctx._ok(
            next_state,
            "Герой вернулся к конспекту; следующие три занятия дадут по одному лишнему знанию.",
        )
    return _ctx._fail(state, "Неизвестный вариант социальной жизни.")


def resolve_voluntary_quit(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if choice != "confirm":
        return _ctx._fail(state, "Сессию можно завершить только после подтверждения.")
    if state.has_flag("voluntary_quit"):
        return _ctx._fail(state, "Эта сессия уже завершена добровольно.")
    return _ctx._ok(
        state.with_flag("voluntary_quit"),
        "Герой закрыл зачётку и добровольно завершил сессию.",
    )


def resolve_pasha_intro(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("pasha_intro_seen"):
        return _ctx._fail(state, "Паша уже получил ответ на этот вопрос.")
    next_state = state.with_flag("pasha_intro_seen")
    if choice == "thanks":
        return _ctx._ok(
            _ctx._change_trust(next_state, "pasha", 1),
            "Паша принял благодарность и оставил расписание на столе.",
        )
    if choice == "schedule":
        return _ctx._ok(next_state, "Паша показал расписание. Оно уже выглядит временным.")
    if choice == "money":
        return _ctx._ok(
            _ctx._change_stats(next_state, charisma=1),
            "Паша оставил деньги. Харизма выросла на единицу за правильный вопрос.",
        )
    return _ctx._fail(state, "Неизвестный ответ на стипендию.")


def resolve_pasha_collision(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("pasha_collision_seen"):
        return _ctx._fail(state, "Паша уже предупредил о коллизии резервного окна.")
    next_state = state.with_flag("pasha_collision_seen")
    if choice == "group":
        next_state = _ctx._change_trust(next_state, "pasha", 1)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(next_state, "Паша добавил наблюдение в общую таблицу.")
    if choice == "self":
        return _ctx._ok(next_state, "Паша оставил личную строку открытой до завтра.")
    if choice == "ignore":
        return _ctx._ok(next_state, "Коллизия записана. Бумага умеет ждать лучше студента.")
    return _ctx._fail(state, "Неизвестный ответ на предупреждение Паши.")


def resolve_misha(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("misha_seen"):
        return _ctx._fail(state, "Миша уже выдал свою стратегию.")
    next_state = state.with_flag("misha_seen")
    if choice == "play":
        selected = _ctx.resolve_balance_profile(profile)
        next_state = _ctx._advance_action(next_state, "scene:misha:play", selected)
        play_knob = selected.duration.action("scene:misha:play")
        play_duration = format_duration(play_knob.minutes) if play_knob else "короткую партию"
        # CHAR-01: the opening game is the first of up to three meetings.
        # Recording the choice lets the evening callback react to it.
        next_state = _ctx._change_trust(next_state, "misha", 1).with_flag("misha_played")
        return _ctx._ok(
            _ctx._change_stats(next_state, health=5, charisma=1),
            f"Партия длилась {play_duration} и вернула пять здоровья и одну харизму.",
        )
    if choice == "rules":
        next_state = _ctx._advance_action(next_state, "scene:misha:rules", profile)
        return _ctx._ok(next_state, "Миша объяснил правила: здоровье важнее красивого плана.")
    if choice == "decline":
        return _ctx._ok(
            next_state, "Миша пожал плечами. Отдых можно пропустить, но это тоже решение."
        )
    return _ctx._fail(state, "Неизвестный вариант разговора с Мишей.")


def resolve_misha_rematch(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    """Close the Misha arc: a rematch that can turn a friend into a helper.

    The closure is reachable only after the introduction and the evening
    callback.  Trust 2 makes Misha eligible for exam-crowd help through the
    existing presence/trust filter, so the payoff opens a variant instead
    of granting a bare resource.
    """

    if state.has_flag("misha_closure_seen"):
        return _ctx._fail(state, "Реванш с Мишей уже состоялся.")
    if not state.has_flag("misha_seen"):
        return _ctx._fail(state, "Сначала нужно познакомиться с Мишей.")
    if not state.has_flag("misha_callback_seen"):
        return _ctx._fail(state, "Миша ещё не звал на реванш.")
    if state.location != "dorm":
        return _ctx._fail(state, "Миша ждёт с ракетками в общежитии.")
    next_state = state.with_flag("misha_closure_seen")
    if choice == "play":
        next_state = _ctx._change_trust(next_state, "misha", 1)
        return _ctx._ok(
            next_state,
            "Реванш состоялся. Миша теперь болеет за героя и на зачётах.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Герой отложил реванш. Миша не обиделся, но партию закрыли.")
    return _ctx._fail(state, "Неизвестный вариант реванша с Мишей.")


def resolve_travel_dogs(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if choice == "garages":
        return _ctx._ok(state, "Стая осталась у платформы. Обход будет учтён отдельно.")
    if choice == "brave":
        if state.stamina >= 5:
            return _ctx._ok(state, "Герой прошёл напролом, не тратя ещё одну остановку.")
        return _ctx._ok(
            _ctx._change_stats(state, health=-8, health_cause="travel_dogs").with_flag(
                "mishap_dogs_hurt"
            ),
            "Герой прошёл напролом, но получил 8 урона.",
        )
    return _ctx._fail(state, "Неизвестный способ пройти мимо собак.")


def resolve_kolya_intro(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("kolya_met"):
        return _ctx._fail(state, "Коля уже представился Мавзолею.")
    if choice == "drink":
        if state.money < 15:
            return _ctx._fail(state, "Для разговора с Колей не хватает 15 рублей.")
        next_state = _ctx._change_stats(state, money=-15, health=-5, health_cause="alcohol")
        next_state = _ctx._change_trust(next_state, "kolya", 1).with_flag("kolya_met")
        return _ctx._ok(
            next_state,
            "Коля принял напиток и признал тебя участником распределённых вычислений.",
        )
    if choice == "sober":
        if state.charisma < 6:
            return _ctx._fail(state, "Трезвый разговор требует харизмы 6.")
        next_state = _ctx._change_trust(state, "kolya", 1).with_flag("kolya_met")
        return _ctx._ok(next_state, "Коля согласился говорить без технологического ускорителя.")
    if choice == "leave":
        return _ctx._ok(
            state.with_flag("kolya_intro_skipped"), "Мавзолей сохранил твоё лицо в очереди."
        )
    return _ctx._fail(state, "Неизвестный вариант разговора с Колей.")


def resolve_grisha(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("grisha_met"):
        return _ctx._fail(state, "Гриша уже открыл доступы.")
    next_state = state.with_flag("grisha_met")
    if choice == "job":
        return _ctx._ok(
            _ctx._change_trust(next_state.with_flag("terkom_unlocked"), "grisha", 1),
            "Гриша записал тебя в смену ТЕРКОМа.",
        )
    if choice == "internet":
        return _ctx._ok(
            next_state.with_flag("has_internet"),
            "Гриша продиктовал прокси. Бумага стала стратегическим ресурсом.",
        )
    if choice == "both":
        if state.charisma < 8:
            return _ctx._fail(state, "Получить работу и интернет сразу можно при харизме 8.")
        return _ctx._ok(
            _ctx._change_trust(
                next_state.with_flag("terkom_unlocked").with_flag("has_internet"), "grisha", 1
            ),
            "Гриша открыл и смену, и прокси. Сегодня система щедра.",
        )
    if choice == "no":
        return _ctx._ok(next_state, "Гриша ушёл искать менее самостоятельного клиента.")
    return _ctx._fail(state, "Неизвестный вариант разговора с Гришей.")


def resolve_kolya_debt(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if not state.has_debt("kolya"):
        return _ctx._fail(state, "У Коли нет открытого долга.")
    if state.has_flag("kolya_debt_scene_seen"):
        return _ctx._fail(state, "Долг Коли уже разбирали на этой неделе.")
    next_state = state.with_flag("kolya_debt_scene_seen")
    if choice == "help":
        next_state = _ctx._change_stats(next_state, health=-8, health_cause="exhaustion")
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(
            _ctx._change_trust(next_state, "kolya", 1)
            .without_debt("kolya")
            .with_flag("kolya_debt_paid"),
            "Долг Коле закрыт здоровьем и одной услугой.",
        )
    if choice == "rai":
        if not state.has_flag("rai_helped"):
            return _ctx._fail(state, "Передать долг Раю можно только после знакомства с ним.")
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(
            _ctx._change_trust(next_state, "kolya", 1)
            .without_debt("kolya")
            .with_flag("kolya_debt_paid"),
            "Рай принял задачу. Долг Коли стал коллективным.",
        )
    if choice == "refuse":
        return _ctx._ok(
            _ctx._change_irritation(
                _ctx._change_trust(next_state, "kolya", -1), "kolya", 2
            ).with_flag("kolya_debt_unpaid"),
            "Коля записал отказ. Долг останется в эпилоге.",
        )
    return _ctx._fail(state, "Неизвестный вариант возврата долга Коли.")


def resolve_terkom_offer(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("terkom_offer_seen"):
        return _ctx._fail(state, "Предложение ТЕРКОМа уже разобрано.")
    if state.work_shifts < 1:
        return _ctx._fail(state, "Предложение ТЕРКОМа появляется только после настоящей смены.")
    next_state = state.with_flag("terkom_offer_seen")
    if choice == "accept":
        next_state = next_state.with_flag("terkom_accepted").with_flag("grisha_arc_closed")
        return _ctx._ok(
            _ctx._change_trust(next_state, "grisha", 1),
            "ТЕРКОМ принял тебя раньше ведомости. Гриша поставил галочку в табеле.",
        )
    if choice == "wait":
        return _ctx._ok(
            next_state.with_flag("terkom_offer").with_flag("grisha_offer_waiting"),
            "ТЕРКОМ оставил предложение до конца недели.",
        )
    if choice == "decline":
        return _ctx._ok(
            next_state.with_flag("terkom_offer_declined").with_flag("grisha_arc_declined"),
            "ТЕРКОМ записал отказ в свободную строку.",
        )
    return _ctx._fail(state, "Неизвестный вариант предложения ТЕРКОМа.")


def resolve_pasha_reserve(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("pasha_reserve_seen"):
        return _ctx._fail(state, "Резервное окно уже распределено.")
    if choice == "group":
        next_state = _ctx._change_stats(state, health=-5, health_cause="organizing")
        next_state = _ctx._change_trust(next_state, "pasha", 1)
        next_state = _ctx.replace(
            next_state, group_score=next_state.group_score + 1, reserve_all=True
        )
        return _ctx._ok(
            next_state.with_flag("pasha_reserve_seen"), "Паша собрал общее резервное окно."
        )
    if choice == "self":
        if subject not in ("algebra", "matan", "geometry", "informatics", "english", "pe"):
            return _ctx._fail(state, "Для личного резерва нужен предмет.")
        return _ctx._ok(
            _ctx.replace(state, reserve_subject=subject).with_flag("pasha_reserve_seen"),
            "Паша закрепил резерв за выбранным предметом.",
        )
    if choice == "shuler":
        if state.inception < 1:
            return _ctx._fail(state, "Шулер вмешивается в резерв только после первого запуска.")
        return _ctx._ok(
            state.with_flag("second_run_requested").with_flag("pasha_reserve_seen"),
            "Паша оставил резерв Шулеру. Это уже не административное решение.",
        )
    return _ctx._fail(state, "Неизвестный вариант резервного окна.")


def resolve_morning_pasha(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("morning_pasha_seen"):
        return _ctx._fail(state, "Паша уже вернул утреннюю услугу.")
    return _ctx._ok(
        _ctx.replace(state, reserve_all=True).with_flag("morning_pasha_seen"),
        "Паша подтвердил общее резервное окно.",
    )


HANDLERS = {
    "pasha_schedule": resolve_pasha_schedule,
    "social_evening": resolve_social_evening,
    "voluntary_quit": resolve_voluntary_quit,
    "pasha_intro": resolve_pasha_intro,
    "pasha_collision": resolve_pasha_collision,
    "misha": resolve_misha,
    "misha_rematch": resolve_misha_rematch,
    "travel_dogs": resolve_travel_dogs,
    "kolya_intro": resolve_kolya_intro,
    "grisha": resolve_grisha,
    "kolya_debt": resolve_kolya_debt,
    "terkom_offer": resolve_terkom_offer,
    "pasha_reserve": resolve_pasha_reserve,
    "morning_pasha": resolve_morning_pasha,
}
