"""Scene reducer dispatcher with explicit domain submodules."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import BalanceProfile
from mmvn.models import GameState
from mmvn.time_budget import action_time_budget

from ..helpers_state import _fail
from ..helpers_time import advance_minutes
from ..types import ActionResult
from .academic import HANDLERS as ACADEMIC_HANDLERS
from .lore import HANDLERS as LORE_HANDLERS
from .social import HANDLERS as SOCIAL_HANDLERS

_SCENE_HANDLERS = {**ACADEMIC_HANDLERS, **SOCIAL_HANDLERS, **LORE_HANDLERS}


def _resolve_scene(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None = None,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Apply one scene choice through its focused reducer."""

    if scene == "terkom_final":
        return resolve_scene(state, "terkom_offer", choice, subject, profile)
    handler = _SCENE_HANDLERS.get(scene)
    if handler is None:
        return _fail(state, "Неизвестная сюжетная сцена.")
    return handler(state, scene, choice, subject, profile)


def _time_position(state: GameState) -> tuple[int, int, int, int | None]:
    return state.day, state.slot, state.minute_offset, state.clock_hour


def resolve_scene(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None = None,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Resolve a scene and charge its authored short-event duration once."""

    result = _resolve_scene(state, scene, choice, subject, profile)
    if not result.ok or _time_position(result.state) != _time_position(state):
        return result
    budget = action_time_budget(
        f"scene:{scene}:{choice}",
        state.day,
        state.slot,
        end_day=result.state.day,
        end_slot=result.state.slot,
        profile=profile,
        start_minute_offset=state.minute_offset,
        end_minute_offset=result.state.minute_offset,
        start_hour=state.hour,
        end_hour=result.state.hour,
    )
    if budget is None or budget.minutes == 0:
        return result
    return replace(result, state=advance_minutes(result.state, budget.minutes, profile))
