"""Lore scene reducers."""

from __future__ import annotations

from mmvn.balance import BalanceProfile
from mmvn.models import GameState
from mmvn.rules.types import ActionResult

from . import context as _ctx


def resolve_english_surreal(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("english_surreal_seen"):
        return _ctx._fail(state, "Английская аномалия уже была записана.")
    next_state = state.with_flag("english_surreal_seen")
    if choice == "answer":
        next_state = _ctx.replace(next_state, memory_shards=next_state.memory_shards + 1)
        next_state = _ctx._grant_study_boost(next_state)
        return _ctx._ok(next_state, "Фраза принята. В памяти остался один лишний фрагмент.")
    if choice == "translate":
        next_state = _ctx._change_stats(next_state, charisma=1)
        return _ctx._ok(next_state, "Перевод оказался понятен не всем, но уверенность выросла.")
    if choice == "close":
        next_state = _ctx._change_stats(next_state, health=-1, health_cause="english")
        return _ctx._ok(
            next_state, "Окно закрыто. Непереведённая фраза осталась на другой стороне."
        )
    return _ctx._fail(state, "Неизвестная реакция на английскую аномалию.")


def resolve_english_fairy(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("english_fairy_seen"):
        return _ctx._fail(state, "Это упражнение уже закончилось.")
    reaction, outcome = choice, None
    if "|" in choice:
        reaction, outcome = choice.split("|", 1)
        if outcome not in _ctx.FAIRY_OUTCOMES:
            return _ctx._fail(state, "Неизвестный исход английского упражнения.")
    next_state = state.with_flag("english_fairy_seen")
    if reaction == "close":
        next_state = _ctx._grant_study_boost(next_state)
        message = "Странное упражнение добавило одну ясную мысль."
    elif reaction == "ask":
        next_state = _ctx._change_stats(next_state, charisma=1)
        message = "Прямой вопрос оказался полезнее правильной интонации."
    elif reaction == "leave":
        next_state = next_state.with_flag("garlic_smell")
        next_state = _ctx.replace(next_state, garlic_minutes=3 * 60, garlic_windows=3)
        message = "В коридоре остался запах чеснока."
    else:
        return _ctx._fail(state, "Неизвестная реакция на упражнение после английского.")

    if outcome is not None:
        next_state = next_state.with_flag(f"english_fairy_outcome:{outcome}")
        if outcome == "money":
            next_state = _ctx._change_stats(next_state, money=3)
            message += " Откуда-то появились три рубля."
        elif outcome == "brain":
            next_state = _ctx._grant_study_boost(next_state)
            message += " В голове стало на одну ясную мысль больше."
        elif outcome == "transfer":
            next_state = next_state.with_flag("english_fairy_transferred")
            message += " Упражнение перенесли в ведомости, хотя никто не просил."
        elif outcome == "garlic":
            # Derive the duration from the saved seed for reproducibility.
            _timer = 2 + (state.seed % 3)
            next_state = next_state.with_flag("garlic_smell")
            next_state = _ctx.replace(
                next_state,
                garlic_minutes=_timer * 60,
                garlic_windows=_timer,
            )
            message += " Вместе с ним остался запах чеснока."
        else:
            message += " Больше ничего не произошло."
    return _ctx._ok(next_state, message)


def resolve_english_intro(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    flag = f"{scene}_seen"
    if state.has_flag(flag):
        return _ctx._fail(state, "Эта короткая сцена уже была показана.")
    if choice != "seen":
        return _ctx._fail(state, "Короткая сцена не имеет такого варианта.")
    return _ctx._ok(state.with_flag(flag), "Сцена отмечена.")


def resolve_dorm_fuse(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("dorm_fuse_resolution_seen"):
        return _ctx._fail(state, "С щитком уже разобрались до сна.")
    next_state = state.with_flag("dorm_fuse_resolution_seen")
    if choice == "fix":
        next_state = _ctx._advance_action(next_state, "scene:dorm_fuse:fix", profile)
        if state.brain >= 5:
            return _ctx._ok(
                next_state.with_flag("dorm_fuse_fixed"),
                "Щиток удалось вернуть к жизни. В коридоре снова есть свет.",
            )
        next_state = _ctx._change_stats(next_state, health=-3, health_cause="dorm_fuse")
        return _ctx._ok(
            next_state.with_flag("dorm_fuse_fix_failed"),
            "Щиток не поддался: короткий удар отнял 3 здоровья.",
        )
    if choice == "sleep":
        return _ctx._ok(
            next_state.with_flag("dorm_fuse_slept_in_dark"),
            "Герой оставил щиток до утра и лёг в темноте.",
        )
    return _ctx._fail(state, "Неизвестное решение для щитка.")


def resolve_lore_baobab(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("lore_baobab_seen"):
        return _ctx._fail(state, "Эту бумагу у Баобаба уже разобрали.")
    if state.location != "faculty":
        return _ctx._fail(state, "Слой расписаний сейчас остался в корпусе.")
    next_state = _ctx._advance_action(state, "scene:lore:baobab", profile).with_flag(
        "lore_baobab_seen"
    )
    if choice == "copy":
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(next_state, "Слой расписания переписан в общий список: +1 к общему делу.")
    if choice == "ask":
        next_state = _ctx._change_trust(next_state, "pasha", 1).with_flag("baobab_teacher_hint")
        return _ctx._ok(
            next_state,
            "Паша назвал автора старой строки и подсказал, где искать преподавателя. Доверие к нему выросло.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Лист остался под кнопкой. Через час его уже никто не узнает.")
    return _ctx._fail(state, "Неизвестная реакция на слои расписания.")


def resolve_lore_terkom(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("lore_terkom_seen"):
        return _ctx._fail(state, "Разговор в ТЕРКОМе уже записан.")
    if state.location != "computer_lab":
        return _ctx._fail(state, "ТЕРКОМ сейчас далеко от героя.")
    next_state = _ctx._advance_action(state, "scene:lore:terkom", profile).with_flag(
        "lore_terkom_seen"
    )
    if choice == "inspect":
        next_state = _ctx.replace(next_state, memory_shards=next_state.memory_shards + 1)
        return _ctx._ok(next_state, "На соседнем компе найден ещё один слой памяти.")
    if choice == "ask":
        next_state = _ctx._change_trust(next_state, "shuler", 1).with_note("informatics")
        progress = next_state.subject("informatics")
        if progress is not None:
            next_state = next_state.with_subject(_ctx.replace(progress, has_notes=True))
        return _ctx._ok(
            next_state,
            "Шулер впервые объяснил, что именно он проверяет, и разрешил переписать распечатку для подготовки.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Герой записал адрес proxy на обороте расписания и отошёл.")
    return _ctx._fail(state, "Неизвестная реакция на разговор в ТЕРКОМе.")


def resolve_lore_geometry_rumor(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("lore_geometry_rumor_seen"):
        return _ctx._fail(state, "Этот слух у кабинета геометрии уже разобрали.")
    if state.location != "faculty":
        return _ctx._fail(state, "Листок про геометрию остался у факультетского кабинета.")
    if state.pending_exam_subject not in (None, "geometry"):
        return _ctx._fail(state, "Сначала нужно закончить другую подготовку к зачёту.")
    next_state = _ctx._advance_action(
        state,
        "scene:lore:geometry_rumor",
        profile,
    ).with_flag("lore_geometry_rumor_seen")
    if choice == "listen":
        return _ctx._ok(
            _ctx.replace(next_state, group_score=next_state.group_score + 1),
            "Слух записан в факультетскую тетрадь: +1 к общему делу.",
        )
    if choice == "check":
        # LORE-01: the payoff opens a prepared exam approach instead of a
        # bare knowledge point.
        return _ctx._ok(
            _ctx._queue_exam_effect(next_state, "geometry", bonus=1),
            "Герой проверил условие по конспекту и выписал ход для зачёта.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Герой оставил слух на двери. Бумага выдержит ещё один день.")
    return _ctx._fail(state, "Неизвестная реакция на слух о геометрии.")


def resolve_lore_international_students(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("lore_international_students_seen"):
        return _ctx._fail(state, "Список иностранных студентов уже обсуждали.")
    if state.location != "faculty":
        return _ctx._fail(state, "Список будущих студентов висит в факультетском коридоре.")
    next_state = _ctx._advance_action(
        state,
        "scene:lore:international_students",
        profile,
    ).with_flag("lore_international_students_seen")
    if choice == "copy":
        return _ctx._ok(
            _ctx.replace(next_state, group_score=next_state.group_score + 1),
            "Список переписан без сокращений: +1 к общему делу.",
        )
    if choice == "ask":
        next_state = _ctx._change_trust(next_state, "pasha", 1).with_flag("train_schedule_tip")
        return _ctx._ok(
            next_state,
            "Паша объяснил, где хранится чистый экземпляр списка, и подсказал, в каком вагоне обычно идут контролёры.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Герой оставил список на кнопке. Его прочитают и без него.")
    return _ctx._fail(state, "Неизвестная реакция на список студентов.")


def resolve_djug(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("djug_seen"):
        return _ctx._fail(state, "Джуга уже оценил метод.")
    next_state = state.with_flag("djug_seen")
    if choice == "stairs":
        return _ctx._ok(
            _ctx._change_stats(next_state, health=-2, health_cause="djug"),
            "Лестница была длиннее доказательства.",
        )
    if choice == "argue":
        next_state = _ctx._change_subject(next_state, "geometry", knowledge=-1)
        return _ctx._ok(
            _ctx._change_stats(next_state, health=-8, health_cause="djug"),
            "Спор выиграл время у геометрии и проиграл его здоровью.",
        )
    if choice == "question":
        if state.brain < 7:
            return _ctx._fail(state, "Точный вопрос требует мозгов 7.")
        next_state = _ctx._change_subject(next_state, "geometry", knowledge=1)
        next_state = _ctx._change_trust(next_state, "djug", 1)
        return _ctx._ok(
            _ctx._change_stats(next_state, health=-4, health_cause="djug"),
            "Джуга ответил на точный вопрос. Это почти считалось помощью.",
        )
    return _ctx._fail(state, "Неизвестный вариант разговора с Джугой.")


def resolve_shuler_offer(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    second_offer = state.has_flag("shuler_refused") and state.day >= 5
    if state.has_flag("shuler_offer_seen") and not second_offer:
        return _ctx._fail(state, "Шулер уже предлагал дискету.")
    offer_flag = "shuler_offer_second_seen" if second_offer else "shuler_offer_seen"
    next_state = state.with_flag(offer_flag)
    if choice == "take":
        next_state = _ctx._change_trust(next_state, "shuler", 1).with_flag("has_disk")
        return _ctx._ok(next_state, "Шулер передал дискету. На наклейке написано твоё расписание.")
    if choice == "inspect":
        if state.brain < 6:
            return _ctx._fail(state, "Просмотр файлов требует мозгов 6.")
        next_state = _ctx._change_trust(next_state, "shuler", 1)
        next_state = _ctx.replace(next_state, memory_shards=next_state.memory_shards + 1)
        return _ctx._ok(
            next_state.with_flag("has_disk"),
            "Внутри нашёлся фрагмент файла, которого ещё не было.",
        )
    if choice == "refuse":
        return _ctx._ok(
            next_state.with_flag("shuler_refused"),
            "Шулер убрал дискету. Она подождёт до пятого дня.",
        )
    return _ctx._fail(state, "Неизвестный вариант предложения Шулера.")


def resolve_shuler_second_run(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if (
        state.inception != 1
        or state.day < 5
        or not state.has_flag("has_disk")
        or state.has_flag("disk_second_choice_seen")
    ):
        return _ctx._fail(state, "Второй выбор дискеты сейчас недоступен.")
    if choice == "run":
        return _ctx.start_nested_game(state, profile=profile)
    if choice == "copy":
        next_state = _ctx.replace(state, memory_shards=state.memory_shards + 1)
        return _ctx._ok(
            next_state.with_flag("disk_second_choice_seen").with_flag("disk_copied"),
            "Файлы скопированы. Вложенность осталась прежней.",
        )
    if choice == "destroy":
        flags = state.event_flags - frozenset(("has_disk",))
        next_state = (
            _ctx.replace(
                state,
                event_flags=flags,
            )
            .with_flag("disk_second_choice_seen")
            .with_flag("disk_destroyed")
        )
        return _ctx._ok(next_state, "Дискету уничтожили. Будущее осталось без резервной копии.")
    return _ctx._fail(state, "Неизвестный вариант второго запуска.")


def resolve_shuler_reaction(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("shuler_reaction_seen"):
        return _ctx._fail(state, "Эта версия запуска уже обсуждалась.")
    next_state = state.with_flag("shuler_reaction_seen")
    if choice == "bug":
        return _ctx._ok(next_state, "Шулер записал слово «баг» в журнал, но не поставил приоритет.")
    if choice == "schedule":
        if state.brain < 6:
            return _ctx._fail(state, "Чтобы назвать это расписанием, нужны мозги 6.")
        return _ctx._ok(
            _ctx.replace(next_state, memory_shards=next_state.memory_shards + 1),
            "В расписании появился ещё один слой.",
        )
    if choice == "hide":
        return _ctx._ok(
            next_state.with_flag("hide_disk"),
            "Дискету спрятали. Мир сделал вид, что это обычный план.",
        )
    return _ctx._fail(state, "Неизвестная реакция на вложенную игру.")


def resolve_kuzmenko(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("kuzmenko_seen"):
        return _ctx._fail(state, "Кузьменко уже сообщил всё, что знает.")
    next_state = state.with_flag("kuzmenko_seen").with_flag("informatics_teacher_found")
    if choice == "window":
        informatics = state.subject("informatics")
        if (
            not state.has_flag("baobab_teacher_hint")
            and state.charisma < 5
            and (informatics is None or informatics.knowledge < 2)
        ):
            return _ctx._fail(
                state,
                "Дополнительное окно открывается при харизме 5 или двух знаниях информатики.",
            )
        return _ctx._ok(
            _ctx._change_trust(next_state.with_flag("kuzmenko_window"), "kuzmenko", 1),
            "Кузьменко добавил окно по информатике на шестом дне.",
        )
    if choice == "task":
        return _ctx._ok(
            _ctx._change_subject(next_state, "informatics", knowledge=1),
            "Кузьменко объяснил, где физически лежит нужная задача.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Кузьменко вернулся к списку. Список пережил разговор.")
    return _ctx._fail(state, "Неизвестный вариант разговора с Кузьменко.")


def resolve_sasha_future(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("sasha_future_seen"):
        return _ctx._fail(state, "Странная строка в конспекте уже обсуждалась.")
    next_state = state.with_flag("sasha_future_seen")
    if choice == "tell":
        return _ctx._ok(
            _ctx._change_trust(next_state, "sasha", 1).with_flag("sasha_future_trusted"),
            "Саша сохранил обе версии строки и начал помнить отменённые события.",
        )
    if choice == "compare":
        if state.note_subject is None:
            return _ctx._fail(state, "Сравнивать пока не с чем: нужен конспект.")
        next_state = _ctx._change_subject(next_state, state.note_subject, knowledge=1)
        return _ctx._ok(
            _ctx._change_trust(next_state, "sasha", 1),
            "Саша сравнил поля. Одна ошибка оказалась полезной.",
        )
    if choice == "sleep":
        return _ctx._ok(next_state, "Саша решил, что это недосып. Недосып ничего не подтвердил.")
    return _ctx._fail(state, "Неизвестный вариант разговора с Сашей.")


def resolve_shuler_final(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if choice == "close":
        return _ctx._ok(
            state.with_flag("shuler_closed"), "Программа закрыта. Расписание осталось на месте."
        )
    if choice == "restart":
        return _ctx._ok(
            state.with_flag("restart_finale"),
            "Начальные условия восстановлены. Сосед пока ещё не знает.",
        )
    if choice == "patch":
        relation = state.relationship("shuler")
        if (
            state.inception != 2
            or state.memory_shards < 2
            or relation is None
            or relation.trust < 2
        ):
            return _ctx._fail(
                state,
                "Исправление требует два запуска, два фрагмента памяти и доверие Шулера 2.",
            )
        return _ctx._ok(
            state.with_flag("patch_used"),
            "Расписание исправлено. Теперь неизвестно, кто его автор.",
        )
    if choice == "gamma":
        return _ctx.start_final_nested_game(state, profile)
    return _ctx._fail(state, "Неизвестный вариант финального запуска.")


HANDLERS = {
    "english_surreal": resolve_english_surreal,
    "english_fairy": resolve_english_fairy,
    "english_intro": resolve_english_intro,
    "small_cabinet": resolve_english_intro,
    "dorm_fuse": resolve_dorm_fuse,
    "lore_baobab": resolve_lore_baobab,
    "lore_terkom": resolve_lore_terkom,
    "lore_geometry_rumor": resolve_lore_geometry_rumor,
    "lore_international_students": resolve_lore_international_students,
    "djug": resolve_djug,
    "shuler_offer": resolve_shuler_offer,
    "shuler_second_run": resolve_shuler_second_run,
    "shuler_reaction": resolve_shuler_reaction,
    "kuzmenko": resolve_kuzmenko,
    "sasha_future": resolve_sasha_future,
    "shuler_final": resolve_shuler_final,
}
