"""Academic scene reducers."""

from __future__ import annotations

from mmvn.balance import BalanceProfile
from mmvn.constants import HOMEWORK_TRUST_CAP
from mmvn.models import GameState
from mmvn.rules.types import ActionResult

from . import context as _ctx


def _trust_with(state: GameState, character: str) -> int:
    relation = state.relationship(character)
    return relation.trust if relation is not None else 0


def resolve_exam_crowd(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("exam_crowd_seen"):
        return _ctx._fail(state, "Помощь перед зачётом уже была использована.")
    if subject not in _ctx.SUBJECTS:
        return _ctx._fail(state, "Для этой сцены не выбран предмет.")
    if subject not in tuple(
        appointment.subject for appointment in _ctx.current_appointments(state)
    ):
        return _ctx._fail(state, "Сейчас этот предмет не принимают.")
    if state.pending_exam_subject not in (None, subject):
        return _ctx._fail(state, "Сначала нужно закончить другую подготовку к зачёту.")
    if not choice.startswith("ask:"):
        return _ctx._fail(state, "Неизвестный вариант разговора перед зачётом.")
    character = choice.split(":", 1)[1]
    if character not in _ctx.exam_crowd_candidates(state, subject):
        return _ctx._fail(state, "Этот человек сейчас не может помочь с этим зачётом.")
    next_state = _ctx._queue_exam_effect(state, subject, bonus=1).with_flag("exam_crowd_seen")
    return _ctx._ok(
        next_state,
        "Перед зачётом удалось сверить один важный шаг: +1 задача к прогнозу.",
    )


def resolve_sasha_notes(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if choice == "decline":
        if state.has_flag("notes_received"):
            return _ctx._fail(state, "Конспект уже лежит в рюкзаке.")
        if state.has_flag("notes_offer_declined"):
            return _ctx._fail(state, "От конспекта уже отказались.")
        return _ctx._ok(
            state.with_flag("notes_offer_declined"),
            "Саша убрал тетрадь. Подготовиться придётся самостоятельно.",
        )
    if subject not in ("algebra", "matan", "geometry"):
        return _ctx._fail(state, "Саша предлагает выбрать один математический конспект.")
    if state.has_flag("notes_received"):
        return _ctx._fail(state, "Конспект уже лежит в рюкзаке.")
    next_state = state.with_note(subject).with_flag("notes_received")
    progress = next_state.subject(subject)
    if progress is not None:
        next_state = next_state.with_subject(_ctx.replace(progress, has_notes=True))
    next_state = _ctx.replace(next_state, note_subject=subject)
    next_state = _ctx._change_trust(next_state, "sasha", 1)
    return _ctx._ok(next_state, f"Саша передал конспект по предмету: {subject}.")


def resolve_serge_pe(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("serge_pe_seen"):
        return _ctx._fail(state, "Серж уже показал короткую дорогу.")
    next_state = state.with_flag("serge_pe_seen")
    if choice == "run":
        return _ctx._ok(next_state, "Серж побежал рядом. Физкультура осталась физкультурой.")
    if choice == "shortcut":
        next_state = _ctx._change_trust(next_state, "serge", 1)
        return _ctx._ok(
            _ctx._change_stats(
                next_state, health=-2, charisma=1, health_cause="shortcut"
            ).with_flag("serge_help"),
            "Срезка отняла два здоровья, но Серж запомнил смелость.",
        )
    if choice == "theory":
        if state.charisma < 7:
            return _ctx._fail(state, "Теорема о круге не заменяет харизму 7.")
        next_state = _ctx._queue_exam_effect(next_state, "pe", bonus=2)
        return _ctx._ok(
            next_state.with_flag("cheated_pe"),
            "Тренер согласился считать аргумент частью разминки.",
        )
    return _ctx._fail(state, "Неизвестный вариант сцены физкультуры.")


def resolve_rai_help(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if subject not in ("algebra", "matan", "geometry"):
        return _ctx._fail(state, "Рай просит помощь только по фундаментальному предмету.")
    if state.has_flag("rai_seen"):
        return _ctx._fail(state, "Рай уже получил ответ или отказ.")
    next_state = state.with_flag("rai_seen")
    if choice == "explain":
        next_state = _ctx._change_trust(next_state, "rai", 1)
        next_state = _ctx._grant_study_boost(next_state)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        next_state = _ctx._queue_exam_effect(next_state, subject, penalty=1)
        return _ctx._ok(
            next_state.with_flag("rai_helped"),
            "Рай понял объяснение. Твоя попытка потеряет одну задачу.",
        )
    if choice == "divide":
        if state.charisma < 6:
            return _ctx._fail(state, "Разделить работу можно при харизме 6.")
        next_state = _ctx._change_trust(next_state, "rai", 1)
        next_state = _ctx._grant_study_boost(next_state)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(
            next_state.with_flag("rai_helped"),
            "Рай взял свою часть. Общий результат не уменьшился.",
        )
    if choice == "refuse":
        return _ctx._ok(
            next_state.with_flag("rai_refused"),
            "Отказ зафиксирован. Рай запомнил формулировку.",
        )
    return _ctx._fail(state, "Неизвестный вариант помощи Раю.")


def resolve_nil_help(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("nil_seen"):
        return _ctx._fail(state, "NiL уже получила ответ или отказ.")
    if subject not in ("algebra", "matan", "geometry", "informatics"):
        return _ctx._fail(state, "NiL просит помощь по учебному предмету.")
    next_state = state.with_flag("nil_seen")
    if choice == "help":
        next_state = _ctx._change_stats(next_state, money=10)
        next_state = _ctx._change_trust(next_state, "nil", 1)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        next_state = _ctx._queue_exam_effect(next_state, subject, penalty=1)
        return _ctx._ok(
            next_state.with_flag("nil_helped"),
            "NiL заплатила десять рублей. Твоя попытка потеряет одну задачу.",
        )
    if choice == "rai":
        if not state.has_flag("rai_helped"):
            return _ctx._fail(state, "Отправить к Раю можно только после знакомства с ним.")
        next_state = _ctx._change_trust(next_state, "nil", 1)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        return _ctx._ok(
            next_state.with_flag("nil_helped"),
            "NiL ушла к Раю. Спрос на чужие мозги перераспределён.",
        )
    if choice == "refuse":
        return _ctx._ok(next_state, "NiL записала отказ как финансовый прогноз.")
    return _ctx._fail(state, "Неизвестный вариант помощи NiL.")


def resolve_andrew_repay(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if not state.has_debt("andrew"):
        return _ctx._fail(state, "У героя нет долга перед Эндрю.")
    if state.has_flag("andrew_repay_seen"):
        return _ctx._fail(state, "Долг перед Эндрю уже урегулирован.")
    next_state = state.with_flag("andrew_repay_seen")
    if choice == "teach":
        next_state = _ctx._change_trust(next_state, "andrew", 1)
        next_state = next_state.without_debt("andrew")
        return _ctx._ok(
            next_state,
            "Герой разобрал задачу вместе с Эндрю. Долг закрыт, а доверие выросло.",
        )
    if choice == "notes":
        next_state = _ctx._change_trust(next_state, "andrew", 1)
        next_state = next_state.without_debt("andrew")
        return _ctx._ok(
            next_state,
            "Герой отдал Эндрю свои черновики. Долг закрыт.",
        )
    if choice == "refuse":
        return _ctx._ok(
            next_state,
            "Герой отложил разговор с Эндрю на потом.",
        )
    return _ctx._fail(state, "Неизвестный вариант расчёта с Эндрю.")


def resolve_andrew_help(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("andrew_seen"):
        return _ctx._fail(state, "Эндрю уже предложил помощь.")
    if subject not in _ctx.SUBJECTS:
        return _ctx._fail(state, "Эндрю не нашёл такой предмет в своей формуле.")
    next_state = state.with_flag("andrew_seen")
    if choice == "now":
        next_state = _ctx._change_trust(next_state, "andrew", 1)
        next_state = _ctx._change_stats(next_state, health=-6, health_cause="study")
        return _ctx._ok(
            _ctx._queue_exam_effect(next_state, subject, bonus=1),
            "Эндрю решил одну задачу вслух. Здоровье заплатило за громкость.",
        )
    if choice == "debt":
        next_state = _ctx._change_trust(next_state, "andrew", 1)
        next_state = _ctx.replace(next_state, group_score=next_state.group_score + 1)
        next_state = next_state.with_debt("andrew")
        return _ctx._ok(
            _ctx._queue_exam_effect(next_state, subject, bonus=1).with_flag("andrew_debt"),
            "Эндрю оставил решение в долг.",
        )
    if choice == "no":
        return _ctx._ok(
            next_state.with_flag("andrew_refused"),
            "Эндрю продолжил думать так громко, будто это самостоятельный предмет.",
        )
    return _ctx._fail(state, "Неизвестный вариант помощи Эндрю.")


def resolve_kolya_algebra(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if subject != "algebra":
        return _ctx._fail(state, "Коля решает только алгебру.")
    if state.has_flag("kolya_algebra_seen"):
        return _ctx._fail(state, "Коля уже предложил свой способ.")
    next_state = state.with_flag("kolya_algebra_seen")
    trust = state.relationship("kolya")
    if choice == "solutions":
        if trust is None or trust.trust < 1:
            return _ctx._fail(state, "Готовые решения доступны после знакомства с Колей.")
        next_state = _ctx._change_subject(next_state, "algebra", tasks=2)
        return _ctx._ok(
            next_state.with_debt("kolya").with_flag("kolya_debt"),
            "Коля закрыл две задачи. Теперь у решения есть долг.",
        )
    if choice == "explain":
        if trust is None or trust.trust < 1:
            return _ctx._fail(state, "Объяснение доступно после знакомства с Колей.")
        next_state = _ctx._change_subject(next_state, "algebra", knowledge=1, tasks=1)
        next_state = _ctx._change_stats(next_state, health=-4, health_cause="study")
        return _ctx._ok(
            _ctx._change_trust(next_state, "kolya", 1),
            "Коля объяснил замену базиса. Здоровье оплатило курс.",
        )
    if choice == "pay":
        if state.money < 20:
            return _ctx._fail(state, "Для слабого решения не хватает 20 рублей.")
        next_state = _ctx._change_stats(next_state, money=-20)
        return _ctx._ok(
            _ctx._change_subject(next_state, "algebra", tasks=1),
            "Коля продал одну задачу без долгосрочных обязательств.",
        )
    if choice == "persuade":
        if state.charisma < 8:
            return _ctx._fail(state, "Уговорить Колю можно при харизме 8.")
        return _ctx._ok(
            _ctx._change_subject(next_state, "algebra", tasks=1),
            "Коля уступил одну задачу из уважения к наглости.",
        )
    if choice == "leave":
        return _ctx._ok(next_state, "Коля убрал салфетку. Алгебра осталась на столе.")
    return _ctx._fail(state, "Неизвестный вариант помощи Коли.")


def resolve_collective_help(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("group_help_used"):
        return _ctx._fail(state, "Коллектив уже разобрал общее решение.")
    if state.location != "faculty":
        return _ctx._fail(state, "Коллективная помощь собирается на факультете.")
    present = set(_ctx.present_characters(state))
    anchors = {"pasha", "sasha", "kolya", "shuler", "grisha", "andrew"}
    if len(present) < 2 or not present.intersection(anchors):
        return _ctx._fail(state, "Для коллективной помощи нужны доверительные люди в одном месте.")
    if choice == "accept":
        if subject not in _ctx.SUBJECTS:
            return _ctx._fail(state, "Коллективному решению нужен предмет.")
        next_state = _ctx._change_subject(state, subject, tasks=1)
        return _ctx._ok(
            next_state.with_flag("group_help_used"), "Коллектив собрал одну пригодную задачу."
        )
    if choice == "give":
        next_state = _ctx._change_trust(state, "rai", 1)
        return _ctx._ok(
            _ctx.replace(next_state, group_score=state.group_score + 1).with_flag(
                "group_help_used"
            ),
            "Решение ушло другому студенту. Это тоже коллективный результат.",
        )
    if choice == "refuse":
        return _ctx._ok(
            state.with_flag("group_help_used"),
            "Группа разошлась по своим доказательствам.",
        )
    return _ctx._fail(state, "Неизвестный вариант коллективной помощи.")


def resolve_morning_sasha(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("morning_sasha_seen"):
        return _ctx._fail(state, "Саша уже вернул утреннюю услугу.")
    if subject not in _ctx.SUBJECTS:
        return _ctx._fail(state, "Саша предлагает выбрать несданный предмет.")
    next_state = _ctx._change_subject(state, subject, knowledge=1)
    return _ctx._ok(
        next_state.with_flag("morning_sasha_seen"), "Саша добавил одну строку в нужный раздел."
    )


def resolve_morning_kolya(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("morning_kolya_seen"):
        return _ctx._fail(state, "Коля уже вернул утреннюю услугу.")
    if not state.has_flag("kolya_debt_paid"):
        return _ctx._fail(state, "Коля возвращает услугу только после закрытия долга.")
    next_state = state.with_flag("morning_kolya_seen")
    if choice == "task":
        return _ctx._ok(
            _ctx._change_subject(next_state, "algebra", tasks=1),
            "Коля добавил одну алгебраическую задачу.",
        )
    if choice == "health":
        return _ctx._ok(
            _ctx._change_stats(next_state, health=8),
            "Коля принёс кефир. В нём подозрительно много здоровья.",
        )
    return _ctx._fail(state, "Неизвестный утренний выбор Коли.")


def resolve_morning_serge(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.has_flag("morning_serge_seen"):
        return _ctx._fail(state, "Серж уже принёс кефир.")
    next_state = _ctx._change_trust(
        _ctx._change_stats(state.with_flag("morning_serge_seen"), health=8),
        "serge",
        1,
    )
    return _ctx._ok(
        next_state,
        "Серж принёс кефир: здоровье выросло на 8, доверие окрепло.",
    )


def resolve_nil_archive(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    if state.location != "faculty":
        return _ctx._fail(state, "Архив NiL доступен только на факультете.")
    if state.day < 4:
        return _ctx._fail(state, "Архив NiL появляется на доске объявлений только с 4-го дня.")
    if not state.has_flag("nil_helped"):
        return _ctx._fail(state, "Без помощи NiL его архив не появляется.")
    if state.has_flag("nil_archive_seen"):
        return _ctx._fail(state, "Архив NiL уже открыт или закрыт.")
    if choice == "buy":
        if state.money < 10:
            return _ctx._fail(state, "Для выкупа архива нужно 10 рублей.")
        next_state = _ctx._change_stats(state, money=-10)
        next_state = _ctx._change_trust(next_state, "nil", 1)
        next_state = next_state.with_flag("nil_archive_bought").with_flag("nil_archive_seen")
        next_state = next_state.with_flag("archive_program_history_unlocked")
        # Gives notes for both informatics and algebra
        next_state = next_state.with_note("informatics").with_note("algebra")
        return _ctx._ok(
            next_state,
            "Архив NiL выкуплен за 10 рублей: конспекты по информатике и алгебре получены, доверие выросло.",
        )
    if choice == "leave":
        return _ctx._ok(
            state.with_flag("nil_archive_seen"),
            "Предложение архива осталось на доске объявлений.",
        )
    return _ctx._fail(state, "Неизвестный выбор в архиве NiL.")


def resolve_miss_li(
    state: GameState,
    scene: str,
    choice: str,
    subject: str | None,
    profile: BalanceProfile | str | None,
) -> ActionResult:
    """Miss Li offers either more exercises or one very bad idea.

    Neither route grants knowledge. The study wall stays intact: only studying
    moves English knowledge, exactly like every other subject. Her exercises buy
    a foothold with her, worth one trust and no more, so the safe route cannot be
    farmed into the deeper trust that the top credit band needs. The other route
    is one attempt for the whole week, and it only lands if that foothold is
    already there: the gamble is in committing before you can be sure you did
    enough. Scenes here stay RNG-free, so the risk is a threshold the player has
    to read, not a dice roll.
    """

    if state.location != "faculty":
        return _ctx._fail(state, "Мисс Ли принимает на кафедре.")
    if subject != "english":
        return _ctx._fail(state, "Мисс Ли ведёт только английский.")
    if choice == "homework":
        if _trust_with(state, "li") >= HOMEWORK_TRUST_CAP:
            return _ctx._ok(
                state,
                "Мисс Ли дала те же упражнения и ничего не добавила.",
            )
        return _ctx._ok(
            _ctx._change_trust(state, "li", 1),
            "Мисс Ли дала ещё один вариант. Она теперь разговаривает с тобой иначе.",
        )
    if choice == "confess":
        if state.charisma < 6:
            return _ctx._fail(
                state,
                "С таким лицом про такое не начинают. Нужна харизма 6.",
            )
        if state.has_flag("miss_li_confessed"):
            return _ctx._fail(state, "Мисс Ли больше не пойдёт на разговор.")
        if _trust_with(state, "li") >= HOMEWORK_TRUST_CAP:
            next_state = _ctx._change_trust(state, "li", 1)
            return _ctx._ok(
                next_state.with_flag("miss_li_confessed"),
                "Она спросила, что ты читал. Ты ответил. Зачёт по английскому подешевеет.",
            )
        return _ctx._ok(
            _ctx._change_stats(
                state.with_flag("miss_li_confessed"),
                health=-6,
                health_cause="confession",
            ),
            "Она спросила, что ты читал. Ты открыл пустую тетрадь. Это заняло здоровья.",
        )
    if choice == "leave":
        return _ctx._ok(state, "Ты вышел, не начав разговора.")
    return _ctx._fail(state, "Неизвестный вариант разговора с Мисс Ли.")


HANDLERS = {
    "exam_crowd": resolve_exam_crowd,
    "sasha_notes": resolve_sasha_notes,
    "serge_pe": resolve_serge_pe,
    "rai_help": resolve_rai_help,
    "nil_help": resolve_nil_help,
    "nil_archive": resolve_nil_archive,
    "andrew_help": resolve_andrew_help,
    "andrew_repay": resolve_andrew_repay,
    "kolya_algebra": resolve_kolya_algebra,
    "collective_help": resolve_collective_help,
    "morning_sasha": resolve_morning_sasha,
    "morning_kolya": resolve_morning_kolya,
    "morning_serge": resolve_morning_serge,
    "miss_li": resolve_miss_li,
}
