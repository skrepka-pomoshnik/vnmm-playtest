"""Shared imports for focused scene reducers."""

from dataclasses import replace

from mmvn.balance import resolve_balance_profile
from mmvn.constants import SUBJECTS
from mmvn.presence import present_characters
from mmvn.schedule import current_appointments
from mmvn.social_events import social_event_available_at
from mmvn.subject_flavor import FAIRY_OUTCOMES

from ..domain.activities import start_final_nested_game, start_nested_game
from ..domain.exams import exam_crowd_candidates
from ..helpers_state import (
    _change_irritation,
    _change_stats,
    _change_subject,
    _change_trust,
    _fail,
    _grant_study_boost,
    _ok,
    _queue_exam_effect,
)
from ..helpers_time import (
    _advance_action,
    advance_minutes,
)

__all__ = [
    "FAIRY_OUTCOMES",
    "SUBJECTS",
    "_advance_action",
    "_change_irritation",
    "_change_stats",
    "_change_subject",
    "_change_trust",
    "_fail",
    "_grant_study_boost",
    "_ok",
    "_queue_exam_effect",
    "advance_minutes",
    "current_appointments",
    "exam_crowd_candidates",
    "present_characters",
    "replace",
    "resolve_balance_profile",
    "social_event_available_at",
    "start_final_nested_game",
    "start_nested_game",
]
