"""Compatibility facade for focused domain helper modules.

New domain code imports the focused modules directly.  The explicit aliases
keep the old import path available to alpha-era tools and saves without
making the facade part of the implementation dependency graph.
"""

from .helpers_state import (
    FOOD_OPTIONS as FOOD_OPTIONS,
)
from .helpers_state import (
    TABLETS_GHOST_ROWS as TABLETS_GHOST_ROWS,
)
from .helpers_state import (
    _change_irritation as _change_irritation,
)
from .helpers_state import (
    _change_stats as _change_stats,
)
from .helpers_state import (
    _change_subject as _change_subject,
)
from .helpers_state import (
    _change_trust as _change_trust,
)
from .helpers_state import (
    _clear_exam_effect as _clear_exam_effect,
)
from .helpers_state import (
    _clear_sleep_debt as _clear_sleep_debt,
)
from .helpers_state import (
    _clear_study_streak as _clear_study_streak,
)
from .helpers_state import (
    _fail as _fail,
)
from .helpers_state import (
    _grant_study_boost as _grant_study_boost,
)
from .helpers_state import (
    _ok as _ok,
)
from .helpers_state import (
    _queue_exam_effect as _queue_exam_effect,
)
from .helpers_state import (
    _study_streak as _study_streak,
)
from .helpers_state import (
    dream_is_due as dream_is_due,
)
from .helpers_state import (
    mark_flag as mark_flag,
)
from .helpers_state import (
    record_dream as record_dream,
)
from .helpers_state import (
    require_gradebook as require_gradebook,
)
from .helpers_state import (
    tablets_display_rows as tablets_display_rows,
)
from .helpers_state import (
    task_requirement as task_requirement,
)
from .helpers_time import (
    CAMPUS_CLOSING_HOUR as CAMPUS_CLOSING_HOUR,
)
from .helpers_time import (
    CAMPUS_CLOSING_LOCATIONS as CAMPUS_CLOSING_LOCATIONS,
)
from .helpers_time import (
    CAMPUS_EVICTION_FLAG as CAMPUS_EVICTION_FLAG,
)
from .helpers_time import (
    _advance_action as _advance_action,
)
from .helpers_time import (
    _apply_window_effects as _apply_window_effects,
)
from .helpers_time import (
    advance_minutes as advance_minutes,
)
from .helpers_time import (
    advance_slots as advance_slots,
)
from .helpers_time import (
    advance_travel_delay as advance_travel_delay,
)
from .helpers_time import (
    campus_location_is_closed as campus_location_is_closed,
)
from .helpers_time import (
    clear_campus_eviction as clear_campus_eviction,
)
from .helpers_time import (
    evict_after_campus_closing as evict_after_campus_closing,
)
from .helpers_time import (
    travel_control_risk as travel_control_risk,
)
from .helpers_time import (
    travel_control_threshold as travel_control_threshold,
)
from .helpers_time import (
    wait as wait,
)

__all__ = (
    "CAMPUS_CLOSING_HOUR",
    "CAMPUS_CLOSING_LOCATIONS",
    "CAMPUS_EVICTION_FLAG",
    "FOOD_OPTIONS",
    "TABLETS_GHOST_ROWS",
    "_advance_action",
    "_apply_window_effects",
    "_change_irritation",
    "_change_stats",
    "_change_subject",
    "_change_trust",
    "_clear_exam_effect",
    "_clear_sleep_debt",
    "_clear_study_streak",
    "_fail",
    "_grant_study_boost",
    "_ok",
    "_queue_exam_effect",
    "_study_streak",
    "advance_minutes",
    "advance_slots",
    "advance_travel_delay",
    "campus_location_is_closed",
    "clear_campus_eviction",
    "dream_is_due",
    "evict_after_campus_closing",
    "mark_flag",
    "record_dream",
    "require_gradebook",
    "tablets_display_rows",
    "task_requirement",
    "travel_control_risk",
    "travel_control_threshold",
    "wait",
)
