"""Calendar, transport and short-duration state transitions."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import BalanceProfile, resolve_balance_profile
from mmvn.models import GameState
from mmvn.time_budget import DAY_MINUTES, format_duration, state_absolute_minutes

from .helpers_state import _change_stats, _clear_sleep_debt, _fail, _ok
from .types import ActionResult

# The campus locations share one closing bell.  The marker is deliberately
# transient: it lets the Ren'Py adapter show the watchwoman's interruption
# once, while the immutable state itself is immediately returned to the dorm.
CAMPUS_CLOSING_HOUR = 20
CAMPUS_CLOSING_LOCATIONS = frozenset(("faculty", "pomi", "mausoleum", "computer_lab"))
CAMPUS_EVICTION_FLAG = "campus_eviction_pending"


def campus_location_is_closed(state: GameState, location: str | None = None) -> bool:
    """Return whether a campus location is past the common closing hour."""

    selected_location = state.location if location is None else location
    return selected_location in CAMPUS_CLOSING_LOCATIONS and state.hour >= CAMPUS_CLOSING_HOUR


def _mark_campus_eviction(state: GameState) -> GameState:
    return replace(
        state,
        location="dorm",
        event_flags=state.event_flags | frozenset((CAMPUS_EVICTION_FLAG,)),
    )


def evict_after_campus_closing(state: GameState) -> GameState:
    """Return a closed-campus save to the dormitory."""

    if not campus_location_is_closed(state):
        return state
    return _mark_campus_eviction(state)


def clear_campus_eviction(state: GameState) -> GameState:
    """Remove the adapter handoff marker after its interruption was shown."""

    flags = state.event_flags - frozenset((CAMPUS_EVICTION_FLAG,))
    if flags == state.event_flags:
        return state
    return replace(state, event_flags=flags)


def _campus_closing_crossed(state: GameState, minutes: int) -> bool:
    """Detect a closing crossed during an action, including an overnight jump."""

    if minutes <= 0 or state.location not in CAMPUS_CLOSING_LOCATIONS:
        return False
    closing_absolute = (state.day - 1) * DAY_MINUTES + CAMPUS_CLOSING_HOUR * 60
    return (
        state.hour >= CAMPUS_CLOSING_HOUR
        or state_absolute_minutes(state) + minutes >= closing_absolute
    )


def travel_control_threshold(
    charisma: int,
    profile: BalanceProfile | str | None = None,
) -> int:
    """Return the d100 roll needed for a controller to stop a stowaway."""

    selected = resolve_balance_profile(profile)
    bonus = min(
        selected.controller_max_bonus,
        max(0, charisma - selected.controller_charisma_floor) * selected.controller_charisma_step,
    )
    return min(100, selected.controller_base_threshold + bonus)


def travel_control_risk(
    charisma: int,
    profile: BalanceProfile | str | None = None,
) -> float:
    """Return the controller probability shown by the train preview."""

    return (100 - travel_control_threshold(charisma, profile)) / 100


def _advance_action(
    state: GameState,
    action_key: str,
    profile: BalanceProfile | str | None = None,
    fallback: int = 1,
) -> GameState:
    """Advance the one continuous clock using a named minute duration.

    ``DurationKnob.slots`` is legacy metadata kept for old profile files.  It
    is deliberately ignored here: a gameplay action may never turn a visible
    minute duration into a whole management window.
    """

    selected = resolve_balance_profile(profile)
    knob = selected.duration.action(action_key)
    minutes = knob.minutes if knob is not None else fallback * 60
    return advance_minutes(state, minutes, selected)


def _apply_elapsed_effects(state: GameState, minutes: int) -> GameState:
    """Apply temporary effects against exact elapsed minutes."""

    if minutes <= 0 or state.garlic_minutes <= 0:
        return state
    remaining = max(0, state.garlic_minutes - minutes)
    if remaining:
        # Keep the old field as a derived, read-only compatibility projection
        # for alpha fixtures.  No rule reads it to make a decision.
        legacy_windows = (remaining + 59) // 60
        return replace(state, garlic_minutes=remaining, garlic_windows=legacy_windows)
    flags = frozenset(flag for flag in state.event_flags if flag != "garlic_smell")
    next_state = replace(state, garlic_minutes=0, garlic_windows=0, event_flags=flags)
    return _change_stats(next_state, charisma=1)


# Kept as a private import alias for alpha callers.  New gameplay code must
# use ``_apply_elapsed_effects`` or, preferably, ``advance_minutes``.
_apply_window_effects = _apply_elapsed_effects


def advance_minutes(
    state: GameState,
    minutes: int,
    profile: BalanceProfile | str | None = None,
) -> GameState:
    """Advance both balance profiles on the same absolute minute axis."""

    if minutes < 0:
        raise ValueError("minutes must not be negative")
    if minutes == 0:
        return state
    current_absolute = (state.day - 1) * 24 * 60 + state.hour * 60 + state.minute
    target_absolute = current_absolute + minutes
    day_index, minute_of_day = divmod(target_absolute, 24 * 60)
    target_hour, target_minute = divmod(minute_of_day, 60)
    crossed_hours = target_absolute // 60 - current_absolute // 60
    next_state = replace(
        state,
        day=day_index + 1,
        slot=GameState._hourly_slot(target_hour),
        clock_hour=target_hour,
        minute_offset=target_minute,
    )
    if crossed_hours > 0:
        next_state = replace(next_state, terkom_free=True)
    elapsed_state = _apply_elapsed_effects(next_state, minutes)
    if _campus_closing_crossed(state, minutes) or campus_location_is_closed(elapsed_state):
        return _mark_campus_eviction(elapsed_state)
    return elapsed_state


def advance_slots(state: GameState, slots: int = 1) -> GameState:
    """Advance explicit one-hour units for old tools and fixtures.

    This is not a calendar-window operation.  Runtime actions use named
    minute knobs; this helper is retained only for old analysis fixtures that
    explicitly ask for one or more hours.
    """

    if slots < 0:
        raise ValueError("slots must not be negative")

    return advance_minutes(state, slots * 60)


def advance_travel_delay(
    state: GameState,
    minutes: int | None = None,
    profile: BalanceProfile | str | None = None,
    *,
    slots: int | None = None,
) -> ActionResult:
    """Spend mishap time without changing resources or relationships."""

    selected = resolve_balance_profile(profile)
    if minutes is not None and slots is not None:
        return _fail(state, "Нельзя одновременно задать минуты и старый параметр slots.")
    if slots is not None:
        if slots < 1:
            return _fail(state, "Задержка должна занимать хотя бы одну минуту.")
        # Compatibility for pre-continuous-time dev callers.  It is an
        # explicit number of hours, never a hidden calendar band.
        minutes = slots * 60
    if minutes is None:
        knob = selected.duration.action("travel_delay")
        minutes = knob.minutes if knob is not None else 60
    if minutes < 1:
        return _fail(state, "Задержка должна занимать хотя бы одну минуту.")
    next_state = advance_minutes(state, minutes, selected)
    return _ok(
        next_state,
        f"Транспортная задержка заняла {format_duration(minutes)}.",
    )


def wait(
    state: GameState,
    minutes: int | None = None,
    profile: BalanceProfile | str | None = None,
    *,
    slots: int | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if minutes is not None and slots is not None:
        return _fail(state, "Нельзя одновременно задать минуты и старый параметр slots.")
    if slots is not None:
        if slots < 1:
            return _fail(state, "Ждать можно хотя бы одну минуту.")
        # Compatibility for old headless callers only.  The runtime button
        # calls wait() with no slots and therefore uses the exact wait knob.
        knob = selected.duration.action("wait")
        minutes = (knob.minutes if knob is not None else 15) * slots
    if minutes is None:
        knob = selected.duration.action("wait")
        minutes = knob.minutes if knob is not None else 15
    if minutes < 1:
        return _fail(state, "Ждать можно хотя бы одну минуту.")
    if minutes > DAY_MINUTES:
        return _fail(state, "За один раз нельзя ждать больше суток.")
    next_state = advance_minutes(state, minutes, selected)
    next_state = _clear_sleep_debt(next_state)
    return _ok(next_state, f"Прошло {format_duration(minutes)}. Расписание не стало добрее.")


def wait_until(
    state: GameState,
    target_day: int,
    target_minute: int,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Wait exactly until an absolute in-week clock position.

    This is used by deterministic QA routes and by authored actions that say
    “дождаться приёма”.  It never rounds to a slot or jumps to a daily band.
    """

    if target_day < 1 or not 0 <= target_minute < DAY_MINUTES:
        return _fail(state, "Неверная точка ожидания.")
    current = state_absolute_minutes(state)
    target = (target_day - 1) * DAY_MINUTES + target_minute
    if target <= current:
        return _fail(state, "Это время уже прошло.")
    return wait(state, target - current, profile=profile)
