"""Computer-class, work and nested-activity reducers."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import BalanceProfile, resolve_balance_profile, source_roll
from mmvn.constants import RandomSource
from mmvn.models import GameState
from mmvn.schedule import regenerate_future_schedule

from ..helpers_state import (
    _change_trust,
    _clear_sleep_debt,
    _fail,
    _grant_study_boost,
    _ok,
    task_requirement,
)
from ..helpers_time import _advance_action
from ..types import ActionResult

__all__ = (
    "play_mmheroes_activity",
    "start_final_nested_game",
    "start_nested_game",
    "use_internet",
    "work_terkom",
)


def _record_grisha_shift(state: GameState) -> GameState:
    if not state.has_flag("grisha_met") or state.has_flag("grisha_shift_seen"):
        return state
    return _change_trust(state.with_flag("grisha_shift_seen"), "grisha", 1)


def work_terkom(
    state: GameState,
    profile: BalanceProfile | str | None = None,
    option_id: str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if state.location != "faculty":
        return _fail(state, "Работа в ТЕРКОМе начинается на факультете.")
    if not state.has_flag("terkom_unlocked"):
        return _fail(state, "Сначала нужно поговорить с Гришей.")

    try:
        option = selected.work_option(option_id)
    except KeyError:
        return _fail(state, "Такого варианта смены сейчас нет.")

    if selected.calendar_mode == "hourly":
        if rng is None:
            return _fail(state, "Для классической смены нужен явный бросок RNG.")

        if not getattr(state, "terkom_free", True):
            return _ok(state, "Свободных компьютеров сейчас нет.")

        def roll(stop: int) -> int:
            return source_roll(rng, stop)

        if roll(3) != 0:
            return _ok(replace(state, terkom_free=False), "Свободных компьютеров нет.")

        money_gain = roll(roll(state.charisma + state.brain)) + 1
        while money_gain > 4:
            money_gain = roll(money_gain - 3) + 2
        health_cost = roll(money_gain * 2)
        next_state = _clear_sleep_debt(_advance_action(state, "work", selected))
        next_stats = replace(
            next_state.stats,
            health=max(0, next_state.health - health_cost),
            money=next_state.money + money_gain,
        )
        next_state = replace(
            next_state,
            stats=next_stats,
            last_health_cause="terkom",
            work_shifts=state.work_shifts + 1,
        ).with_flag("terkom_job")
        next_state = _record_grisha_shift(next_state)
        message = f"Смена в ТЕРКОМе принесла {money_gain} рублей и отняла {health_cost} здоровья."
        if not state.has_flag("grisha_shift_seen") and next_state.has_flag("grisha_shift_seen"):
            message += " Гриша отметил первую смену в табеле."
        return _ok(next_state, message)

    next_state = _clear_sleep_debt(_advance_action(state, option.duration_key, selected))
    next_stats = replace(
        next_state.stats,
        health=max(0, next_state.health - option.health_cost),
        money=next_state.money + option.money_gain,
    )
    next_state = replace(
        next_state,
        stats=next_stats,
        last_health_cause="terkom",
        work_shifts=state.work_shifts + 1,
    ).with_flag("terkom_job")
    next_state = _record_grisha_shift(next_state)
    message = f"Смена в ТЕРКОМе ({option.label}) принесла {option.money_gain} рублей и отняла {option.health_cost} здоровья."
    if not state.has_flag("grisha_shift_seen") and next_state.has_flag("grisha_shift_seen"):
        message += " Гриша отметил первую смену в табеле."
    return _ok(next_state, message)


def use_internet(
    state: GameState,
    outcome: str,
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if state.location != "computer_lab":
        return _fail(state, "Интернет доступен только в компьютерном классе.")
    if not state.has_flag("has_internet"):
        return _fail(state, "Сначала нужно поговорить с Гришей.")
    if selected.calendar_mode == "hourly":
        # MMHEROES has one repeatable Inet action, not three collectible
        # modern outcomes.  Keep the old labels as harmless API aliases for
        # headless callers, but resolve all of them through the same source
        # roll and never burn a one-shot flag.
        if outcome not in {"classic", "informatics", "memory"}:
            return _fail(state, "В классическом режиме Inet предлагает одну услугу.")
        if rng is None:
            return _fail(state, "Для классического интернета нужен явный бросок RNG.")

        def roll(stop: int) -> int:
            return source_roll(rng, stop)

        progress = state.subject("informatics")
        if progress is None:
            return _fail(state, "Информатика отсутствует в учебном плане.")
        next_state = _clear_sleep_debt(_advance_action(state, "internet", selected))
        if roll(state.brain) > 6 and progress.tasks_done < progress.required_tasks:
            tasks_done = progress.tasks_done + 1
            next_progress = replace(
                progress,
                tasks_done=tasks_done,
                passed=tasks_done >= progress.required_tasks,
                passed_day=state.day
                if tasks_done >= progress.required_tasks and not progress.passed
                else progress.passed_day,
            )
            next_state = next_state.with_subject(next_progress)
            message = "Нашлась программка, которая нужна для Климова."
        elif roll(3) == 0 and state.brain < 5:
            # AUDIT-09: this used to be a permanent brain +1, which crossed the
            # `brain >= 7` study threshold and doubled every later session for
            # the rest of the week. Grant the temporary boost instead.
            next_state = _grant_study_boost(next_state)
            message = "В сети нашлась полезная подсказка: следующие занятия пойдут бодрее."
        else:
            message = "Час в Inet прошёл без заметного результата."
        return _ok(next_state, message)

    outcome_flags = {
        "informatics": "internet_informatics_used",
        "memory": "internet_memory_used",
        "schedule": "internet_schedule_used",
    }
    if outcome not in outcome_flags:
        return _fail(state, "Неизвестный результат интернет-сцены.")
    outcome_flag = outcome_flags[outcome]
    if state.has_flag(outcome_flag):
        return _fail(state, "Этот результат уже проверен через интернет.")

    next_state = _clear_sleep_debt(_advance_action(state, "internet", selected))
    if outcome == "informatics":
        progress = next_state.subject("informatics")
        if progress is None:
            return _fail(state, "Информатика отсутствует в учебном плане.")
        required = task_requirement(next_state, "informatics")
        tasks_done = min(required, progress.tasks_done + 2)
        next_progress = replace(
            progress,
            tasks_done=tasks_done,
            passed=tasks_done >= required,
            passed_day=state.day
            if tasks_done >= required and not progress.passed
            else progress.passed_day,
        )
        next_state = next_state.with_subject(next_progress)
        message = "Интернет добавил две задачи по информатике."
    elif outcome == "memory":
        next_state = replace(next_state, memory_shards=next_state.memory_shards + 1)
        message = "В коде нашёлся фрагмент, которого вчера ещё не существовало."
    else:
        message = "Расписание сверено. Изменившиеся строки теперь отмечены в бумажной версии."
    next_state = next_state.with_flag(outcome_flag)
    if all(next_state.has_flag(flag) for flag in outcome_flags.values()):
        next_state = next_state.with_flag("internet_used")
    return _ok(next_state, message)


def start_nested_game(
    state: GameState,
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
    session_score: int | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if state.location != "computer_lab":
        return _fail(state, "Дискету можно запустить только в компьютерном классе.")
    if not state.has_flag("has_disk"):
        return _fail(state, "Для запуска нужна дискета Шулера.")
    if state.inception >= 2:
        return _fail(state, "Следующий запуск возможен только в финальной сцене.")

    next_state = _clear_sleep_debt(_advance_action(state, "nested", selected))
    next_schedule = regenerate_future_schedule(next_state, rng, variant="B")
    score_bonus = int(session_score is not None and session_score >= 30)
    if state.inception == 0:
        health_cost = selected.nested_first_health_cost
        next_state = replace(
            next_state,
            schedule=next_schedule,
            inception=1,
            schedule_variant="B",
            stats=replace(next_state.stats, health=max(0, next_state.health - health_cost)),
            last_health_cause="nested",
            memory_shards=next_state.memory_shards + 1 + score_bonus,
        ).with_flag("nested_game_started")
        if score_bonus:
            next_state = next_state.with_flag("nested_game_won")
        message = "Будущие окна перепечатаны. Кто-то ещё помнит старую версию."
        if score_bonus:
            message += " Дискета сохранила удачный результат."
        return _ok(next_state, message)

    if state.day < 5:
        return _fail(state, "Второй запуск доступен только с пятого дня.")
    health_cost = selected.nested_second_health_cost
    next_state = replace(
        next_state,
        schedule=next_schedule,
        inception=2,
        schedule_variant="B",
        reserve_all=True,
        stats=replace(next_state.stats, health=max(0, next_state.health - health_cost)),
        last_health_cause="nested",
        memory_shards=next_state.memory_shards + 1 + score_bonus,
    ).with_flag("nested_game_started")
    if score_bonus:
        next_state = next_state.with_flag("nested_game_won")
    next_state = _change_trust(next_state, "shuler", 1)
    message = "Вложенность достигла второго уровня. Резервный зачёт открыт."
    if score_bonus:
        message += " Дискета сохранила удачный результат."
    return _ok(next_state, message)


def play_mmheroes_activity(
    state: GameState,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Spend the computer-class activity time without changing the story run.

    The full game and the authored test quests are optional software. They
    share the planner's real time cost, but completing either one must not
    advance inception, rewrite the schedule, grant knowledge or alter trust.
    """

    if state.location != "computer_lab":
        return _fail(state, "Компьютерные программы доступны только в компьютерном классе.")
    selected = resolve_balance_profile(profile)
    next_state = _clear_sleep_debt(_advance_action(state, "nested", selected))
    return _ok(next_state, "В компьютерном классе прошло время; остальное состояние не изменилось.")


def start_final_nested_game(
    state: GameState,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    if state.inception != 2 or state.day < 6 or not state.has_flag("has_disk"):
        return _fail(state, "Финальный запуск доступен только на шестом дне после двух запусков.")
    selected = resolve_balance_profile(profile)
    next_state = _clear_sleep_debt(_advance_action(state, "nested", selected))
    next_state = replace(
        next_state,
        inception=3,
        memory_shards=next_state.memory_shards + 1,
    ).with_flag("gamma_finale")
    return _ok(next_state, "Экран внутри экрана открыл финальную ветку.")
