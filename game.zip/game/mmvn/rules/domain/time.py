"""Calendar, travel, food and recovery reducers.

This module owns actions whose primary effect is moving the clock or restoring
the resources needed to keep moving.
"""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import (
    BalanceProfile,
    FoodOption,
    resolve_balance_profile,
    source_roll,
)
from mmvn.balance.reference import classic_local_travel_health_cost
from mmvn.constants import MAX_HEALTH, MAX_STAMINA, STUDY_BOOST_SESSIONS, RandomSource
from mmvn.models import GameState
from mmvn.time_budget import DAY_MINUTES, format_duration, state_absolute_minutes

from ..helpers_state import (
    _change_trust,
    _clear_sleep_debt,
    _clear_study_streak,
    _fail,
    _ok,
)
from ..helpers_time import (
    CAMPUS_EVICTION_FLAG,
    _advance_action,
    advance_minutes,
    clear_campus_eviction,
    evict_after_campus_closing,
    travel_control_threshold,
)
from ..types import ActionResult

__all__ = (
    "DEFAULT_MEAL_COOLDOWN_MINUTES",
    "cafe_open_now",
    "eat_food",
    "food_options",
    "mausoleum_open_now",
    "meal_cooldown_active",
    "meal_cooldown_remaining",
    "rest",
    "sleep",
    "travel_to",
)

DEFAULT_MEAL_COOLDOWN_MINUTES = 90


def cafe_open_now(state: GameState) -> bool:
    """Return whether the Mausoleum's paid café service is open."""

    total_minutes = state.hour * 60 + state.minute
    return 10 * 60 <= total_minutes < 18 * 60


def mausoleum_open_now(state: GameState) -> bool:
    """Return whether the Mausoleum building is open (10:00 to 18:00)."""
    return cafe_open_now(state)


def meal_cooldown_remaining(
    state: GameState, cooldown_minutes: int = DEFAULT_MEAL_COOLDOWN_MINUTES
) -> int:
    """Return remaining cooldown minutes before the next full meal can be consumed."""
    if state.last_meal_at is None:
        return 0
    current_minutes = state_absolute_minutes(state)
    elapsed = current_minutes - state.last_meal_at
    if elapsed < 0:
        return 0
    return max(0, cooldown_minutes - elapsed)


def meal_cooldown_active(
    state: GameState, cooldown_minutes: int = DEFAULT_MEAL_COOLDOWN_MINUTES
) -> bool:
    """Return True if a full meal was consumed recently within cooldown_minutes."""
    return meal_cooldown_remaining(state, cooldown_minutes) > 0


def _sleep_end_absolute(state: GameState, sleep_minutes: int) -> int:
    """Return the wake-up minute, never earlier than 07:00 after an evening sleep."""

    current = state_absolute_minutes(state)
    natural_end = current + sleep_minutes
    if state.hour >= 19:
        next_morning = state.day * DAY_MINUTES + 7 * 60
        return max(natural_end, next_morning)
    return natural_end


def _advance_route(
    state: GameState,
    destination: str,
    profile: BalanceProfile,
) -> GameState:
    """Advance every route by its authored exact minute duration."""

    minutes = profile.duration.travel_duration(state.location, destination)
    if minutes is not None:
        return advance_minutes(state, minutes, profile)
    fallback = profile.duration.action("travel")
    return advance_minutes(state, fallback.minutes if fallback is not None else 60, profile)


def _finalize_route_location(state: GameState, destination: str) -> GameState:
    """Apply the destination after route time, including the closing bell."""

    if destination == "dorm":
        return clear_campus_eviction(state)
    if state.has_flag(CAMPUS_EVICTION_FLAG):
        # The route crossed 20:00 and ``advance_minutes`` already sent the
        # player home.  Do not let the later route assignment put them back in
        # a closed building, even when the clock wrapped past midnight.
        return replace(state, location="dorm")
    return evict_after_campus_closing(state)


def _classic_travel(
    state: GameState,
    destination: str,
    mode: str,
    rng: RandomSource | None,
    profile: BalanceProfile,
) -> ActionResult:
    """Apply the original route checks and its hourly/non-hourly asymmetry."""

    if rng is None:
        return _fail(state, "Для классической поездки нужен явный бросок RNG.")

    def roll(stop: int) -> int:
        return source_roll(rng, stop)

    if destination == "pomi" and state.hour > 20:
        return _fail(state, "ПОМИ уже закрывается: ехать туда поздно.")

    if destination != "pomi" and state.location != "pomi":
        walk_cost = classic_local_travel_health_cost(state.location, destination)
        next_state = _clear_study_streak(
            _clear_sleep_debt(_advance_route(state, destination, profile))
        )
        next_stats = replace(next_state.stats, health=max(0, next_state.health - walk_cost))
        next_state = replace(
            next_state,
            location=destination,
            stats=next_stats,
            last_health_cause="walk",
        )
        next_state = _finalize_route_location(next_state, destination)
        minutes = profile.duration.travel_duration(state.location, destination)
        # AUDIT-28: the walk cost was silently deducted. Report it whenever it
        # is non-zero, the same way the POMI route already reported its fare.
        spent = f" и {walk_cost} здоровья" if walk_cost > 0 else ""
        if minutes:
            message = f"Переход занял {format_duration(minutes)}{spent}."
        else:
            message = f"Переход выполнен сразу, как в классическом MMHEROES{spent}."
        if next_state.location != destination:
            # The closing bell sent the player home instead of where they aimed.
            message += " Время закрытия отправило тебя в общежитие."
        return _ok(next_state, message)

    if destination == "pomi":
        if mode not in {"ticket", "stowaway"}:
            return _fail(state, "Неизвестный способ поездки в ПОМИ.")
        if mode == "ticket" and state.money < 10:
            # The source silently falls back to the зайцем branch when the
            # student cannot afford the outbound ticket.
            mode = "stowaway"
        train_loss = roll(10)
        money = state.money
        ticket_uses = state.pomi_ticket_uses
        if mode == "ticket":
            money -= 10
            ticket_uses = 1
        next_state = _clear_sleep_debt(_advance_action(state, "travel", profile))
        next_stats = replace(
            next_state.stats,
            health=max(0, next_state.health - train_loss),
            money=money,
        )
        next_state = replace(
            next_state,
            location="pomi",
            stats=next_stats,
            pomi_ticket_uses=ticket_uses,
            last_health_cause="train",
        )
        if mode == "stowaway" and state.charisma < roll(10):
            next_stats = replace(next_state.stats, health=max(0, next_state.health - 10))
            next_state = replace(next_state, stats=next_stats).with_flag("travel_controlled")
            next_state = _clear_sleep_debt(_advance_action(next_state, "travel", profile))
            return _ok(next_state, "Контролёр высадил героя; поездка заняла два часа.")
        next_state = _clear_study_streak(next_state)
        next_state = _finalize_route_location(next_state, "pomi")
        return _ok(next_state, "Электричка до ПОМИ заняла один час.")

    if state.location == "pomi":
        ticket_uses = state.pomi_ticket_uses
        money = state.money
        paid_ticket = False
        if ticket_uses:
            ticket_uses -= 1
        elif money >= 5 and mode == "ticket":
            money -= 5
            paid_ticket = True
        elif mode != "stowaway":
            return _fail(state, "На обратный билет из ПОМИ нужно 5 ₽.")
        train_loss = roll(10)
        next_state = _clear_sleep_debt(_advance_action(state, "travel", profile))
        next_stats = replace(
            next_state.stats,
            health=max(0, next_state.health - train_loss),
            money=money,
        )
        next_state = _clear_study_streak(next_state)
        next_state = replace(
            next_state,
            location=destination,
            stats=next_stats,
            pomi_ticket_uses=ticket_uses,
            last_health_cause="train",
        )
        has_ticket = paid_ticket or bool(state.pomi_ticket_uses)
        caught = not has_ticket and state.charisma < roll(10)
        if not has_ticket:
            # The source's ticketless return calls hour_pass once in the
            # stowaway branch and once after it.  The extra hour is paid even
            # when the controller misses the student.
            next_state = _clear_sleep_debt(_advance_action(next_state, "travel", profile))
        if caught:
            next_stats = replace(next_state.stats, health=max(0, next_state.health - 10))
            next_state = replace(next_state, stats=next_stats).with_flag("travel_controlled")
            next_state = _finalize_route_location(next_state, destination)
            return _ok(next_state, "Контролёр высадил героя; обратная электричка заняла два часа.")
        next_state = _finalize_route_location(next_state, destination)
        return _ok(
            next_state,
            "Обратная электричка заняла два часа."
            if not has_ticket
            else "Обратная электричка заняла один час.",
        )

    return _fail(state, "Такой переход в классическом календаре не задан.")


def travel_to(
    state: GameState,
    destination: str,
    mode: str = "ticket",
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if destination not in dict(selected.travel_fares):
        return _fail(state, "Такого места нет на карте.")
    if destination == state.location:
        return _ok(state, "Ты уже находишься здесь.")

    if selected.calendar_mode == "hourly":
        return _classic_travel(state, destination, mode, rng, selected)

    if destination != "pomi" and mode != "ticket":
        return _fail(state, "Особый способ поездки доступен только до ПОМИ.")

    if destination == "pomi" and mode not in {"ticket", "stowaway"}:
        return _fail(state, "Неизвестный способ поездки в ПОМИ.")

    if destination == "pomi" and mode == "stowaway":
        if rng is None:
            return _fail(state, "Для поездки зайцем нужен явный бросок контролёра.")
        next_state = _clear_sleep_debt(_advance_route(state, destination, selected))
        roll = rng.randint(1, 100)
        tip = (
            " Подсказка про вагон помогла выбрать место."
            if state.has_flag("train_schedule_tip")
            else ""
        )
        if roll > travel_control_threshold(state.charisma, selected):
            next_stats = replace(
                next_state.stats,
                health=max(0, next_state.health - selected.travel_controlled_health_cost),
            )
            next_state = replace(
                next_state,
                stats=next_stats,
                last_health_cause="controllers",
            ).with_flag("travel_controlled")
            return _ok(
                next_state,
                f"Контролёр высадил героя до ПОМИ. −{selected.travel_controlled_health_cost} здоровья, поездка заняла время.{tip}",
            )
        next_stats = replace(
            next_state.stats,
            health=max(0, next_state.health - selected.travel_health(destination)),
        )
        next_state = _clear_study_streak(next_state)
        next_state = replace(
            next_state,
            location=destination,
            stats=next_stats,
            last_health_cause="train",
        ).with_flag("travel_stowaway_success")
        next_state = _finalize_route_location(next_state, destination)
        return _ok(next_state, f"Поездка зайцем удалась: ПОМИ достигнут без билета.{tip}")

    fare = selected.travel_fare(destination)
    ticket_uses = state.pomi_ticket_uses
    if destination == "pomi" and ticket_uses:
        fare = 0
        ticket_uses -= 1
    elif state.location == "pomi" and ticket_uses:
        # Pasha's tickets are one-way passes.  The old direct return path did
        # not consume the remaining pass, leaving a visible "Билет" marker
        # after the player had already returned from the city.
        fare = 0
        ticket_uses -= 1
    if state.money < fare:
        return _fail(state, "Не хватает денег на дорогу.")

    travel_minutes = selected.duration.travel_duration(state.location, destination)
    next_state = _clear_study_streak(
        _clear_sleep_debt(_advance_route(state, destination, selected))
    )
    next_stats = replace(
        next_state.stats,
        health=max(
            0,
            next_state.health - selected.travel_health_for_route(state.location, destination),
        ),
        money=next_state.money - fare,
    )
    next_state = replace(
        next_state,
        location=destination,
        stats=next_stats,
        pomi_ticket_uses=ticket_uses,
        last_health_cause="train",
    )
    next_state = _finalize_route_location(next_state, destination)
    if destination == "pomi":
        duration_message = format_duration(travel_minutes or 0)
        message = (
            f"Дорога в ПОМИ заняла {duration_message} и "
            f"{selected.travel_health_for_route(state.location, destination)} здоровья."
        )
        if state.pomi_ticket_uses:
            message = "Билет Паши сработал."
    else:
        # AUDIT-28: leaving POMI costs health for every route, and the old
        # message named only the time. Report the cost, and say so when the
        # closing bell sent the player home instead.
        route_health = selected.travel_health_for_route(state.location, destination)
        spent = f" и {route_health} здоровья" if route_health > 0 else ""
        message = f"Переход занял {format_duration(travel_minutes or 0)}{spent}."
    if next_state.location != destination:
        message += " Время закрытия отправило тебя в общежитие."
    return _ok(next_state, message)


def rest(
    state: GameState,
    venue: str = "dorm",
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        if venue not in {"dorm", "mausoleum"}:
            return _fail(state, "В классическом режиме отдыхают в общаге или Мавзолее.")
        if venue == "dorm" and state.location != "dorm":
            return _fail(state, "Отдыхать в комнате можно только в общежитии.")
        if venue == "mausoleum" and state.location != "mausoleum":
            return _fail(state, "Коля отдыхает только в Мавзолее.")

        if rng is None:
            return _fail(state, "Для классического отдыха нужен явный бросок RNG.")

        def roll(stop: int) -> int:
            return source_roll(rng, stop)

        gain = 7 + roll(8) if venue == "dorm" else roll(state.charisma)
        if venue == "mausoleum":
            gain = roll(state.charisma)
        next_state = _clear_sleep_debt(_advance_action(state, "rest", selected))
        next_stats = replace(next_state.stats, health=min(MAX_HEALTH, state.health + gain))
        return _ok(replace(next_state, stats=next_stats), f"Отдых восстановил {gain} здоровья.")
    try:
        health_gain = selected.rest_gain(venue)
    except KeyError:
        return _fail(state, "Такого варианта отдыха нет.")
    if venue == "dorm" and state.location != "dorm":
        return _fail(state, "Отдыхать в комнате можно только в общежитии.")
    if venue == "mausoleum" and state.location != "mausoleum":
        return _fail(state, "Коля отдыхает только в Мавзолее.")
    if venue == "cafe" and state.location != "mausoleum":
        return _fail(state, "Кафе находится в Мавзолее.")
    if venue == "cafe" and not cafe_open_now(state):
        return _fail(state, "Комплексный обед подают с 10:00 до 18:00.")
    if venue == "serge" and not state.has_flag("serge_help_available"):
        return _fail(state, "Помощь Сержа сейчас недоступна.")
    if venue == "cafe" and state.money < selected.rest_cafe_cost:
        return _fail(state, f"В кафе не хватает {selected.rest_cafe_cost} рублей.")

    action_key = "rest:dorm" if venue == "dorm" else "rest"
    dorm_rest_flag = f"dorm_rest_used:{state.day}"
    if venue == "dorm" and selected.calendar_mode != "hourly" and state.has_flag(dorm_rest_flag):
        return _fail(state, "Сегодня отдых в общаге уже использован.")
    next_state = _clear_sleep_debt(_advance_action(state, action_key, selected))
    next_stats = replace(
        next_state.stats,
        health=min(MAX_HEALTH, next_state.health + health_gain),
        money=next_state.money - (selected.rest_cafe_cost if venue == "cafe" else 0),
        charisma=next_state.charisma
        + (1 if venue == "cafe" and not state.has_flag("cafe_visited") else 0),
    )
    next_state = replace(next_state, stats=next_stats)
    if venue == "cafe":
        next_state = next_state.with_flag("cafe_visited")
    if venue == "dorm" and selected.calendar_mode != "hourly":
        next_state = next_state.with_flag(dorm_rest_flag)
    if venue == "serge":
        next_state = _change_trust(next_state.with_flag("serge_rest_completed"), "serge", 1)
        next_state = replace(
            next_state,
            event_flags=next_state.event_flags - frozenset(("serge_help_available",)),
        )
    return _ok(next_state, f"Отдых восстановил {health_gain} здоровья.")


def food_options(
    state: GameState,
    profile: BalanceProfile | str | None = None,
) -> tuple[FoodOption, ...]:
    """Return the food menu available at the current physical location."""

    selected = resolve_balance_profile(profile)
    if state.location == "dorm":
        # There is no café in the dormitory in either profile.  Food is a
        # physical-location action: the café surface belongs to the
        # Mausoleum, while the source also has its separate POMI/faculty
        # menus.
        venue = None
    elif state.location == "mausoleum":
        venue = "mausoleum"
    elif state.location == "pomi" or (
        selected.calendar_mode == "hourly"
        and state.location == "faculty"
        and 10 <= state.hour <= 18
    ):
        # The source has a faculty café from 10:00 through 18:00.  The
        # realistic profile keeps its separate POMI menu; the dormitory is
        # never treated as a food venue.
        venue = "cafe"
    else:
        venue = None
    if venue is None:
        return ()
    return tuple(option for option in selected.food_options if option.venue == venue)


def eat_food(
    state: GameState,
    item_id: str,
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    """Buy one visible food option, consume one window, and apply its trade-off."""

    selected = resolve_balance_profile(profile)
    option = next(
        (candidate for candidate in food_options(state, selected) if candidate.item_id == item_id),
        None,
    )
    if option is None:
        return _fail(state, "Здесь нет такого варианта еды.")
    if (
        selected.calendar_mode != "hourly"
        and state.location == "mausoleum"
        and not mausoleum_open_now(state)
    ):
        return _fail(state, "Мавзолей закрыт. Часы работы: с 10:00 до 18:00.")
    if selected.calendar_mode != "hourly" and item_id != "sit" and meal_cooldown_active(state):
        remaining = meal_cooldown_remaining(state)
        return _fail(
            state,
            f"Герой ещё не проголодался (сыт ещё {remaining} мин.).",
        )
    if state.money < option.cost:
        return _fail(state, f"На {option.label.lower()} не хватает {option.cost} рублей.")

    next_state = _clear_sleep_debt(_advance_action(state, "food", selected))
    if selected.calendar_mode != "hourly" and item_id != "sit":
        next_state = replace(next_state, last_meal_at=state_absolute_minutes(next_state))
    if selected.calendar_mode == "hourly":
        if rng is None:
            return _fail(state, "Для классической еды нужен явный бросок RNG.")

        def roll(stop: int) -> int:
            return source_roll(rng, stop)

        if state.location == "pomi":
            venue_bonus = {"coffee": 3, "pie": 6, "coffee_pie": 10}.get(item_id, 0)
        elif state.location == "faculty":
            venue_bonus = {"coffee": 2, "pie": 4, "coffee_pie": 7}.get(item_id, 0)
        else:
            venue_bonus = {"cola": 3, "soup": 5}.get(item_id, 0)
        health_gain = roll(state.charisma) + venue_bonus
        next_stats = replace(
            next_state.stats,
            health=min(MAX_HEALTH, next_state.health + health_gain),
            money=next_state.money - option.cost,
        )
        if state.location == "mausoleum" and item_id == "beer":
            if roll(3) == 0:
                next_stats = replace(next_stats, brain=max(0, next_stats.brain - 1))
            if roll(3) == 0:
                next_stats = replace(next_stats, charisma=next_stats.charisma + 1)
            if roll(2) == 0:
                next_stats = replace(next_stats, stamina=next_stats.stamina + 1)
            if next_stats.brain <= 0:
                next_stats = replace(next_stats, health=0)
        next_state = replace(next_state, stats=next_stats).with_flag(f"food_{option.item_id}_seen")
        food_knob = selected.duration.action("food")
        elapsed_label = format_duration(food_knob.minutes if food_knob else 0)
        return _ok(
            next_state,
            f"{option.label}: +{health_gain} здоровья, −{option.cost} ₽"
            + ("." if item_id == "sit" else f", прошло {elapsed_label}."),
        )
    # Brain is a hero stat, not a consumable. A brain-sharpening drink used to
    # raise it permanently and, because the study gain keyed off `brain >= 7`,
    # a 2-RUB coffee doubled every later session permanently (AUDIT-09). The
    # boost is now temporary and counted in sessions, so it always expires.
    next_stats = replace(
        next_state.stats,
        health=min(MAX_HEALTH, next_state.health + option.health),
        stamina=next_state.stats.stamina + option.stamina,
        charisma=next_state.stats.charisma + option.charisma,
        money=next_state.money - option.cost,
    )
    boost_granted = 0
    if option.brain > 0:
        boost_granted = STUDY_BOOST_SESSIONS
        next_state = replace(next_state, study_boost_sessions=boost_granted)
    next_state = replace(next_state, stats=next_stats).with_flag(f"food_{option.item_id}_seen")
    effects = [f"+{option.health} HP"]
    if boost_granted:
        effects.append(f"+1 к учёбе на {boost_granted} сессии")
    if option.stamina:
        effects.append(f"+{option.stamina} выносливость")
    if option.charisma:
        effects.append(f"+{option.charisma} харизма")
    return _ok(next_state, f"{option.label}: {', '.join(effects)}, −{option.cost} ₽.")


def sleep(
    state: GameState,
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    if state.location != "dorm":
        return _fail(state, "Спать до утра можно только в общежитии.")

    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        if state.day >= 6:
            next_stats = replace(state.stats, health=0)
            return _ok(
                replace(state, stats=next_stats, last_health_cause="deadline"),
                "Шесть дней закончились: время вышло.",
            )
        if 3 < state.hour < 20:
            return _fail(state, "Тебя чего-то не тянет по-спать днём.")
        if rng is None:
            return _fail(state, "Для классического сна нужен явный бросок RNG.")

        def roll(stop: int) -> int:
            return source_roll(rng, stop)

        capped_health = min(state.health, 40)
        gain = min(capped_health + 15 + roll(20), 50) - capped_health
        hours = roll(gain // 4) + 7
        natural_sleep_minutes = hours * 60
        absolute = _sleep_end_absolute(state, natural_sleep_minutes)
        sleep_minutes = absolute - state_absolute_minutes(state)
        day_index, minute_of_day = divmod(absolute, DAY_MINUTES)
        target_day = day_index + 1
        if target_day > 6:
            next_stats = replace(state.stats, health=0)
            return _ok(
                replace(state, stats=next_stats, last_health_cause="deadline"),
                "Сон закончился уже после дедлайна: время вышло.",
            )
        if state.stamina <= 0:
            next_stats = replace(state.stats, health=0)
            return _ok(
                replace(state, stats=next_stats, last_health_cause="stamina"),
                "Утро пришло, но сил на него уже не осталось.",
            )
        target_hour, target_minute = divmod(minute_of_day, 60)
        next_state = _clear_study_streak(
            replace(
                state,
                day=target_day,
                slot=GameState._hourly_slot(target_hour),
                clock_hour=target_hour,
                minute_offset=target_minute,
                sleep_debt=False,
                event_flags=frozenset(flag for flag in state.event_flags if flag != "watch_lost"),
            )
        )
        next_stats = replace(next_state.stats, health=capped_health + gain)
        if state.garlic_minutes > 0:
            remaining_garlic = max(0, state.garlic_minutes - sleep_minutes)
            next_stats = replace(next_stats, charisma=next_stats.charisma + roll(2))
            flags = next_state.event_flags
            if remaining_garlic == 0:
                flags = frozenset(flag for flag in flags if flag != "garlic_smell")
            next_state = replace(
                next_state,
                garlic_minutes=remaining_garlic,
                garlic_windows=(remaining_garlic + 59) // 60,
                event_flags=flags,
            )
        return _ok(
            replace(next_state, stats=next_stats),
            f"Сон занял {format_duration(sleep_minutes)}.",
        )
    # Modern sleep uses the configured overnight duration on the same
    # continuous clock as every other action.  An evening bedtime may be
    # extended to 07:00; sleeping in the middle of the day remains rejected.
    # A daytime nap is not one of the authored actions; wait until the evening
    # band and spend the configured eight hours there.
    if 4 <= state.hour < 19:
        return _fail(state, "Сейчас ещё не время ложиться спать.")
    sleep_knob = selected.duration.action("sleep")
    configured_sleep_minutes = sleep_knob.minutes if sleep_knob is not None else 8 * 60
    sleep_end = _sleep_end_absolute(state, configured_sleep_minutes)
    sleep_minutes = sleep_end - state_absolute_minutes(state)
    next_state = _clear_study_streak(advance_minutes(state, sleep_minutes, selected))
    next_state = replace(
        next_state,
        sleep_debt=False,
        event_flags=frozenset(flag for flag in next_state.event_flags if flag != "watch_lost"),
    )
    next_stats = replace(
        next_state.stats,
        health=min(MAX_HEALTH, next_state.health + selected.sleep_health_gain),
        stamina=min(MAX_STAMINA, next_state.stamina + selected.sleep_stamina_gain),
    )
    return _ok(
        replace(next_state, stats=next_stats),
        f"Сон занял {format_duration(sleep_minutes)}.",
    )
