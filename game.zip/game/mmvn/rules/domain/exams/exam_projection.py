"""Exam projections and closing probability calculations."""

from __future__ import annotations

import math
from dataclasses import dataclass

from mmvn.balance import (
    BalanceProfile,
    resolve_balance_profile,
    source_exam_close_probability,
)
from mmvn.constants import (
    EXAM_MENTORS,
    MAX_EXAM_MENTOR_DISCOUNT,
    STANDING_BREADTH,
    STANDING_DEPTH,
    SUBJECTS,
)
from mmvn.models import GameState
from mmvn.presence import present_characters
from mmvn.schedule import current_appointments

from ...helpers_state import task_requirement
from ...types import ExamProjection


def field_standing_requirement(state: GameState) -> int:
    """Return the shape of standing the next credit demands.

    A pure count made every social web equivalent, so the top band now asks
    for two different shapes in order: the fifth credit wants breadth (two
    separate people) and the sixth wants depth (one person trusted twice).
    Spreading one point across three strangers opens the fifth credit and
    strands the sixth, so a run has to decide who to cultivate rather than
    merely how many people to greet.
    """

    passed = state.passed_count
    if passed >= 4:
        return STANDING_DEPTH if passed >= 5 else STANDING_BREADTH
    return 0


def trusted_contacts(state: GameState) -> int:
    """Return how many different people the player trusts at all."""

    return sum(1 for relation in state.relationships if relation.trust > 0)


def deepest_trust(state: GameState) -> int:
    """Return the most trust the player holds with any single person."""

    return max((relation.trust for relation in state.relationships), default=0)


def field_standing_shortfall(state: GameState) -> int:
    """Return how far the player's standing is from the required shape."""

    required = field_standing_requirement(state)
    if required == 0:
        return 0
    if state.passed_count >= 5:
        return max(0, required - deepest_trust(state))
    return max(0, required - trusted_contacts(state))


def exam_mentor_discount(state: GameState, subject: str) -> int:
    """Return how much trust with a subject's helper discounts its exam cost.

    Exploration is the only route to this discount, and it never grants
    knowledge, so the study wall stays intact.
    """

    character = EXAM_MENTORS.get(subject)
    if character is None:
        return 0
    relation = state.relationship(character)
    if relation is None:
        return 0
    return max(0, min(relation.trust, MAX_EXAM_MENTOR_DISCOUNT))


@dataclass(frozen=True)
class EnglishExamTactic:
    """A named English answer mode mapped to the shared exam reducer.

    The player sees the three parts of one examination, while the resolver
    still has one compact progress counter. Named oral modes let the scene
    offer a plain answer as well as charisma-based approaches without making
    English a separate mini-engine.
    """

    command: str
    base_tactic: str
    charisma_required: int = 0
    scene_bonus: int = 0
    extra_health_cost: int = 0


_ENGLISH_EXAM_TACTICS = {
    "english_oral_plain": EnglishExamTactic("english_oral_plain", "as_is"),
    "english_oral_charisma": EnglishExamTactic(
        "english_oral_charisma",
        "talk",
        charisma_required=6,
        scene_bonus=1,
    ),
    "english_oral_improv": EnglishExamTactic(
        "english_oral_improv",
        "talk",
        charisma_required=8,
        scene_bonus=2,
        extra_health_cost=1,
    ),
}


def english_exam_tactic_spec(tactic: str) -> EnglishExamTactic | None:
    """Return the authored specification for a modern English oral mode."""

    return _ENGLISH_EXAM_TACTICS.get(tactic)


def exam_crowd_candidates(state: GameState, subject: str) -> tuple[str, ...]:
    """Return every trusted person currently available before an exam.

    Presence is already capped by the authored location rotation at three
    people.  Keeping the trust and appointment filter in the kernel prevents
    the planner from inventing a helper that the resolver would reject.
    """

    if subject not in SUBJECTS:
        return ()
    if subject not in tuple(appointment.subject for appointment in current_appointments(state)):
        return ()
    if state.pending_exam_subject not in (None, subject):
        return ()
    return tuple(
        character
        for character in present_characters(state)
        if (relation := state.relationship(character)) is not None and relation.trust >= 2
    )


def exam_unit_label(subject: str) -> str:
    """Return the player-facing unit for exam progress."""

    if subject == "english":
        return "компонентов"
    return "упражнений" if subject == "pe" else "задач"


def exam_projection(
    state: GameState,
    subject: str,
    scene_bonus: int = 0,
    profile: BalanceProfile | str | None = None,
) -> ExamProjection | None:
    """Project a scheduled exam without turning study into a story gate.

    Preparation is an intentionally quiet input: it changes the task bundle,
    closing chance and health pressure, but the player may still enter an
    algebra or analysis appointment without a separate preparation flag.
    """

    selected = resolve_balance_profile(profile)
    progress = state.subject(subject)
    try:
        difficulty = selected.subject_difficulty(subject)
    except KeyError:
        difficulty = None
    if progress is None or difficulty is None:
        return None

    if subject == "pe":
        relevant = state.stamina // 2
    elif subject == "english":
        relevant = max(state.brain, state.charisma) // 2
    else:
        relevant = state.brain // 2

    power = progress.knowledge + relevant + scene_bonus
    if subject == "english":
        # A fluent-looking first attempt must not close the whole examination
        # on the initial stats. Preparation, or a deliberate oral approach,
        # is still useful, but the two-component modern exam is no longer a
        # one-click lottery.
        base_tasks = min(2, max(0, (power - difficulty + 3) // 3))
    else:
        # Prepared students scale nicely with study while unprepared get 0-1 base tasks
        base_tasks = min(4, max(0, (power - difficulty + 5) // 2))
    fatigue = selected.subject_fatigue(subject)
    if fatigue is None:
        base_health_cost = max(
            selected.exam_min_health_cost,
            selected.exam_health_offset
            + difficulty
            - selected.exam_stamina_multiplier * state.stamina,
        )
    else:
        base_health_cost = max(selected.exam_min_health_cost, fatigue - state.stamina)
    # Trust earned by exploring shaves the exam's health cost, but an attempt
    # always costs something so stamina and preparation still matter.
    base_health_cost = max(1, base_health_cost - exam_mentor_discount(state, subject))
    can_talk = state.charisma >= max(3, difficulty - 2)
    return ExamProjection(
        subject=subject,
        difficulty=difficulty,
        relevant=relevant,
        base_tasks=base_tasks,
        base_health_cost=base_health_cost,
        can_push=state.health > 12,
        can_talk=can_talk,
    )


def exam_pass_probability(
    state: GameState,
    subject: str,
    tactic: str = "as_is",
    scene_bonus: int = 0,
    assistance_bonus: int = 0,
    profile: BalanceProfile | str | None = None,
) -> float | None:
    """Return the chance of closing a subject in the current exam window.

    The current task bundle still gives partial progress deterministically. A
    roll is only needed when that bundle can close the remaining requirement;
    preparation then changes the actual closing chance instead of being a
    number that only appears in the planner.
    """

    selected = resolve_balance_profile(profile)
    progress = state.subject(subject)
    if progress is None or progress.passed:
        return None
    tactic_spec = english_exam_tactic_spec(tactic) if subject == "english" else None
    effective_tactic = tactic_spec.base_tactic if tactic_spec is not None else tactic
    if tactic_spec is not None and state.charisma < tactic_spec.charisma_required:
        return None
    if tactic not in {"as_is", "push", "talk"} and tactic_spec is None:
        return None

    if selected.calendar_mode == "hourly":
        if tactic != "as_is":
            return None
        from mmvn.balance.reference import CLASSIC_SOURCE_SUBJECT_MAP

        source_subject = CLASSIC_SOURCE_SUBJECT_MAP.get(subject)
        if source_subject is None:
            return None
        return source_exam_close_probability(
            progress.knowledge,
            state.health,
            source_subject.difficulty,
            state.brain,
            state.stamina,
            state.charisma,
            progress.tasks_done,
            task_limit=progress.required_tasks,
            divisor=source_subject.divisor,
            geometry_gate=subject == "geometry",
        )

    pending_bonus = state.pending_exam_bonus if state.pending_exam_subject == subject else 0
    pending_penalty = state.pending_exam_penalty if state.pending_exam_subject == subject else 0
    command_bonus = tactic_spec.scene_bonus if tactic_spec is not None else 0
    projection = exam_projection(
        state,
        subject,
        scene_bonus + assistance_bonus + pending_bonus + command_bonus,
        profile,
    )
    if projection is None:
        return None
    if effective_tactic == "push" and not projection.can_push:
        return None
    if effective_tactic == "talk" and not projection.can_talk:
        return None

    tactic_bonus = int(effective_tactic in {"push", "talk"})
    remaining = task_requirement(state, subject) - progress.tasks_done
    available_tasks = max(0, projection.base_tasks + tactic_bonus - pending_penalty)
    if remaining <= 0:
        return 1.0
    if available_tasks < remaining:
        return 0.0

    # Social subjects can still produce a useful first-pass result without
    # study: English offers an oral route and PE has a small normative bundle.
    # Mathematical subjects keep the stricter floor; their ``available_tasks``
    # check above still makes an unprepared algebra/analysis attempt unable to
    # close the subject.
    if progress.knowledge == 0:
        return 0.40 if subject in {"english", "pe"} else 0.15

    preparation = (
        progress.knowledge
        + projection.relevant
        + scene_bonus
        + assistance_bonus
        + pending_bonus
        + command_bonus
        - pending_penalty
    )
    readiness = max(0, preparation - projection.difficulty + 2)
    # Preparation and already closed tasks have diminishing returns. A second
    # solved task still matters, but never as much as the first one. This is
    # intentionally kept in the modern profile; classic uses the source task
    # distribution above and has no separate closing coin flip.
    readiness_curve = math.log1p(readiness) / math.log(2.0)
    progress_curve = math.log1p(max(0, progress.tasks_done)) / math.log(2.0)
    probability = selected.exam_probability_base + selected.exam_probability_step * (
        readiness_curve + 0.5 * progress_curve
    )
    probability += selected.exam_tactic_probability_bonus * tactic_bonus
    return min(
        selected.exam_probability_cap,
        max(selected.exam_probability_floor, probability),
    )
