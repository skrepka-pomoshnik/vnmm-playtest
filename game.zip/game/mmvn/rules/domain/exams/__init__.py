"""Public exam API with stable monkey-patch points for adapter tests."""

from __future__ import annotations

from mmvn.balance import BalanceProfile
from mmvn.constants import RandomSource
from mmvn.models import GameState

from ...types import ActionResult
from .exam_attempts import (
    take_exam as _take_exam,
)
from .exam_attempts import (
    take_patch_exam as _take_patch_exam,
)
from .exam_beats import (
    EXAM_CHALLENGE_BEATS,
    EXAM_CHALLENGE_SUBJECTS,
    ExamBeat,
    ExamBeatChoice,
    cancel_exam_challenge,
    exam_beat_choices,
    exam_beat_prompt_key,
    exam_challenge_finished,
    exam_challenge_outcome,
    resolve_exam_beat,
)
from .exam_projection import (
    EnglishExamTactic,
    english_exam_tactic_spec,
    exam_crowd_candidates,
    exam_mentor_discount,
    exam_pass_probability,
    exam_projection,
    exam_unit_label,
    field_standing_requirement,
    field_standing_shortfall,
)
from .exam_retry import (
    take_teacher_last_chance as _take_teacher_last_chance,
)
from .exam_retry import (
    teacher_last_chance_projection,
)

__all__ = (
    "EXAM_CHALLENGE_BEATS",
    "EXAM_CHALLENGE_SUBJECTS",
    "EnglishExamTactic",
    "ExamBeat",
    "ExamBeatChoice",
    "cancel_exam_challenge",
    "english_exam_tactic_spec",
    "exam_beat_choices",
    "exam_beat_prompt_key",
    "exam_challenge_finished",
    "exam_challenge_outcome",
    "exam_crowd_candidates",
    "exam_mentor_discount",
    "exam_pass_probability",
    "exam_projection",
    "exam_unit_label",
    "field_standing_requirement",
    "field_standing_shortfall",
    "resolve_exam_beat",
    "take_exam",
    "take_patch_exam",
    "take_teacher_last_chance",
    "teacher_last_chance_projection",
)


def take_exam(
    state: GameState,
    subject: str,
    rng: RandomSource | None = None,
    assistance_bonus: int = 0,
    tactic: str = "as_is",
    scene_bonus: int = 0,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    return _take_exam(
        state,
        subject,
        rng,
        assistance_bonus,
        tactic,
        scene_bonus,
        profile,
        projection_fn=exam_projection,
        probability_fn=exam_pass_probability,
        unit_label_fn=exam_unit_label,
    )


def take_patch_exam(
    state: GameState,
    subject: str,
    tactic: str = "as_is",
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    return _take_patch_exam(
        state,
        subject,
        tactic,
        rng,
        profile,
        projection_fn=exam_projection,
        probability_fn=exam_pass_probability,
        unit_label_fn=exam_unit_label,
    )


def take_teacher_last_chance(
    state: GameState,
    subject: str,
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    return _take_teacher_last_chance(
        state,
        subject,
        rng,
        profile,
        projection_fn=teacher_last_chance_projection,
    )
