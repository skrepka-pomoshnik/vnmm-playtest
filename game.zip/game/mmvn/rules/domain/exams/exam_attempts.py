"""Modern and classic exam-attempt reducers."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import (
    BalanceProfile,
    resolve_balance_profile,
    source_exam_tasks,
)
from mmvn.constants import SUBJECTS, RandomSource
from mmvn.models import GameState
from mmvn.schedule import current_appointments

from ...helpers_state import (
    _clear_exam_effect,
    _clear_sleep_debt,
    _fail,
    _ok,
    require_gradebook,
    task_requirement,
)
from ...helpers_time import _advance_action
from ...types import ActionResult
from .exam_projection import (
    english_exam_tactic_spec,
)
from .exam_projection import (
    exam_pass_probability as _default_exam_pass_probability,
)
from .exam_projection import (
    exam_projection as _default_exam_projection,
)
from .exam_projection import (
    exam_unit_label as _default_exam_unit_label,
)


def _classic_take_exam(
    state: GameState,
    subject: str,
    rng: RandomSource | None,
    profile: BalanceProfile,
) -> ActionResult:
    """Resolve one source-style hourly exam attempt without modern tactics."""

    if rng is None:
        return _fail(state, "Для классического зачёта нужен явный бросок RNG.")
    progress = state.subject(subject)
    if progress is None or progress.passed:
        return _fail(state, "Этот зачёт уже закрыт.")
    if subject not in tuple(appointment.subject for appointment in current_appointments(state)):
        return _fail(state, "Преподаватель сейчас не принимает этот предмет.")
    try:
        profile.subject_difficulty(subject)
    except KeyError:
        return _fail(state, "Такого предмета нет в классическом расписании.")
    from mmvn.balance.reference import CLASSIC_SOURCE_SUBJECT_MAP

    source_subject = CLASSIC_SOURCE_SUBJECT_MAP[subject]
    outcome = source_exam_tasks(
        progress.knowledge,
        state.health,
        source_subject.difficulty,
        state.brain,
        state.stamina,
        state.charisma,
        progress.tasks_done,
        task_limit=progress.required_tasks,
        divisor=source_subject.divisor,
        fatigue=source_subject.fatigue,
        rng=rng,
        geometry_gate=subject == "geometry",
    )
    tasks_done = min(progress.required_tasks, progress.tasks_done + outcome.tasks)
    passed = tasks_done >= progress.required_tasks
    next_progress = replace(
        progress,
        knowledge=outcome.knowledge_after,
        tasks_done=tasks_done,
        passed=passed,
        passed_day=state.day if passed and not progress.passed else progress.passed_day,
    )
    if state.health <= outcome.health_loss:
        next_stats = replace(state.stats, health=0)
        return _ok(
            replace(
                state,
                stats=next_stats,
                last_health_cause="exam",
                last_exam_subject=subject,
            ).with_subject(next_progress),
            f"{subject}: преподаватель замучил героя.",
        )
    next_state = _clear_sleep_debt(_advance_action(state, "exam", profile))
    next_stats = replace(
        next_state.stats,
        health=max(0, state.health - outcome.health_loss),
    )
    next_state = replace(
        next_state,
        stats=next_stats,
        last_health_cause="exam",
        last_exam_subject=subject,
    ).with_subject(next_progress)
    if subject == "english":
        if passed:
            message = (
                "Классический зачёт по английскому закрыт: грамматика, письмо и говорение приняты."
            )
        elif outcome.tasks:
            message = (
                "Классический зачёт по английскому продвинулся, но одну из частей нужно доработать."
            )
        else:
            message = "Классический зачёт по английскому не продвинулся: подготовка оказалась недостаточной."
    elif passed:
        message = f"Классический зачёт закрыт: {tasks_done}/{progress.required_tasks}."
    elif outcome.tasks:
        message = f"Классический зачёт: ещё {outcome.tasks} задач, всего {tasks_done}/{progress.required_tasks}."
    else:
        message = "Классический зачёт не продвинулся: подготовка оказалась недостаточной."
    return _ok(next_state, message)


def take_exam(
    state: GameState,
    subject: str,
    rng: RandomSource | None = None,
    assistance_bonus: int = 0,
    tactic: str = "as_is",
    scene_bonus: int = 0,
    profile: BalanceProfile | str | None = None,
    *,
    projection_fn=None,
    probability_fn=None,
    unit_label_fn=None,
) -> ActionResult:
    """Attempt the subject currently being received.

    A scheduled window is the narrative entry point. Preparation is resolved
    inside the attempt for every subject, so an unprepared mathematics attempt
    is allowed to fail naturally instead of being rejected by a plot gate.
    """

    projection_fn = projection_fn or _default_exam_projection
    probability_fn = probability_fn or _default_exam_pass_probability
    unit_label_fn = unit_label_fn or _default_exam_unit_label
    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        if tactic != "as_is":
            return _fail(state, "В классическом режиме тактики зачёта отсутствуют.")
        return _classic_take_exam(state, subject, rng, selected)
    progress = state.subject(subject)
    if progress is None:
        return _fail(state, "Такого предмета нет в учебном плане.")
    if progress.passed:
        return _fail(state, "Этот зачёт уже закрыт.")

    blocked = require_gradebook(state)
    if blocked is not None:
        return blocked

    if subject == "informatics" and not state.has_flag("informatics_teacher_found"):
        return _fail(state, "Сначала нужно найти преподавателя информатики.")

    tactic_spec = english_exam_tactic_spec(tactic) if subject == "english" else None
    effective_tactic = tactic_spec.base_tactic if tactic_spec is not None else tactic
    if tactic_spec is not None and state.charisma < tactic_spec.charisma_required:
        return _fail(state, "Для такого устного ответа нужна большая уверенность в разговоре.")
    if subject == "english" and tactic.startswith("english_") and tactic_spec is None:
        return _fail(state, "Неизвестный формат ответа по английскому.")

    appointments = tuple(
        appointment for appointment in current_appointments(state) if appointment.subject == subject
    )
    if not appointments:
        return _fail(state, "Преподаватель сейчас не принимает этот предмет.")

    appointment = appointments[0]
    # RV-H4: единственный источник требования — план предмета. Расхождение
    # расписания и плана означает повреждённое состояние; отказ до любого
    # броска RNG, иначе closing-shot сгорает при нулевом шансе.
    requirement = task_requirement(state, subject)
    if appointment.required_tasks != requirement:
        return _fail(
            state,
            "Требование зачёта расходится между расписанием и планом предмета.",
        )
    pending_bonus = state.pending_exam_bonus if state.pending_exam_subject == subject else 0
    pending_penalty = state.pending_exam_penalty if state.pending_exam_subject == subject else 0
    pending_health = state.pending_exam_health_cost if state.pending_exam_subject == subject else 0
    projection = projection_fn(
        state,
        subject,
        scene_bonus
        + assistance_bonus
        + pending_bonus
        + (tactic_spec.scene_bonus if tactic_spec is not None else 0),
        selected,
    )
    if projection is None:
        return _fail(state, "Для этого предмета не удалось построить прогноз.")
    if tactic not in {"as_is", "push", "talk"} and tactic_spec is None:
        return _fail(state, "Неизвестная тактика зачёта.")
    if effective_tactic == "push" and not projection.can_push:
        return _fail(state, "Дожим недоступен при здоровье 12 и ниже.")
    if effective_tactic == "talk" and not projection.can_talk:
        return _fail(state, "Преподавателя нельзя разговорить с текущей харизмой.")

    extra_tasks = int(effective_tactic in {"push", "talk"})
    extra_health_cost = {
        "as_is": 0,
        "push": selected.exam_push_health_cost,
        "talk": selected.exam_talk_health_cost,
    }[effective_tactic] + (tactic_spec.extra_health_cost if tactic_spec is not None else 0)
    tasks = max(0, projection.base_tasks + extra_tasks - pending_penalty)
    remaining_tasks = requirement - progress.tasks_done
    pass_probability = probability_fn(
        state,
        subject,
        tactic=tactic,
        scene_bonus=scene_bonus,
        assistance_bonus=assistance_bonus,
        profile=selected,
    )
    pass_roll_failed = False
    if tasks >= remaining_tasks and pass_probability is not None and rng is not None:
        pass_roll_failed = rng.random() >= pass_probability
        if pass_roll_failed:
            tasks = max(0, remaining_tasks - 1)
    health_cost = projection.base_health_cost + extra_health_cost + pending_health
    tasks_done = min(requirement, progress.tasks_done + tasks)
    passed = tasks_done >= requirement

    next_state = _clear_sleep_debt(_advance_action(state, "exam", selected))
    next_stats = replace(
        next_state.stats,
        health=max(0, next_state.health - health_cost),
    )
    next_progress = replace(
        progress,
        tasks_done=tasks_done,
        passed=passed,
        passed_day=state.day if passed and not progress.passed else progress.passed_day,
    )
    next_state = replace(
        next_state,
        stats=next_stats,
        last_health_cause="exam",
        last_exam_subject=subject,
    ).with_subject(next_progress)
    if state.pending_exam_subject == subject:
        next_state = _clear_exam_effect(next_state)
    if subject == "english":
        if pass_roll_failed:
            message = "Зачёт по английскому не закрыт: ответ требует доработки."
        elif passed:
            message = "Зачёт по английскому закрыт: грамматика, письмо и говорение приняты."
        else:
            message = "Зачёт по английскому продолжается: ответ нужно доработать."
    elif pass_roll_failed:
        message = f"Зачёт не закрыт: шанс был {pass_probability:.0%}, не хватило одного решения."
    elif passed:
        message = f"Зачёт закрыт: выполнено {unit_label_fn(subject)} {tasks_done}/{requirement}."
    else:
        message = (
            f"Зачёт продолжается: выполнено {unit_label_fn(subject)} {tasks_done}/{requirement}."
        )
    return _ok(next_state, message)


def take_patch_exam(
    state: GameState,
    subject: str,
    tactic: str = "as_is",
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
    *,
    projection_fn=None,
    probability_fn=None,
    unit_label_fn=None,
) -> ActionResult:
    projection_fn = projection_fn or _default_exam_projection
    probability_fn = probability_fn or _default_exam_pass_probability
    unit_label_fn = unit_label_fn or _default_exam_unit_label
    """Use the one no-road exam attempt unlocked by repairing the schedule."""

    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        return _fail(state, "В классическом режиме последней попытки нет.")

    if not state.has_flag("patch_used"):
        return _fail(state, "Исправление расписания ещё не открыто.")
    if state.has_flag("patch_exam_used"):
        return _fail(state, "Последняя попытка уже использована.")
    blocked = require_gradebook(state)
    if blocked is not None:
        return blocked

    if subject == "informatics" and not state.has_flag("informatics_teacher_found"):
        return _fail(state, "Сначала нужно найти преподавателя информатики.")

    progress = state.subject(subject)
    if progress is None or subject not in SUBJECTS:
        return _fail(state, "Такого предмета нет в учебном плане.")
    if progress.passed:
        return _fail(state, "Этот зачёт уже закрыт.")
    tactic_spec = english_exam_tactic_spec(tactic) if subject == "english" else None
    effective_tactic = tactic_spec.base_tactic if tactic_spec is not None else tactic
    if tactic_spec is not None and state.charisma < tactic_spec.charisma_required:
        return _fail(state, "Для такого устного ответа нужна большая уверенность в разговоре.")
    if subject == "english" and tactic.startswith("english_") and tactic_spec is None:
        return _fail(state, "Неизвестный формат ответа по английскому.")
    if tactic not in {"as_is", "push", "talk"} and tactic_spec is None:
        return _fail(state, "Неизвестная тактика зачёта.")

    pending_bonus = state.pending_exam_bonus if state.pending_exam_subject == subject else 0
    pending_penalty = state.pending_exam_penalty if state.pending_exam_subject == subject else 0
    pending_health = state.pending_exam_health_cost if state.pending_exam_subject == subject else 0
    projection = projection_fn(
        state,
        subject,
        pending_bonus + (tactic_spec.scene_bonus if tactic_spec is not None else 0),
        selected,
    )
    if projection is None:
        return _fail(state, "Для этого предмета не удалось построить прогноз.")
    if effective_tactic == "push" and not projection.can_push:
        return _fail(state, "Дожим недоступен при здоровье 12 и ниже.")
    if effective_tactic == "talk" and not projection.can_talk:
        return _fail(state, "Преподавателя нельзя разговорить с текущей харизмой.")

    extra_tasks = int(effective_tactic in {"push", "talk"})
    extra_health_cost = {
        "as_is": 0,
        "push": selected.exam_push_health_cost,
        "talk": selected.exam_talk_health_cost,
    }[effective_tactic] + (tactic_spec.extra_health_cost if tactic_spec is not None else 0)
    tasks = max(0, projection.base_tasks + extra_tasks - pending_penalty)
    remaining_tasks = task_requirement(state, subject) - progress.tasks_done
    pass_probability = probability_fn(
        state,
        subject,
        tactic=tactic,
        scene_bonus=tactic_spec.scene_bonus if tactic_spec is not None else 0,
        profile=selected,
    )
    pass_roll_failed = False
    if tasks >= remaining_tasks and pass_probability is not None and rng is not None:
        pass_roll_failed = rng.random() >= pass_probability
        if pass_roll_failed:
            tasks = max(0, remaining_tasks - 1)
    health_cost = projection.base_health_cost + extra_health_cost + pending_health
    requirement = task_requirement(state, subject)
    tasks_done = min(requirement, progress.tasks_done + tasks)
    next_state = _clear_sleep_debt(_advance_action(state, "exam:patch", selected))
    next_stats = replace(next_state.stats, health=max(0, next_state.health - health_cost))
    next_progress = replace(
        progress,
        tasks_done=tasks_done,
        passed=tasks_done >= requirement,
        passed_day=state.day
        if tasks_done >= requirement and not progress.passed
        else progress.passed_day,
    )
    next_state = (
        replace(next_state, stats=next_stats, last_health_cause="exam", last_exam_subject=subject)
        .with_subject(next_progress)
        .with_flag("patch_exam_used")
    )
    if state.pending_exam_subject == subject:
        next_state = _clear_exam_effect(next_state)
    if subject == "english":
        if pass_roll_failed:
            message = "Исправленное окно не закрыло английский: ответ требует доработки."
        elif next_progress.passed:
            message = "Исправленное окно закрыло английский: три части ответа приняты."
        else:
            message = "Исправленное окно завершено: ответ по английскому нужно доработать."
    elif pass_roll_failed:
        message = (
            f"Исправление не закрыло зачёт: шанс был {pass_probability:.0%}, "
            "не хватило одного решения."
        )
    elif next_progress.passed:
        message = (
            f"Исправление сработало: зачёт закрыт, {unit_label_fn(subject)} "
            f"{tasks_done}/{requirement}."
        )
    else:
        message = (
            f"Последняя попытка завершена: {unit_label_fn(subject)} {tasks_done}/{requirement}."
        )
    return _ok(next_state, message)
