"""Short, optional interactive preparation beats for the realistic exams."""

from __future__ import annotations

from dataclasses import dataclass, replace

from mmvn.balance import BalanceProfile, resolve_balance_profile
from mmvn.constants import SUBJECTS
from mmvn.models import GameState
from mmvn.schedule import current_appointments

from ...helpers_state import _fail, _ok, _queue_exam_effect
from ...types import ActionResult

EXAM_CHALLENGE_SUBJECTS = ("algebra", "matan", "geometry")
EXAM_CHALLENGE_BEATS = 3


@dataclass(frozen=True)
class ExamBeatChoice:
    """One visible answer in a preparation beat."""

    command: str
    points: int


@dataclass(frozen=True)
class ExamBeat:
    """A prompt and its three possible approaches."""

    prompt_key: str
    choices: tuple[ExamBeatChoice, ...]


_EXAM_BEATS = {
    "algebra": (
        ExamBeat(
            "condition",
            (
                ExamBeatChoice("check_condition", 2),
                ExamBeatChoice("rewrite_condition", 1),
                ExamBeatChoice("skip_condition", 0),
            ),
        ),
        ExamBeat(
            "basis",
            (
                ExamBeatChoice("build_basis", 2),
                ExamBeatChoice("compare_row", 1),
                ExamBeatChoice("jump_answer", 0),
            ),
        ),
        ExamBeat(
            "counterexample",
            (
                ExamBeatChoice("test_counterexample", 2),
                ExamBeatChoice("state_result", 1),
                ExamBeatChoice("argue_result", 0),
            ),
        ),
    ),
    "matan": (
        ExamBeat(
            "limit",
            (
                ExamBeatChoice("state_limit", 2),
                ExamBeatChoice("draw_limit", 1),
                ExamBeatChoice("skip_limit", 0),
            ),
        ),
        ExamBeat(
            "theorem",
            (
                ExamBeatChoice("name_theorem", 2),
                ExamBeatChoice("bound_argument", 1),
                ExamBeatChoice("swap_terms", 0),
            ),
        ),
        ExamBeat(
            "remainder",
            (
                ExamBeatChoice("check_remainder", 2),
                ExamBeatChoice("estimate_remainder", 1),
                ExamBeatChoice("ignore_remainder", 0),
            ),
        ),
    ),
    "geometry": (
        ExamBeat(
            "figure",
            (
                ExamBeatChoice("check_figure", 2),
                ExamBeatChoice("sketch_figure", 1),
                ExamBeatChoice("skip_figure", 0),
            ),
        ),
        ExamBeat(
            "invariant",
            (
                ExamBeatChoice("state_invariant", 2),
                ExamBeatChoice("check_orientation", 1),
                ExamBeatChoice("assume_invariant", 0),
            ),
        ),
        ExamBeat(
            "boundary",
            (
                ExamBeatChoice("test_boundary", 2),
                ExamBeatChoice("state_boundary", 1),
                ExamBeatChoice("skip_boundary", 0),
            ),
        ),
    ),
}


def exam_beat_choices(subject: str, step: int) -> tuple[ExamBeatChoice, ...]:
    """Return the immutable options for one subject/step pair."""

    beats = _EXAM_BEATS.get(subject)
    if beats is None or not 0 <= step < EXAM_CHALLENGE_BEATS:
        return ()
    return beats[step].choices


def exam_beat_prompt_key(subject: str, step: int) -> str | None:
    """Return the adapter-facing prompt key for one challenge step."""

    beats = _EXAM_BEATS.get(subject)
    if beats is None or not 0 <= step < EXAM_CHALLENGE_BEATS:
        return None
    return beats[step].prompt_key


def exam_challenge_finished(state: GameState, subject: str) -> bool:
    """Return whether all three beats have been answered for ``subject``."""

    return (
        state.exam_challenge_subject == subject
        and state.exam_challenge_step >= EXAM_CHALLENGE_BEATS
    )


def exam_challenge_outcome(state: GameState, subject: str) -> str | None:
    """Classify a finished challenge without exposing numeric mechanics."""

    if not exam_challenge_finished(state, subject):
        return None
    if state.exam_challenge_score >= 6:
        return "clean"
    if state.exam_challenge_score >= 3:
        return "cost"
    return "fail-forward"


def _reset_exam_challenge(state: GameState) -> GameState:
    return replace(
        state,
        exam_challenge_subject=None,
        exam_challenge_step=0,
        exam_challenge_score=0,
    )


def cancel_exam_challenge(
    state: GameState,
    subject: str,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Leave preparation without spending time or leaving a stale challenge."""

    if resolve_balance_profile(profile).calendar_mode == "hourly":
        return _fail(state, "В классическом режиме отдельной подготовки к зачёту нет.")
    if subject not in EXAM_CHALLENGE_SUBJECTS:
        return _fail(state, "Для этого зачёта отдельной подготовки нет.")
    if state.exam_challenge_subject not in (None, subject):
        return _fail(state, "Сначала закончи начатую подготовку к другому зачёту.")
    return _ok(_reset_exam_challenge(state), "Подготовка отложена до следующего зачёта.")


def resolve_exam_beat(
    state: GameState,
    subject: str,
    command: str,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    """Resolve one beat and queue its final preparation effect.

    The beats are deliberately not calendar actions: the surrounding exam
    still costs exactly one 90-minute attempt.  A weak answer does not create a
    plot lock; it merely makes the ordinary attempt less comfortable.
    """

    if resolve_balance_profile(profile).calendar_mode == "hourly":
        return _fail(state, "В классическом режиме отдельной подготовки к зачёту нет.")
    if subject not in EXAM_CHALLENGE_SUBJECTS:
        return _fail(state, "Для этого зачёта отдельной подготовки нет.")
    progress = state.subject(subject)
    if progress is None or subject not in SUBJECTS:
        return _fail(state, "Такого предмета нет в учебном плане.")
    if progress.passed:
        return _fail(state, "Этот зачёт уже закрыт.")
    if not any(appointment.subject == subject for appointment in current_appointments(state)):
        return _fail(state, "Преподаватель сейчас не принимает этот предмет.")
    if state.pending_exam_subject not in (None, subject):
        return _fail(state, "Сначала нужно закончить другую экзаменационную сцену.")
    if state.exam_challenge_subject not in (None, subject):
        return _fail(state, "Начата подготовка к другому зачёту.")
    if exam_challenge_finished(state, subject):
        return _fail(state, "Подготовка уже закончена.")

    step = state.exam_challenge_step
    choices = exam_beat_choices(subject, step)
    selected = next((choice for choice in choices if choice.command == command), None)
    if selected is None:
        return _fail(state, "Такого ответа в этой задаче нет.")

    next_state = replace(
        state,
        exam_challenge_subject=subject,
        exam_challenge_step=step + 1,
        exam_challenge_score=state.exam_challenge_score + selected.points,
    )
    if next_state.exam_challenge_step < EXAM_CHALLENGE_BEATS:
        return _ok(next_state, "Подготовка записана на полях.")

    outcome = exam_challenge_outcome(next_state, subject)
    if outcome == "clean":
        next_state = _queue_exam_effect(next_state, subject, bonus=2)
        message = "Подготовка собрана в цельное решение."
    elif outcome == "cost":
        next_state = _queue_exam_effect(next_state, subject, bonus=1, health_cost=2)
        message = "Решение держится, но потребует лишнего напряжения."
    else:
        next_state = _queue_exam_effect(next_state, subject, penalty=1)
        message = "В конспекте осталась дыра; на зачёте придётся её обойти."
    return _ok(next_state, message)


__all__ = (
    "EXAM_CHALLENGE_BEATS",
    "EXAM_CHALLENGE_SUBJECTS",
    "ExamBeat",
    "ExamBeatChoice",
    "cancel_exam_challenge",
    "exam_beat_choices",
    "exam_beat_prompt_key",
    "exam_challenge_finished",
    "exam_challenge_outcome",
    "resolve_exam_beat",
)
