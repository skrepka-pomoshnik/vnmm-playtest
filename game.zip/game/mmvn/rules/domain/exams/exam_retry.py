"""The visible teacher retry after a failed modern exam."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import BalanceProfile, resolve_balance_profile
from mmvn.constants import RandomSource
from mmvn.models import GameState

from ...helpers_state import (
    _change_stats,
    _fail,
    _ok,
    require_gradebook,
    task_requirement,
)
from ...types import ActionResult, TeacherLastChanceProjection
from .exam_projection import exam_unit_label


def teacher_last_chance_projection(
    state: GameState,
    subject: str,
    profile: BalanceProfile | str | None = None,
) -> TeacherLastChanceProjection | None:
    """Describe the single retry offered after a failed exam.

    The retry does not advance the calendar and never creates a new
    appointment. It is deliberately a small, visible rescue of the just
    finished possibility rather than a hidden extra exam window.
    """

    selected = resolve_balance_profile(profile)
    progress = state.subject(subject)
    try:
        difficulty = selected.subject_difficulty(subject)
    except KeyError:
        difficulty = None
    if progress is None or difficulty is None or progress.passed:
        return None
    flag = f"teacher_last_chance_used:{subject}"
    if state.has_flag(flag):
        return None

    charisma_required = difficulty + 1
    health_cost = selected.teacher_last_chance_health_cost
    probability = 0.42 + 0.07 * (state.charisma - charisma_required + 1)
    probability += 0.02 * max(0, state.stamina - 4)
    probability = min(0.9, max(0.25, probability))
    can_ask = state.charisma >= charisma_required and state.health > health_cost
    return TeacherLastChanceProjection(
        subject=subject,
        charisma_required=charisma_required,
        health_cost=health_cost,
        extra_tasks=1,
        probability=probability,
        can_ask=can_ask,
    )


def take_teacher_last_chance(
    state: GameState,
    subject: str,
    rng: RandomSource | None = None,
    profile: BalanceProfile | str | None = None,
    *,
    projection_fn=None,
) -> ActionResult:
    projection_fn = projection_fn or teacher_last_chance_projection
    """Spend health on one charisma-gated, no-window exam retry."""

    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        return _fail(state, "В классическом режиме последних десяти минут нет.")
    projection = projection_fn(state, subject, profile)
    if projection is None:
        return _fail(state, "Дополнительные десять минут для этого предмета уже недоступны.")
    blocked = require_gradebook(state)
    if blocked is not None:
        return blocked
    if state.charisma < projection.charisma_required:
        return _fail(
            state,
            f"Преподавателя можно попросить ещё десять минут при харизме {projection.charisma_required}.",
        )
    if state.health <= projection.health_cost:
        return _fail(
            state,
            f"На просьбу нужны силы: после −{projection.health_cost} HP герой должен остаться в сознании.",
        )

    pass_roll_failed = rng is not None and rng.random() >= projection.probability
    next_state = _change_stats(
        state,
        health=-projection.health_cost,
        health_cause="exam",
    ).with_flag(f"teacher_last_chance_used:{subject}")
    next_state = replace(next_state, last_exam_subject=subject)
    progress = next_state.subject(subject)
    if progress is None:
        return _fail(state, "Такого предмета нет в учебном плане.")

    if pass_roll_failed:
        return _ok(
            next_state,
            f"Преподаватель дал десять минут, но просьба не помогла: шанс был {projection.probability:.0%}.",
        )

    requirement = task_requirement(state, subject)
    tasks_done = min(requirement, progress.tasks_done + projection.extra_tasks)
    passed = tasks_done >= requirement
    next_progress = replace(progress, tasks_done=tasks_done, passed=passed)
    if passed and not progress.passed:
        next_progress = replace(next_progress, passed_day=state.day)
    next_state = next_state.with_subject(next_progress)
    if subject == "english":
        if passed:
            message = "Дополнительные десять минут помогли: грамматика, письмо и говорение приняты."
        else:
            message = (
                "Дополнительные десять минут закончились: ответ по английскому нужно доработать."
            )
    elif passed:
        message = (
            f"Ещё десять минут помогли: зачёт закрыт, {exam_unit_label(subject)} "
            f"{tasks_done}/{requirement}."
        )
    else:
        message = (
            f"Ещё десять минут закончились: {exam_unit_label(subject)} {tasks_done}/{requirement}."
        )
    return _ok(next_state, message)
