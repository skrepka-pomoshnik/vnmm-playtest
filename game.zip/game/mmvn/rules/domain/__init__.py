"""Focused domain reducers used by the public rules facade."""
