"""End-of-run classification and score reducers."""

from __future__ import annotations

from mmvn.balance import STUDY_FRESH_AIR_STREAK, source_score
from mmvn.constants import SCORE_PRIORITY_SUBJECTS, SUBJECTS
from mmvn.models import GameState

from ..helpers_state import _study_streak


def ending_key(state: GameState) -> str:
    if state.health <= 0:
        return "death"
    if state.has_flag("voluntary_quit"):
        return "voluntary_quit"
    if state.has_flag("restart_finale"):
        return "restart"
    if state.inception >= 3 or state.has_flag("gamma_finale"):
        return "gamma"
    if state.has_flag("patch_used") and state.passed_count == len(SUBJECTS):
        return "author"
    if state.group_score >= 4 and state.has_flag("group_help_used") and state.passed_count >= 5:
        return "group"

    failed = len(SUBJECTS) - state.passed_count
    # A TERKOM career is what you get instead of being thrown out: the player
    # took the job, worked a shift, and the academic week did not come
    # together. It requires accepting the job, because drifting into one shift
    # to afford lunch is not a career -- game/story/endings.rpy already draws
    # that distinction with dlg_ending_epilogues_13. It is checked AFTER every
    # success ending so a good week is never downgraded by having worked
    # (external MDA audit, AUDIT-12/14).
    if state.has_flag("terkom_accepted") and state.work_shifts > 0 and failed >= 3:
        return "terkom"
    if failed == 0:
        return "hero"
    if failed == 1:
        return "one_tail"
    if failed == 2:
        return "mechanics"
    return "expelled"


def exhaustion_note(state: GameState) -> str:
    """Return a player-facing explanation of current exhaustion effects."""

    notes = []
    if state.sleep_debt:
        notes.append("Недосып: без конспекта или запаса выносливости учёба даёт меньше знаний")
    streak = _study_streak(state)
    if streak >= 2:
        if getattr(state, "fresh_air_required", False) and streak >= STUDY_FRESH_AIR_STREAK:
            notes.append("Голова ватная: после трёх сессий подряд нужна прогулка в другую локацию")
        else:
            notes.append(
                "Голова ватная: следующая учебная попытка имеет шанс 60%, потом нужна прогулка"
            )
    if state.health <= 15:
        notes.append("Истощение: следите за здоровьем")
    return " · ".join(notes)


def score_week(state: GameState) -> int:
    """Return the local, deterministic score shown on the end-of-week board."""

    if state.calendar_mode == "hourly":
        passed = tuple(progress.passed for progress in state.subjects)
        passed_days = tuple(
            (progress.passed_day - 1) if progress.passed_day is not None else 5
            for progress in state.subjects
        )
        completed_tasks = tuple(progress.tasks_done for progress in state.subjects)
        return source_score(
            passed,
            passed_days,
            completed_tasks,
            terkom=state.has_flag("terkom_unlocked") or state.has_flag("terkom_job"),
        )

    task_points = sum(progress.tasks_done * 12 for progress in state.subjects)
    passed_points = state.passed_count * 100
    unfinished_penalty = (len(SUBJECTS) - state.passed_count) * 25
    priority_penalty = 0
    for subject in SCORE_PRIORITY_SUBJECTS:
        progress = state.subject(subject)
        if progress is not None and not progress.passed:
            priority_penalty += 15
    early_pass_points = sum(
        max(0, 7 - (progress.passed_day or state.day)) * 5
        for progress in state.subjects
        if progress.passed
    )
    resource_points = state.health * 2 + state.money
    social_points = state.group_score * 10
    work_penalty = state.work_shifts * 5
    return max(
        0,
        passed_points
        + task_points
        + early_pass_points
        + resource_points
        + social_points
        - unfinished_penalty
        - priority_penalty
        - work_penalty,
    )


__all__ = ["ending_key", "exhaustion_note", "score_week"]
