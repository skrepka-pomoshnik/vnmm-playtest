"""Rewards produced by the authored computer-class text quests."""

from __future__ import annotations

from dataclasses import replace

from mmvn.models import GameState

from ..helpers_state import _fail, _ok
from ..types import ActionResult

TEXT_QUEST_REWARDS = {
    "proofchk": ("algebra", "алгебре"),
    "stopper": ("informatics", "информатике"),
}


def apply_text_quest_reward(
    state: GameState,
    quest_id: str,
    outcome: str,
) -> ActionResult:
    """Apply one non-repeatable subject-knowledge reward from a DOS quest.

    ``clean`` and ``cost`` are both considered completed outcomes: the former
    demonstrates the idea, while the latter leaves a useful but imperfect
    tool. Terminal failures deliberately do not grant study progress.
    """

    reward = TEXT_QUEST_REWARDS.get(quest_id)
    if reward is None or outcome not in {"clean", "cost"}:
        return _ok(state, "")

    subject, subject_label = reward
    reward_flag = f"text_quest_reward:{quest_id}"
    if state.has_flag(reward_flag):
        return _ok(state, "")

    progress = state.subject(subject)
    if progress is None:
        return _fail(state, f"В учебном плане нет предмета для награды {quest_id}.")

    updated = replace(progress, knowledge=progress.knowledge + 1)
    next_state = (
        state.with_subject(updated)
        .with_flag(reward_flag)
        .with_flag(f"rumor_quest_completed:{quest_id}")
    )
    return _ok(next_state, f"Квест оставил полезную запись: +1 знание по {subject_label}.")
