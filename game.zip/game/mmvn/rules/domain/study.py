"""Study and retention reducers."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import (
    STUDY_FRESH_AIR_STREAK,
    BalanceProfile,
    resolve_balance_profile,
    source_roll,
    source_study_gain_range,
    source_study_health_cost_range,
    study_success_percent,
)
from mmvn.constants import MAX_KNOWLEDGE, STUDY_LOCATIONS, SUBJECTS, RandomSource
from mmvn.models import GameState

from ..helpers_state import (
    _clear_sleep_debt,
    _fail,
    _mark_study_session,
    _ok,
    _study_streak,
)
from ..helpers_time import (
    _advance_action,
)
from ..types import ActionResult

__all__ = (
    "night_study",
    "study",
    "study_projection",
    "study_success_probability",
)


def study_projection(
    state: GameState,
    subject: str,
    profile: BalanceProfile | str | None = None,
) -> tuple[int, int]:
    """Return knowledge gained and health spent by one study window."""

    selected = resolve_balance_profile(profile)
    progress = state.subject(subject)
    if progress is None or subject not in SUBJECTS:
        return (0, 0)

    if selected.calendar_mode == "hourly":
        relevant = state.stamina if subject == "pe" else state.brain
        gain_range = source_study_gain_range(
            relevant,
            state.health,
            state.hour,
            has_notes=progress.has_notes or state.has_note(subject),
        )
        cost_range = source_study_health_cost_range(
            state.stamina,
            state.hour,
            has_notes=progress.has_notes or state.has_note(subject),
        )
        return gain_range[1], cost_range[1]

    if state.hour >= 19 or state.hour < 4:
        # Penalty increments with every day passed (cumulative night exhaustion)
        day_penalty = (state.day - 1) * 2
        return (1, selected.study_night_health_cost + day_penalty)

    gain = 1 + int(
        progress.has_notes
        or state.has_note(subject)
        or state.brain >= 7
        or state.study_boost_sessions > 0
    )
    health_cost = max(
        1, selected.study_base_health_cost - state.stamina // selected.study_stamina_divisor
    )
    if (
        state.sleep_debt
        and state.stamina < 8
        and not (progress.has_notes or state.has_note(subject))
    ):
        gain = max(0, gain - 1)
    return gain, health_cost


def study_success_probability(
    state: GameState,
    profile: BalanceProfile | str | None = None,
) -> float:
    """Return the chance that the next modern cram session adds knowledge."""

    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        # Classic study keeps its source-backed random gain calculation.
        return 1.0
    attempt = _study_streak(state) + 1
    return study_success_percent(attempt) / 100


def study(
    state: GameState,
    subject: str,
    slots: int = 1,
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    progress = state.subject(subject)
    if progress is None or subject not in SUBJECTS:
        return _fail(state, "Такого предмета нет в учебном плане.")
    if progress.passed:
        return _fail(state, "Этот предмет уже закрыт.")
    if state.location not in STUDY_LOCATIONS:
        return _fail(state, "Здесь невозможно нормально заниматься.")
    if slots != 1:
        return _fail(state, "Одна учебная сессия занимает ровно 45 минут.")
    if state.health <= 0:
        return _fail(state, "Герой уже не может учиться.")

    if selected.calendar_mode == "hourly":
        if state.location != "dorm":
            return _fail(state, "В классическом режиме готовятся в общаге.")
        if rng is None:
            return _fail(state, "Для классической учёбы нужен явный бросок RNG.")
        has_notes = progress.has_notes or state.has_note(subject)
        relevant = state.stamina if subject == "pe" else state.brain

        def roll(stop: int) -> int:
            return source_roll(rng, stop)

        gain = relevant if state.hour < 19 else relevant * 2 // 3
        gain -= roll(relevant // 2)
        gain += roll(state.health // 18)
        if has_notes:
            gain += 10
        penalty = 10 - roll(state.stamina) if state.stamina > 0 else 10
        if penalty < 0 or has_notes:
            penalty = 0
        if state.hour > 21 or state.hour < 4:
            penalty += 12
        knowledge = progress.knowledge + gain
        health_after = max(0, state.health - penalty)
        if health_after > 0 and knowledge > 45:
            health_after = max(0, health_after - 10)
        next_progress = replace(progress, knowledge=knowledge)
        if health_after <= 0:
            return _ok(
                replace(
                    state,
                    stats=replace(state.stats, health=0),
                    last_health_cause="study",
                ).with_subject(next_progress),
                "Герой заучился и больше не может продолжать.",
            )
        next_state = _clear_sleep_debt(_advance_action(state, "study", selected))
        next_state = replace(
            next_state,
            stats=replace(next_state.stats, health=health_after),
            last_health_cause="study",
        ).with_subject(next_progress)
        return _ok(next_state, "Час учёбы прошёл: знания выросли, здоровье уменьшилось.")

    if (
        getattr(state, "fresh_air_required", False)
        and _study_streak(state) >= STUDY_FRESH_AIR_STREAK
    ):
        return _fail(
            state,
            "Голова ватная после зубрёжки: сначала нужна прогулка в другую локацию.",
        )

    gain_per_session, health_cost = study_projection(state, subject, selected)
    knowledge_gain = gain_per_session
    # The boost is only spent when it is what actually carried the session: with
    # a conspect or a high enough brain the extra point comes from those, so the
    # drink stays banked instead of burning on a free session.
    subject_progress = state.subject(subject)
    boost_was_source = (
        state.study_boost_sessions > 0
        and not (subject_progress is not None and subject_progress.has_notes)
        and not state.has_note(subject)
        and state.brain < 7
    )
    night_study = state.hour >= 19 or state.hour < 4
    attempt = _study_streak(state) + 1
    success_percent = study_success_percent(attempt)
    # The Ren'Py adapter always supplies renpy.random.  ``None`` is kept as a
    # deterministic compatibility path for old headless route probes; those
    # probes do not claim to measure stochastic retention.
    retained = success_percent >= 100 or rng is None or rng.randint(1, 100) <= success_percent
    next_state = _clear_sleep_debt(_advance_action(state, "study", selected))
    next_state = _mark_study_session(next_state)
    next_stats = replace(
        next_state.stats,
        health=max(0, next_state.health - health_cost),
    )
    next_progress = replace(
        progress,
        knowledge=(
            min(MAX_KNOWLEDGE, progress.knowledge + knowledge_gain)
            if retained
            else progress.knowledge
        ),
    )
    next_state = replace(
        next_state,
        stats=next_stats,
        last_health_cause="study",
    ).with_subject(next_progress)
    if boost_was_source:
        next_state = replace(next_state, study_boost_sessions=state.study_boost_sessions - 1)
    if night_study:
        next_state = replace(next_state, sleep_debt=True)
        if retained:
            message = (
                "Ночная зубрёжка дала одно знание и оставила долг сна на утро. "
                f"Здоровье: −{health_cost} HP."
            )
        else:
            message = (
                "Ночная зубрёжка не закрепилась: время и здоровье ушли, а знания остались на месте."
                f" Здоровье: −{health_cost} HP."
            )
    elif retained:
        message = f"Знания по предмету выросли, здоровье уменьшилось. Здоровье: −{health_cost} HP."
    else:
        message = (
            f"Голова подвела: знания не закрепились (шанс был {success_percent}%). "
            f"Время и здоровье ушли. Здоровье: −{health_cost} HP."
        )
    streak = _study_streak(next_state)
    if streak == 2:
        message += " После второй сессии голова ватная: следующая попытка будет на 60%; потом нужна прогулка."
    elif streak >= STUDY_FRESH_AIR_STREAK:
        message += " Теперь нужна прогулка в другую локацию, прежде чем снова ботать."
    return _ok(next_state, message)


def night_study(
    state: GameState,
    subject: str,
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        if not (state.hour >= 19 or state.hour < 4):
            return _fail(state, "Ночная зубрёжка доступна после 19:00.")
    elif not (state.hour >= 19 or state.hour < 4):
        return _fail(state, "Ночная зубрёжка доступна после 19:00.")
    return study(state, subject, profile=profile, rng=rng)
