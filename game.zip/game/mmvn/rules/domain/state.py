"""Progress setup, developer reducers and planner forecasts."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import STUDY_FRESH_AIR_STREAK, BalanceProfile, resolve_balance_profile
from mmvn.constants import (
    HERO_TYPE_LABELS,
    HERO_TYPE_STATS,
    MAX_KNOWLEDGE,
    STUDY_LOCATIONS,
    SUBJECTS,
    RandomSource,
)
from mmvn.models import GameState, Stats
from mmvn.schedule import current_appointments
from mmvn.time_budget import format_duration

from ..helpers_state import _fail, _ok, _study_streak, task_requirement
from ..types import ActionResult

__all__ = (
    "action_forecast",
    "debug_resources",
    "debug_subject",
    "give_pomi_ticket",
    "receive_notes",
    "receive_stipend",
    "select_hero",
)


def select_hero(
    state: GameState,
    hero_type: str,
    profile: BalanceProfile | str | None = None,
    rng: RandomSource | None = None,
) -> ActionResult:
    if hero_type not in HERO_TYPE_STATS:
        return _fail(state, "Такого типа героя нет.")
    if state.has_flag("hero_type_selected"):
        return _fail(state, "Начальный тип героя уже выбран.")
    if (state.day, state.slot) != (1, 0):
        return _fail(state, "Тип героя выбирается до начала первой сессии.")

    selected = resolve_balance_profile(profile)
    if selected.calendar_mode == "hourly":
        if rng is None:
            return _fail(state, "Для классического выбора героя нужен явный бросок RNG.")
        # The original menu rolls the selected archetype before it generates
        # the schedule.  Rebuild the complete first state from the stored seed
        # instead of merely replacing three modern stat constants.
        from mmvn.schedule import new_game

        rebuilt = new_game(rng, seed=state.seed, hero_type=hero_type, profile=selected)
        next_state = replace(
            rebuilt,
            event_flags=rebuilt.event_flags
            | state.event_flags
            | frozenset(("hero_type_selected",)),
        )
        return _ok(next_state, f"Начальные условия: {HERO_TYPE_LABELS[hero_type]}.")

    stats = Stats(**HERO_TYPE_STATS[hero_type], money=state.money)
    next_state = replace(state, hero_type=hero_type, stats=stats).with_flag("hero_type_selected")
    return _ok(next_state, f"Начальные условия: {HERO_TYPE_LABELS[hero_type]}.")


def receive_stipend(
    state: GameState,
    profile: BalanceProfile | str | None = None,
) -> ActionResult:
    if state.has_flag("stipend_received"):
        return _fail(state, "Стипендия уже получена.")

    selected = resolve_balance_profile(profile)
    next_stats = replace(state.stats, money=state.money + selected.stipend_amount)
    next_state = replace(
        state,
        stats=next_stats,
        pomi_ticket_uses=state.pomi_ticket_uses + selected.stipend_ticket_uses,
    ).with_flag("stipend_received")
    if selected.stipend_ticket_uses:
        message = "Паша выдал первую стипендию и два железнодорожных билета до Балтийского вокзала."
    else:
        message = f"Паша выдал первую стипендию: {selected.stipend_amount} ₽."
    return _ok(next_state, message)


def give_pomi_ticket(state: GameState, uses: int = 2) -> ActionResult:
    if uses < 1:
        return _fail(state, "Билет должен покрывать хотя бы одну поездку.")
    return _ok(
        replace(state, pomi_ticket_uses=state.pomi_ticket_uses + uses),
        f"Паша добавил {uses} поездки на электричке по железнодорожному билету.",
    )


def receive_notes(state: GameState, subjects: tuple[str, ...]) -> ActionResult:
    unknown = set(subjects) - set(SUBJECTS)
    if unknown:
        return _fail(state, "В конспекте нет такого предмета.")
    if state.has_flag("notes_received"):
        return _fail(state, "Конспекты уже лежат в рюкзаке.")

    next_state = state
    for subject in subjects:
        progress = next_state.subject(subject)
        if progress is not None:
            next_state = next_state.with_subject(replace(progress, has_notes=True))
            next_state = next_state.with_note(subject)
    next_state = next_state.with_flag("notes_received")
    return _ok(next_state, "Саша передал конспекты. Учёба стала дешевле для здоровья.")


def debug_subject(
    state: GameState,
    subject: str,
    knowledge_delta: int = 0,
    tasks_delta: int = 0,
    pass_subject: bool = False,
) -> ActionResult:
    """Developer-only state changes used by the Ren'Py debug panel."""

    progress = state.subject(subject)
    if progress is None or subject not in SUBJECTS:
        return _fail(state, "Такого предмета нет в учебном плане.")

    requirement = task_requirement(state, subject)
    tasks_done = min(requirement, max(0, progress.tasks_done + tasks_delta))
    if pass_subject:
        tasks_done = requirement
    next_progress = replace(
        progress,
        knowledge=min(MAX_KNOWLEDGE, max(0, progress.knowledge + knowledge_delta)),
        tasks_done=tasks_done,
        passed=pass_subject or (progress.passed and tasks_done >= requirement),
        passed_day=state.day if pass_subject and not progress.passed else progress.passed_day,
    )
    return _ok(state.with_subject(next_progress), "DEV: прогресс предмета изменён.")


def debug_resources(
    state: GameState,
    health_delta: int = 0,
    stamina_delta: int = 0,
    money_delta: int = 0,
) -> ActionResult:
    """Developer-only resource changes routed through the immutable kernel."""

    next_stats = replace(
        state.stats,
        health=state.health + health_delta,
        stamina=state.stamina + stamina_delta,
        money=state.money + money_delta,
    )
    return _ok(replace(state, stats=next_stats), "DEV: ресурсы изменены.")


def action_forecast(
    state: GameState,
    profile: BalanceProfile | str | None = None,
) -> str:
    """Return a short deterministic forecast for the planner."""

    selected = resolve_balance_profile(profile)
    if state.health <= 0:
        return "Здоровье исчерпано: следующее действие завершит партию."

    unfinished = None
    for subject in SUBJECTS:
        progress = state.subject(subject)
        if progress is not None and not progress.passed:
            unfinished = subject
            break

    if state.location in STUDY_LOCATIONS and unfinished is not None:
        from .study import study_projection, study_success_probability

        if (
            getattr(state, "fresh_air_required", False)
            and _study_streak(state) >= STUDY_FRESH_AIR_STREAK
        ):
            return "Сначала прогулка в другую локацию, потом учёба."
        gain, cost = study_projection(state, unfinished, selected)
        study_knob = selected.duration.action("study")
        study_time = format_duration(study_knob.minutes) if study_knob else ""

        chance = round(study_success_probability(state, selected) * 100)
        fatigue = " Голова ватная; лучше выйти на воздух." if _study_streak(state) >= 2 else ""
        return f"Учёба: до +{gain} знаний, шанс {chance}%, −{cost} здоровья, {study_time}.{fatigue}"
    if current_appointments(state):
        from .exams import exam_projection

        appointment = current_appointments(state)[0]
        projection = exam_projection(state, appointment.subject, profile=selected)
        if projection is not None:
            return (
                f"Зачёт: до {projection.base_tasks} пунктов "
                f"за {projection.base_health_cost} здоровья."
            )
        return "Сейчас доступен зачёт: результат зависит от подготовки и тактики."
    if state.location == "dorm":
        return "В общаге доступны отдых и ожидание."
    wait_knob = selected.duration.action("wait")
    wait_time = format_duration(wait_knob.minutes) if wait_knob else ""
    return f"Следующее действие займёт {wait_time}, если оно разрешено локацией."
