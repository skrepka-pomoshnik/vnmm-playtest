"""Domain module extracted from rules._impl."""

from __future__ import annotations

from dataclasses import dataclass

from mmvn.models import GameState


@dataclass(frozen=True)
class ActionResult:
    state: GameState
    ok: bool
    message: str


@dataclass(frozen=True)
class ExamProjection:
    subject: str
    difficulty: int
    relevant: int
    base_tasks: int
    base_health_cost: int
    can_push: bool
    can_talk: bool

    @property
    def unit_label(self) -> str:
        """Return the activity counted by this subject's exam."""

        from .domain.exams import exam_unit_label

        return exam_unit_label(self.subject)


@dataclass(frozen=True)
class TeacherLastChanceProjection:
    """Visible cost and charisma check for the one immediate retry."""

    subject: str
    charisma_required: int
    health_cost: int
    extra_tasks: int
    probability: float
    can_ask: bool
