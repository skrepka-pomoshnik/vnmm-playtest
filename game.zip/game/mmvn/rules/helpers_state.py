"""Immutable state reducers shared by domain actions."""

from __future__ import annotations

from dataclasses import replace

from mmvn.balance import MODERN_BALANCE, STUDY_FATIGUE_STREAK
from mmvn.constants import REQUIRED_TASKS
from mmvn.models import GameState, TabletRecord

from .types import ActionResult

FOOD_OPTIONS = MODERN_BALANCE.food_options

# The board shows a fixed number of rows, matching the display cap.
TABLETS_BOARD_LIMIT = 5

TABLETS_GHOST_ROWS = (
    {
        "name": "Коля",
        "ending": "старый рекорд",
        "score": 400,
        "passed": 4,
        "origin": "ghost",
    },
    {
        "name": "Саша",
        "ending": "проверено карандашом",
        "score": 280,
        "passed": 3,
        "origin": "ghost",
    },
    {
        "name": "Эндрю",
        "ending": "почти доказано",
        "score": 180,
        "passed": 2,
        "origin": "ghost",
    },
    {
        "name": "Паша",
        "ending": "окно найдено",
        "score": 100,
        "passed": 1,
        "origin": "ghost",
    },
    {
        "name": "Гриша",
        "ending": "сдача отложена",
        "score": 20,
        "passed": 0,
        "origin": "ghost",
    },
)


def tablets_display_rows(player_rows: tuple[dict, ...] | list[dict] | None) -> tuple[dict, ...]:
    """Merge local runs with fixed diegetic starter rows without mutation."""

    rows = [dict(row) for row in TABLETS_GHOST_ROWS]
    rows.extend(dict(row) for row in (player_rows or ()))
    rows.sort(key=lambda row: int(row.get("score", 0)), reverse=True)
    return tuple(rows[:5])


def record_week_result(state: GameState, ending: str, score: int) -> GameState:
    """Store this playthrough's end-of-week result on the board.

    Results are gameplay progress, so they belong to the state and to ordinary
    saves, not to ``persistent``. The board therefore shows the current run plus
    the diegetic starter rows, and a new game starts clean. Repeating the same
    ending at the same credit count replaces the earlier row instead of filling
    the board with duplicates, and only the five strongest results are kept.
    """

    record = TabletRecord(
        ending=ending,
        score=score,
        passed=state.passed_count,
        day=state.day,
        inception=state.inception,
        seed=state.seed,
        passed_days=tuple(
            (progress.subject, progress.passed_day)
            for progress in state.subjects
            if progress.passed and progress.passed_day is not None
        ),
    )
    kept = [
        row
        for row in state.tablets
        if not (row.ending == ending and row.passed == record.passed and row.seed == record.seed)
    ]
    kept.append(record)
    kept.sort(key=lambda row: row.score, reverse=True)
    return replace(state, tablets=tuple(kept[:TABLETS_BOARD_LIMIT]))


def _ok(state: GameState, message: str) -> ActionResult:
    return ActionResult(state=state, ok=True, message=message)


def require_gradebook(state: GameState) -> ActionResult | None:
    """Инвентарный контракт 0.3-C: без зачётки экзамен не закрывается."""

    if state.has_flag("has_gradebook"):
        return None
    return _fail(state, "Зачётка осталась в общаге — без неё задания не примут.")


def _fail(state: GameState, message: str) -> ActionResult:
    return ActionResult(state=state, ok=False, message=message)


def mark_flag(state: GameState, flag: str, message: str = "") -> ActionResult:
    """Record a story boundary without letting labels mutate the state directly."""

    if not flag:
        return _fail(state, "Нельзя записать пустой флаг.")
    return _ok(state.with_flag(flag), message)


def dream_is_due(state: GameState) -> bool:
    """Return whether the next sleep may reveal one authored dream fragment."""

    if state.has_flag("dream_seen"):
        return False
    return (
        state.sleep_debt
        or state.health <= 25
        or state.has_flag("djug_aftereffect")
        or state.inception > 0
    )


def record_dream(state: GameState) -> ActionResult:
    """Record the single authored dream and reward only a meta run."""

    if state.has_flag("dream_seen"):
        return _fail(state, "Этот фрагмент сна уже записан.")
    next_state = state.with_flag("dream_seen")
    if state.inception > 0:
        next_state = replace(next_state, memory_shards=state.memory_shards + 1)
        message = "Сон оставил один фрагмент памяти. Остальное исчезло до пробуждения."
    else:
        message = "Сон записан. Утром останется только ощущение, что это уже было."
    return _ok(next_state, message)


def _clear_sleep_debt(state: GameState) -> GameState:
    if not state.sleep_debt:
        return state
    return replace(state, sleep_debt=False)


def _study_streak(state: GameState) -> int:
    """Read the cram counter while remaining safe for pre-counter saves."""

    return max(0, int(getattr(state, "study_streak", 0)))


def _mark_study_session(state: GameState) -> GameState:
    """Record one study attempt and flag the point where air is needed."""

    streak = _study_streak(state) + 1
    return replace(
        state,
        study_streak=streak,
        fresh_air_required=streak >= STUDY_FATIGUE_STREAK,
    )


def _clear_study_streak(state: GameState) -> GameState:
    """Reset cram fatigue after a physical reset such as walking or sleeping."""

    if _study_streak(state) == 0 and not getattr(state, "fresh_air_required", False):
        return state
    return replace(state, study_streak=0, fresh_air_required=False)


def _grant_study_boost(state: GameState) -> GameState:
    """Top the temporary study edge up to its full length.

    Decided 02.10.2026 (AUDIT-09): the study gain keys off `brain >= 7`, so any
    permanent `brain + 1` is a permanent doubling of studying. Every "you learned
    something" reward now grants this counted boost instead. It refreshes to full
    rather than stacking, so the edge always expires.
    """

    from mmvn.constants import STUDY_BOOST_SESSIONS

    return replace(
        state,
        study_boost_sessions=max(state.study_boost_sessions, STUDY_BOOST_SESSIONS),
    )


def _change_stats(
    state: GameState,
    *,
    health: int = 0,
    brain: int = 0,
    stamina: int = 0,
    charisma: int = 0,
    money: int = 0,
    health_cause: str | None = None,
) -> GameState:
    next_stats = replace(
        state.stats,
        health=state.health + health,
        brain=state.brain + brain,
        stamina=state.stamina + stamina,
        charisma=state.charisma + charisma,
        money=state.money + money,
    )
    next_state = replace(state, stats=next_stats)
    if health < 0 and health_cause:
        next_state = replace(next_state, last_health_cause=health_cause)
    return next_state


def _change_trust(state: GameState, character: str, delta: int) -> GameState:
    relation = state.relationship(character)
    if relation is None:
        return state
    updated = replace(relation, trust=max(0, relation.trust + delta))
    return state.with_relationship(updated)


def _change_irritation(state: GameState, character: str, delta: int) -> GameState:
    relation = state.relationship(character)
    if relation is None:
        return state
    updated = replace(relation, irritation=max(0, relation.irritation + delta))
    return state.with_relationship(updated)


def task_requirement(state: GameState, subject: str) -> int:
    """Resolve a subject limit from state, preserving old-save behavior."""

    progress = state.subject(subject)
    if progress is not None:
        return progress.required_tasks
    return REQUIRED_TASKS[subject]


def _change_subject(
    state: GameState,
    subject: str,
    *,
    knowledge: int = 0,
    tasks: int = 0,
) -> GameState:
    progress = state.subject(subject)
    if progress is None:
        return state
    requirement = task_requirement(state, subject)
    passed = progress.passed or progress.tasks_done + tasks >= requirement
    passed_day = progress.passed_day
    if passed and not progress.passed:
        passed_day = state.day
    updated = replace(
        progress,
        knowledge=progress.knowledge + knowledge,
        tasks_done=progress.tasks_done + tasks,
        passed=passed,
        passed_day=passed_day,
    )
    return state.with_subject(updated)


def _queue_exam_effect(
    state: GameState,
    subject: str,
    *,
    bonus: int = 0,
    penalty: int = 0,
    health_cost: int = 0,
) -> GameState:
    if state.pending_exam_subject not in (None, subject):
        return state
    return replace(
        state,
        pending_exam_subject=subject,
        pending_exam_bonus=state.pending_exam_bonus + bonus,
        pending_exam_penalty=state.pending_exam_penalty + penalty,
        pending_exam_health_cost=state.pending_exam_health_cost + health_cost,
    )


def _clear_exam_effect(state: GameState) -> GameState:
    return replace(
        state,
        pending_exam_subject=None,
        pending_exam_bonus=0,
        pending_exam_penalty=0,
        pending_exam_health_cost=0,
        exam_challenge_subject=None,
        exam_challenge_step=0,
        exam_challenge_score=0,
    )
