"""Stable identifiers and balance constants for the game kernel."""

from collections.abc import Sequence
from typing import Any, Protocol

from . import time_budget
from .balance import MODERN_BALANCE

SLOT_HOURS = time_budget.SLOT_HOURS
SLOT_LABELS = time_budget.SLOT_LABELS

SUBJECTS = (
    "algebra",
    "matan",
    "geometry",
    "informatics",
    "english",
    "pe",
)

# These subjects define the academic backbone of the week. Leaving one of
# them open is a stronger signal in the local end-of-week score.
SCORE_PRIORITY_SUBJECTS = ("algebra", "matan", "informatics")

SUBJECT_LABELS = {
    "algebra": "Алгебра",
    "matan": "Матан",
    "geometry": "Геометрия и топология",
    "informatics": "Информатика",
    "english": "Английский",
    "pe": "Физкультура",
}

SLOTS_PER_DAY = len(SLOT_HOURS)

# Lore-canon student helpers. Trust with these characters lowers the health cost
# of an exam in their subject, which is the only currency exploration pays in:
# knowledge stays study-only so the knowledge wall is never cheapened.
# Only characters with a real trust route belong here; `tests` assert that.
EXAM_MENTORS = {
    "algebra": "kolya",
    "english": "li",
    "geometry": "djug",
    "informatics": "kuzmenko",
    "pe": "serge",
}
MAX_EXAM_MENTOR_DISCOUNT = 3

# Miss Li's exercises are free and repeatable, so they are capped below
# STANDING_DEPTH. The safe route buys a foothold and cannot be farmed into the
# deeper trust that the sixth credit rewards; only the risky talk can do that.
HOMEWORK_TRUST_CAP = 1

# Shape of the social web the top band demands, in order: the fifth credit
# needs breadth (this many separate people), the sixth needs depth (this much
# trust with one person). A count would make every web equivalent.
STANDING_BREADTH = 2
STANDING_DEPTH = 2

LOCATIONS = (
    "dorm",
    "faculty",
    "pomi",
    "computer_lab",
    "mausoleum",
)

LOCATION_LABELS = {
    "dorm": "Общежитие",
    "faculty": "Факультет",
    "pomi": "ПОМИ",
    "computer_lab": "Компьютерный класс",
    "mausoleum": "Мавзолей",
}

STUDY_LOCATIONS = ("dorm", "faculty", "pomi", "computer_lab")
EXAM_LOCATIONS = ("faculty", "pomi", "computer_lab", "mausoleum")
EXAM_HOURS = SLOT_HOURS

# Only the POMI route has a direct cost in the current ruleset. The other
# destinations still consume a time window, but do not charge a fare.
# Compatibility views for callers that still need the current profile's
# values. Reducers resolve the selected BalanceProfile explicitly.
TRAVEL_FARES = dict(MODERN_BALANCE.travel_fares)
TRAVEL_HEALTH_COSTS = dict(MODERN_BALANCE.travel_health_costs)

TRAVEL_MISHAP_FLAGS = {
    "martyshkino": "mishap_martyshkino_seen",
    "remiz": "mishap_remiz_seen",
    "dogs": "mishap_dogs_seen",
}

TEACHERS = {
    "algebra": "Зильберборд",
    "matan": "Флоринский",
    "geometry": "Нежинский",
    "informatics": "Кузьменко",
    "english": "Мисс Ли",
    "pe": "Тренер",
}

REQUIRED_TASKS = {
    "algebra": 4,
    "matan": 4,
    "geometry": 3,
    "informatics": 3,
    "english": 2,
    "pe": 2,
}

SUBJECT_DIFFICULTIES = {
    "algebra": 6,
    "matan": 7,
    "geometry": 5,
    "informatics": 5,
    "english": 4,
    "pe": 3,
}

CHARACTERS = (
    "pasha",
    "sasha",
    "kolya",
    "shuler",
    "rai",
    "nil",
    "misha",
    "serge",
    "kuzmenko",
    "djug",
    "andrew",
    "grisha",
    "li",
)

PRESENCE_LABELS = {
    "neighbor": "Сосед",
    "pasha": "Паша",
    "sasha": "Саша",
    "li": "Мисс Ли",
    "kolya": "Коля",
    "shuler": "Шулер",
    "rai": "Рай",
    "nil": "NiL",
    "misha": "Миша",
    "serge": "Серж",
    "kuzmenko": "Кузьменко",
    "djug": "Джуга",
    "andrew": "Эндрю",
    "grisha": "Гриша",
    "mantra": "Мантра",
}

HERO_TYPE_LABELS = {
    "theorist": "Теоретик",
    "survivor": "Живучий",
    "connector": "Связной",
    "universal": "Универсал",
}

HERO_TYPE_STATS = {
    "theorist": {"health": 60, "brain": 8, "stamina": 4, "charisma": 3},
    "survivor": {"health": 75, "brain": 4, "stamina": 8, "charisma": 3},
    "connector": {"health": 65, "brain": 4, "stamina": 5, "charisma": 8},
    "universal": {"health": 65, "brain": 6, "stamina": 6, "charisma": 6},
}

INITIAL_MONEY = 0
STIPEND_AMOUNT = 50
MAX_HEALTH = 100
MAX_STAMINA = 10
MAX_KNOWLEDGE = 6
LAST_DAY = 6
# How many study sessions a brain-sharpening drink buys. The boost is counted in
# sessions, not clock, so it always expires and the player can see it running out
# in the planner (AUDIT-09).
STUDY_BOOST_SESSIONS = 3


# --- RNG boundary (merged from rng.py) ---


class RandomSource(Protocol):
    def random(self) -> float: ...

    def randrange(self, stop: int, /) -> int: ...

    def randint(self, lower: int, upper: int, /) -> int: ...

    def choice(self, values: Sequence[Any], /) -> Any: ...


def seed_rng(rng: RandomSource, seed: int) -> None:
    """Seed a Ren'Py-compatible RNG when the implementation supports it."""

    seed_method = getattr(rng, "seed", None)
    if seed_method is not None:
        seed_method(seed)
