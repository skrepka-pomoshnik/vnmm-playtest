"""Stable IDs for authored content, runtime labels and QA traces."""

from __future__ import annotations


def _semantic_part(value: str) -> str:
    """Normalize one identifier component without changing its meaning."""

    normalized = "".join(
        character.lower() if character.isalnum() or character == "_" else "_"
        for character in value.strip()
    ).strip("_")
    if not normalized:
        raise ValueError("semantic identifier parts cannot be empty")
    return normalized


def semantic_id(namespace: str, *parts: str) -> str:
    """Build a stable dotted ID from source identifiers.

    Semantic IDs deliberately do not contain source line numbers. Moving a
    label or changing prose therefore does not break a trace binding.
    """

    namespace_parts = tuple(namespace.split("."))
    if not namespace_parts or any(not part for part in namespace_parts):
        raise ValueError("semantic identifier namespace cannot contain empty parts")
    values = (
        *(_semantic_part(part) for part in namespace_parts),
        *(_semantic_part(part) for part in parts),
    )
    return ".".join(values)


def quest_node_semantic_id(
    quest_id: str,
    node_id: str,
    *,
    namespace: str = "quest",
) -> str:
    """Return the canonical ID for a design or authored quest node."""

    return semantic_id(namespace, quest_id, node_id)


def action_semantic_id(action: str) -> str:
    """Return a trace-friendly ID for a reducer action key."""

    parts = tuple(part for part in action.split(":") if part)
    return semantic_id("action", *(parts or ("unknown",)))


def runtime_label_semantic_id(
    label_name: str,
    source_path: str,
    *,
    is_qa: bool = False,
) -> str:
    """Namespace a Ren'Py label by the executable/content surface it serves.

    The source path is used only to select a namespace; it is not embedded in
    the ID. This keeps full ``MMHEROES.EXE``, authored DOS programs, ZORK and
    plot labels distinct while allowing files to move inside their surface.
    """

    path = source_path.replace("\\", "/").lower()
    path_marker = f"/{path}"
    if is_qa or "/dev/" in path_marker:
        namespace = "qa"
    elif "/ui/mmheroes/test_quests.rpy" in path_marker:
        namespace = "quest.dos"
    elif "/ui/mmheroes/zork.rpy" in path_marker:
        namespace = "quest.zork"
    elif "/mmheroes/" in path_marker or path.endswith("/mmheroes.rpy"):
        namespace = "nested.mmheroes"
    elif "/story/" in path_marker or "/dialogue/" in path_marker:
        namespace = "story"
    else:
        namespace = "runtime"
    return semantic_id(namespace, label_name)


__all__ = [
    "action_semantic_id",
    "quest_node_semantic_id",
    "runtime_label_semantic_id",
    "semantic_id",
]
