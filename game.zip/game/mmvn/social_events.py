"""Seeded locations for the optional evening social event."""

from .models import GameState

SOCIAL_EVENT_LABELS = {
    "birthday": "день рождения в соседней комнате",
    "shajba": "дискотека в «Шайбе»",
    "mafia": "мафия на кухне",
    "quake": "одна партия в Quake",
    "preference": "компания преферансистов",
}
SOCIAL_EVENTS = tuple(SOCIAL_EVENT_LABELS)
SOCIAL_EVENT_LOCATIONS = {
    "birthday": "dorm",
    "shajba": "dorm",
    "mafia": "dorm",
    "quake": "computer_lab",
    "preference": "dorm",
}


def social_event_for(state: GameState) -> str:
    """Return the one social event selected for this run and current evening."""

    index = (state.seed + state.day + state.slot) % len(SOCIAL_EVENTS)
    return SOCIAL_EVENTS[index]


def social_event_available_at(state: GameState) -> bool:
    """Return whether the seeded evening event belongs at the current place."""

    event = social_event_for(state)
    return state.location == SOCIAL_EVENT_LOCATIONS[event]


__all__ = [
    "SOCIAL_EVENTS",
    "SOCIAL_EVENT_LABELS",
    "SOCIAL_EVENT_LOCATIONS",
    "social_event_available_at",
    "social_event_for",
]
