"""Cheap structural checks for rollback-safe gameplay states."""

from __future__ import annotations

from .balance import STUDY_FATIGUE_STREAK
from .constants import (
    CHARACTERS,
    HERO_TYPE_LABELS,
    LOCATIONS,
    MAX_HEALTH,
    MAX_KNOWLEDGE,
    MAX_STAMINA,
    REQUIRED_TASKS,
    SLOTS_PER_DAY,
    SUBJECTS,
)
from .models import GameState


def state_invariant_errors(state: GameState) -> tuple[str, ...]:
    """Return every structural violation found in an immutable game state."""

    errors: list[str] = []

    if state.day < 1:
        errors.append("day must be positive")
    if not 0 <= state.slot < SLOTS_PER_DAY:
        errors.append("slot must be a canonical daily window")
    if state.location not in LOCATIONS:
        errors.append("location must be a known location")
    if state.hero_type not in HERO_TYPE_LABELS:
        errors.append("hero_type must be a known profile")
    if state.calendar_mode not in {"continuous", "hourly"}:
        errors.append("calendar_mode must be continuous or hourly")
    if state.clock_hour is None or not 0 <= state.clock_hour < 24:
        errors.append("state must have a valid continuous clock hour")
    if state.minute_offset < 0 or state.minute_offset >= 60:
        errors.append("minute offset must be inside the current hour")

    if not 0 <= state.health <= MAX_HEALTH:
        errors.append("health is outside its allowed range")
    if not 0 <= state.stamina <= MAX_STAMINA:
        errors.append("stamina is outside its allowed range")
    if state.brain < 0:
        errors.append("brain must not be negative")
    if state.charisma < 0:
        errors.append("charisma must not be negative")
    if state.money < 0:
        errors.append("money must not be negative")

    if state.schedule_variant not in {"A", "B"}:
        errors.append("schedule_variant must be A or B")
    if state.group_score < 0:
        errors.append("group_score must not be negative")
    if state.memory_shards < 0:
        errors.append("memory_shards must not be negative")
    if state.inception < 0:
        errors.append("inception must not be negative")
    if state.work_shifts < 0:
        errors.append("work_shifts must not be negative")
    if state.pomi_ticket_uses < 0:
        errors.append("pomi_ticket_uses must not be negative")
    if state.garlic_minutes < 0:
        errors.append("garlic_minutes must not be negative")
    if state.last_meal_at is not None and state.last_meal_at < 0:
        errors.append("last_meal_at must be non-negative")
    study_streak = getattr(state, "study_streak", 0)
    if study_streak < 0:
        errors.append("study_streak must not be negative")
    if getattr(state, "fresh_air_required", False) and study_streak < STUDY_FATIGUE_STREAK:
        errors.append("fresh_air_required needs the fatigue streak")

    subject_ids = tuple(progress.subject for progress in state.subjects)
    if set(subject_ids) != set(SUBJECTS) or len(subject_ids) != len(set(subject_ids)):
        errors.append("subjects must contain each canonical subject exactly once")
    for progress in state.subjects:
        requirement = progress.required_tasks
        if requirement is None:
            errors.append(f"unknown subject progress: {progress.subject}")
            continue
        knowledge_limit = progress.knowledge_limit or MAX_KNOWLEDGE
        if not 0 <= progress.knowledge <= knowledge_limit:
            errors.append(f"knowledge out of range: {progress.subject}")
        if not 0 <= progress.tasks_done <= requirement:
            errors.append(f"tasks out of range: {progress.subject}")
        if progress.passed and progress.tasks_done < requirement:
            errors.append(f"passed subject is below its task requirement: {progress.subject}")
        if progress.passed_day is not None and not progress.passed:
            errors.append(f"unpassed subject has a passed_day: {progress.subject}")
        if progress.passed_day is not None and progress.passed_day > state.day:
            errors.append(f"passed_day is in the future: {progress.subject}")

    relationship_ids = tuple(relation.character for relation in state.relationships)
    if set(relationship_ids) != set(CHARACTERS) or len(relationship_ids) != len(
        set(relationship_ids)
    ):
        errors.append("relationships must contain each canonical character exactly once")
    for relation in state.relationships:
        if relation.trust < 0 or relation.debt < 0 or relation.irritation < 0:
            errors.append(f"negative relationship value: {relation.character}")

    if len(state.debts) != len(set(state.debts)):
        errors.append("debts must not contain duplicate IDs")
    if not state.notes.issubset(SUBJECTS):
        errors.append("notes contain an unknown subject")
    if state.reserve_subject is not None and state.reserve_subject not in SUBJECTS:
        errors.append("reserve_subject must be a known subject")
    if state.note_subject is not None and state.note_subject not in SUBJECTS:
        errors.append("note_subject must be a known subject")

    if state.pending_exam_subject is not None and state.pending_exam_subject not in SUBJECTS:
        errors.append("pending_exam_subject must be a known subject")
    if state.last_exam_subject is not None and state.last_exam_subject not in SUBJECTS:
        errors.append("last_exam_subject must be a known subject")
    if state.pending_exam_bonus < 0:
        errors.append("pending_exam_bonus must not be negative")
    if state.pending_exam_penalty < 0:
        errors.append("pending_exam_penalty must not be negative")
    if state.pending_exam_health_cost < 0:
        errors.append("pending_exam_health_cost must not be negative")
    if state.pending_exam_subject is None and any(
        (state.pending_exam_bonus, state.pending_exam_penalty, state.pending_exam_health_cost)
    ):
        errors.append("pending exam modifiers require a pending subject")

    challenge_subject = getattr(state, "exam_challenge_subject", None)
    challenge_step = getattr(state, "exam_challenge_step", 0)
    challenge_score = getattr(state, "exam_challenge_score", 0)
    if challenge_subject is not None and challenge_subject not in SUBJECTS:
        errors.append("exam_challenge_subject must be a known subject")
    if not 0 <= challenge_step <= 3:
        errors.append("exam_challenge_step must be between zero and three")
    if not 0 <= challenge_score <= 6:
        errors.append("exam_challenge_score must be between zero and six")
    if challenge_subject is None and (challenge_step or challenge_score):
        errors.append("exam challenge progress requires a subject")

    schedule_keys = set()
    for appointment in state.schedule:
        key = (
            appointment.day,
            appointment.start_minute,
            appointment.end_minute,
            appointment.subject,
            appointment.location,
        )
        if key in schedule_keys:
            errors.append(f"duplicate appointment: {key}")
        schedule_keys.add(key)
        if appointment.day < 1 or not 0 <= appointment.slot < SLOTS_PER_DAY:
            errors.append(f"appointment outside calendar: {key}")
        if not (0 <= appointment.start_minute < appointment.end_minute <= 24 * 60):
            errors.append(f"appointment has invalid interval: {key}")
        if appointment.subject not in SUBJECTS:
            errors.append(f"appointment has unknown subject: {key}")
        if appointment.location not in LOCATIONS:
            errors.append(f"appointment has unknown location: {key}")
        appointment_progress = state.subject(appointment.subject)
        expected_requirement = (
            appointment_progress.required_tasks
            if appointment_progress is not None
            else REQUIRED_TASKS.get(appointment.subject)
        )
        if appointment.required_tasks != expected_requirement:
            errors.append(f"appointment has incorrect task requirement: {key}")

    if not isinstance(state.event_flags, frozenset):
        errors.append("event_flags must be a frozenset")
    if not isinstance(state.notes, frozenset):
        errors.append("notes must be a frozenset")
    if not isinstance(state.ending_tags, frozenset):
        errors.append("ending_tags must be a frozenset")

    return tuple(errors)
