#!/usr/bin/env python3
"""Compatibility loader for the standalone MMHEROES legacy namespace.

The port intentionally keeps its historical global state and menu protocol.
Its executable source is split into focused fragments so the playable port can
be maintained without turning one file into a second domain monolith.  The
fragments are evaluated in this module's namespace; public imports and the
standalone CLI therefore keep their existing behaviour.
"""

from pathlib import Path

_LEGACY_PARTS = (
    "core/bootstrap.py",
    "core/terminal.py",
    "core/time.py",
    "core/interface.py",
    "gameplay/actions.py",
    "gameplay/exams.py",
    "gameplay/dialogue.py",
    "gameplay/scenes.py",
    "gameplay/game.py",
    "bridge/embed.py",
    "bridge/cli.py",
)


def _load_legacy_namespace() -> None:
    parts_root = Path(__file__).with_name("parts")
    namespace = globals()
    for relative_path in _LEGACY_PARTS:
        path = parts_root / relative_path
        source = path.read_text(encoding="utf-8")
        exec(compile(source, str(path), "exec"), namespace, namespace)


_load_legacy_namespace()
del _load_legacy_namespace
