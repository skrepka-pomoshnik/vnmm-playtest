# --------------------------------------------------------------- разговоры


def t_kolya():
    hdr()
    say('Коля смотрит на тебя немного окосевшими глазами.')
    if g.char > R(10) and g.done[ALG] + 2 <= SUBJ[ALG][5]:
        say('"У тебя остались нерешенные задачи по Всемирнову? Давай сюда!"')
        g.done[ALG] += 2
        say('Коля решил тебе еще 2 задачи по алгебре!')
        pause()
        hour_pass()
        return
    say('"Знаешь, пиво, конечно, хорошо, но настойка овса - лучше!"')
    if g.money <= 15:
        say('Коля достает тормозную жидкость, и вы распиваете еще по стакану.')
        g.brain -= 1
        if g.brain <= 0:
            g.hp = 0
            die('Спился.')
        pause()
        return
    r = menu('Заказать Коле настойку овса?', [('Да', 1), ('Нет', 2)])
    if r == 1:
        g.money -= 15
        if g.char > R(10) and g.done[ALG] + 1 < SUBJ[ALG][5]:
            say('"У тебя остались нерешенные задачи по Всемирнову? Давай сюда!"')
            g.done[ALG] += 2
            say('Коля решил тебе еще 2 задачи по алгебре!')
            pause()
            hour_pass()
            return
        say('Твой альтруизм навсегда останется в памяти потомков.')
    else:
        say('"Зря, ой, зря ..."')
        say('Коля достает тормозную жидкость, и вы распиваете еще по стакану.')
        g.brain -= 1
    pause()


def t_pasha():
    hdr()
    if not g.stipend:
        g.stipend = 1
        say('Паша вручает тебе твою стипуху за май: 50 руб.')
        g.money += 50
    else:
        say('Паша воодушевляет тебя на великие дела.')
        say('Вместе с этим он немного достает тебя.')
        g.stam += 1
        for i in range(6):
            if g.know[i] > 3:
                g.know[i] -= R(3)
    pause()


def t_diamond():
    hdr()
    say('Wow! Ты только что встретил автора !')
    if not g.disk and g.place == COMP and R(8) == 0:
        say('"Хочешь по-тестить новую версию Heroes of MAT-MEX?"')
        r = menu('', [('ДА, КОНЕЧНО, ОЧЕНЬ ХОЧУ!', 1),
                      ('Нет, у меня нет на это времени...', 2)])
        if r == 1:
            say('"Ну и ладушки! Вот тебе дискетка..."')
            g.disk = 1
        else:
            say('"Извини, что побеспокоил."')
        pause()
        return
    say('Diamond: ' + choice(DIAMOND_HINTS))
    if g.cs == -1 and R(2) == 0:
        say('Diamond убегает по своим делам ...')
        g.cm[DIA]['p'] = 0
        g.cm[DIA]['s'] = -1
    pause()


def t_rai():
    if g.cs >= 3 or g.cs == -1:
        hdr()
        say('RAI не реагирует на твои позывы.')
        pause()
        return
    s = g.cs
    hdr()
    say('RAI: "Ты мне поможешь?"')
    r = menu('', [('"Да, конечно"', 1), ('"Нет, извини..."', 2)])
    if r == 1:
        if R(g.know[s]) > R(SUBJ[s][3]):
            say('Ты помог RAI.')
            g.brain += 1
        else:
            say('Ничего не вышло.')
        hour_pass()
    else:
        say('"Ах, так! Получай! Получай!"')
        say('RAI делает тебе больно ...')
        dec_hp(10, 'RAI замочил.')
    pause()


def t_misha():
    hdr()
    if g.place != COMP and g.cs != -1:
        say('Миша : "Слушай, хватит мучаться! Прервись!')
        say('Давай в клоподавку сыграем!"')
        r = menu('', [('"Давай!"', 1), ('"Нет, не буду я в клоподавку ..."', 2)])
        if r == 1:
            say('Ты сыграл с Мишей партию в клоподавку.')
            g.char += 1
            pause()
            hour_pass()
        else:
            say('"Зря, очень зря!"')
            g.char -= R(2)
            pause()
        return
    if g.place == PUNK and g.cs == -1 and g.terkom and g.char > R(8):
        say('Миша : "Слушай, а ведь в ТЕРКОМе есть столик для тенниса. Сыграем?"')
        r = menu('', [('"Обязательно!"', 1), ('"Извини, потом."', 2)])
        if r == 1:
            say('Ты сыграл с Мишей в теннис.')
            g.char += 1
            if g.char < R(10):
                dec_hp(R(3) + 3, 'Загонял тебя Миша.')
            else:
                pause()
                hour_pass()
        else:
            say('"Ничего, я на тебя не в обиде."')
            pause()
        return
    say('Миша: ' + choice(MISHA_HINTS))
    pause()


def t_serzh():
    hdr()
    wr('Серж: ')
    if R(g.char) <= R(3) + 2 and g.char * 2 + 20 > g.hp:
        say('"На, глотни кефирчику."')
        g.hp += g.char + R(g.char)
        if g.cs != -1 and g.know[g.cs] > 3:
            g.know[g.cs] -= R(3)
    elif R(g.char) > R(6) + 2 and g.know[FIZ] < 10:
        say('"Я знаю, где срезать в парке на физ-ре!"')
        g.know[FIZ] += 30
    else:
        say(choice(SERZH_HINTS))
    if g.char < R(9):
        say('Серж уходит куда-то по своим делам ...')
        g.cm[SER]['s'] = -1
        g.cm[SER]['p'] = 0 if g.cm[SER]['p'] == MAUS else MAUS
    pause()


def t_sasha():
    hdr()
    say('Ты встретил Сашу! Говорят, у него классные конспекты ...')
    items = [(SUBJ[i][1], i) for i in range(3) if not g.syn[i]['h']]
    items.append(('Ничего не надо', -1))
    r = menu('Чего тебе надо от Саши?', items)
    if r == -1:
        say('Как знаешь...')
    elif g.char > R(18) and g.syn[r]['s']:
        say('Саша: "Да, у меня с собой этот конспект ..."')
        g.syn[r]['h'] = 1
    else:
        say('Саша: "Ох, извини, кто-то другой уже позаимствовал ..."')
        g.syn[r]['s'] = 0
    pause()


def t_nil():
    hdr()
    if g.cs == -1:
        say('Ты заводишь с NiL светскую беседу.')
        say('Тебе поплохело.')
        dec_hp(10, 'Общение с NiL оказалось выше человеческих сил.')
        pause()
        return
    s = g.cs
    say('"Маладой чилавек, вы мне не паможите решить задачу?\n'
        'А то я сигодня ни в зуб нагой ..."')
    r = menu('', [('"Да, конечно"', 1), ('"Извини, в другой раз"', 2)])
    if r == 1:
        if g.know[s] > SUBJ[s][3]:
            say(f'"Ой, спасибо! Вот вам {g.know[s]} руб. за это..."')
            g.money += g.know[s]
            g.hp -= SUBJ[s][4]
            g.know[s] = max(0, g.know[s] - SUBJ[s][6] - R(SUBJ[s][4]))
            hour_pass()
        else:
            say('У тебя ничего не вышло.')
            hour_pass()
            g.hp -= SUBJ[s][4]
        if g.hp <= 0:
            die('Альтруизм не довел до добра.')
    else:
        g.brain -= R(2)
        g.char -= R(2)
        g.stam -= R(2)
    pause()


def t_kuzm():
    hdr()
    placed = -1
    for d in range(g.day + 1, 6):
        if placed < 0 and g.char > R(18) and g.ts[d][INF]['w'] == 0:
            f = 10 + R(5)
            g.ts[d][INF] = {'f': f, 't': f + 1 + R(2), 'w': COMP}
            placed = d
    if placed >= 0 and g.klim < 2:
        g.klim += 1
        t = g.ts[placed][INF]
        say('Кузьменко: "Вы знаете, Климова можно найти в компьютерном классе')
        say(f'{placed + 22}-го мая с {t["f"]} по {t["t"]} ч.."')
    else:
        say('Кузьменко: ' + choice(KUZM_HINTS))
    pause()


def t_djug():
    hdr()
    say('DJuG: "У Вас какой-то школьный метод решения задач..."')
    if g.know[GIT] > 5:
        g.know[GIT] -= R(5)
    dec_hp(15, 'Не общайся с тормозами!')
    pause()


def t_endru():
    hdr()
    if g.cs == -1:
        say('Эндрю: ' + choice(ENDRU_HINTS))
        pause()
        return
    say('Обратиться к Эндрю за помощью?')
    r = menu('', [('Да, чем я хуже других?', 1), ('Нет, я уж как-нибудь сам...', 2)])
    if r == 2:
        say('Эндрю: ' + choice(ENDRU_HINTS))
        pause()
        return
    s = g.cs
    if R(14) < g.char:
        say('Эндрю вглядывается в твои задачки,')
        say('и начинает думать очень громко...')
        say('Пока Эндрю так напрягается, ты не можешь ни на чем сосредоточиться!')
        n = int(math.sqrt(max(R(max(SUBJ[s][5] - g.done[s], 0)), 0)))
        if n <= 2:
            n = 0
        g.stam -= R(2)
        if n == 0:
            say('У Эндрю ничего не вышло...')
        else:
            say(f'Эндрю решил тебе {n}{zad(n)}!')
            g.done[s] += n
            if g.done[s] >= SUBJ[s][5]:
                say('Надо будет подойти с зачеткой!')
        hour_pass()
    else:
        say('Эндрю тебя игнорирует!')
        dec_hp(R(5) + 2, 'Эндрю тоже умеет отбиваться от нехороших людей.')
    pause()


def t_grisha():
    hdr()
    if not g.terkom and g.char > R(20):
        say('"А ты не хочешь устроиться в ТЕРКОМ? Может, кое-чего подзаработаешь..."')
        r = menu('', [('Да, мне бы не помешало.', 1),
                      ('Нет, я лучше поучусь еще чуток.', 2)])
        if r == 1:
            g.terkom = 1
            say('"Поздравляю, теперь ты можешь идти в "контору"!"')
        else:
            say('"Как хочешь. Только смотри, не заучись там ..."')
        pause()
        return
    if g.char > R(20) and not g.inet:
        say('"Кстати, я тут знаю один качественно работающий прокси-сервер..."')
        say('Ты записываешь адрес. Вдруг пригодится?')
        g.inet = 1
        pause()
        return
    say('Гриша: ' + choice(GRISHA_HINTS))
    if R(3) != 0:
        say('И еще по пиву...')
        g.brain -= R(2)
        if g.brain <= 0:
            g.hp = 0
            die('Губит людей не пиво, а избыток пива.')
        g.char += R(2)
    if R(3) == 0:
        say('И еще один час прошел в бесплодных разговорах...')
        hour_pass()
    pause()


TALKS = (t_kolya, t_pasha, t_diamond, t_rai, t_misha, t_serzh,
         t_sasha, t_nil, t_kuzm, t_djug, t_endru, t_grisha)


def talk(i):
    TALKS[i]()
