# ---------------------------------------------------------------- поездки


def to_pomi():
    hdr()
    if g.hour > 20:
        say('Здравый смысл подсказывает тебе, что в такое время\n'
            'ты там никого уже не найдешь.\n'
            'Не будем зря тратить здоровье на поездку в ПОМИ.')
        pause()
        return
    dec_hp(R(10), 'В электричке нашли бездыханное тело.')
    if g.end:
        return
    g.place = POMI
    if g.money < 10:
        say('Денег у тебя нет, пришлось ехать зайцем...')
        if g.char < R(10):
            say('Тебя заловили контролеры!')
            say('Высадили в Красных зорях, гады!')
            g.hp -= 10
            if g.hp <= 0:
                die('Контролеры жизни лишили.')
            hour_pass()
        else:
            say('Уф, доехал!')
    else:
        r = menu('', [('Ехать зайцем', 1),
                      ('Честно заплатить 10 руб. за билет в оба конца', 2)])
        if r == 1:
            if g.char < R(10):
                say('Тебя заловили контролеры!')
                say('Высадили в Красных зорях, гады!')
                hour_pass()
            else:
                say('Уф, доехал!')
        else:
            g.money -= 10
            g.ticket = 1
    pause()
    hour_pass()


def pomi_to_punk():
    if not g.ticket and g.money >= 5:
        r = menu('Едем в ПУНК, билета нет. Будем покупать билет (5 рублей)?',
                 [('Да, будем', 1), ('Нет, не будем', 2)])
        if r == 1:
            g.money -= 5
            g.ticket = 1
    dec_hp(R(10), 'В электричке нашли бездыханное тело.')
    if g.end:
        return
    g.place = PUNK
    if not g.ticket:
        wr('Едем зайцем... ')
        if g.char < R(10):
            say('Контролеры поймали! Высадили в Красных Зорях!')
            dec_hp(10, 'Контролеры жизни лишили.')
        else:
            say()
        pause()
        hour_pass()
    hour_pass()
    g.ticket = 0


# --------------------------------------------------------------- учеба и быт


def botva():
    hdr()
    items = [(SUBJ[i][1] + (' (к)' if i <= 2 and g.syn[i]['h'] else ''), i)
             for i in range(6)]
    items.append(('Ни к чему', -1))
    s = menu('К чему готовиться?', items)
    if s < 0:
        return
    syn = False
    if s <= 2 and g.syn[s]['h']:
        syn = menu('', [('Воспользуюсь конспектом', True),
                        ('Буду учиться, как умею', False)]) is True
    stat = g.stam if s == FIZ else g.brain
    if stat <= 0:
        return
    gain = stat if g.hour < 19 else stat * 2 // 3
    gain -= R(stat // 2)
    gain += R(g.hp // 18)
    if syn:
        gain += 10
    g.know[s] += gain
    pen = 10 - R(g.stam) if g.stam > 0 else R(g.stam) + 10
    if pen < 0 or syn:
        pen = 0
    if g.hour > 21 or g.hour < 4:
        pen += 12
    dec_hp(pen, 'Заучился.')
    if not g.end and g.know[s] > 45:
        dec_hp(10, 'Зубрежка до добра не доводит!')
    if not g.end:
        hour_pass()


def invite():
    say('К тебе ломится сосед и приглашает тебя ' + choice(INVITES))
    r = menu('', [('"Угу, я сейчас!!!"', 1),
                  ('"Не, извини, мне готовиться надо..."', 2)])
    if r == 1:
        say('"Пошли оттягиваться!"')
        for _ in range(R(3) + 3):
            hour_pass()
            if g.end:
                return
            s = R(6)
            g.know[s] -= R(iround(math.sqrt(max(g.know[s], 0) * 2.0)))
            if g.know[s] < 0:
                g.know[s] = 0
            if g.char > R(25):
                g.hp += R(5) + 1
        g.char += 1
        if g.brain < 2:
            g.brain = R(3) + 2
    else:
        say('"Ну и зря!"')
        g.char -= R(2) + 1
    pause()


def rest_maus():
    items = []
    if g.money >= 4:
        items.append(('Стакан колы за 4 р.', 2))
    if g.money >= 6:
        items.append(('Суп, 6 р. все удовольствие', 3))
    if g.money >= 8:
        items.append(('0,5 пива за 8 р.', 1))
    items += [('Расслабляться будем своими силами.', 4),
              ('Нет, отдыхать - это я зря сказал.', 0)]
    r = menu('Выбери себе способ "культурного отдыха".', items)
    if r == 1:
        g.money -= 8
        if R(3) == 0:
            g.brain -= 1
        if R(3) == 0:
            g.char += 1
        if R(2) == 0:
            g.stam += 1
        g.hp += R(g.char)
        if g.brain <= 0:
            g.hp = 0
            die('Пивной алкоголизм, батенька...')
    elif r == 2:
        g.money -= 4
        g.hp += R(g.char) + 3
    elif r == 3:
        g.money -= 6
        g.hp += R(g.char) + 5
    elif r == 4:
        g.hp += R(g.char)
    elif r == 0:
        return
    hour_pass()


def cafe_punk():
    hdr()
    items = []
    if g.money >= 2:
        items.append(('Чай за 2 р.', 1))
    if g.money >= 4:
        items.append(('Кекс за 4 р.', 2))
    if g.money >= 6:
        items.append(('Чай и выпечку, 6 р.', 3))
    items += [('Просто посижу с приятелями.', 4), ('Я вообще зря сюда зашел.', 0)]
    r = menu('Что брать будем?', items)
    if r == 1:
        g.money -= 2
        g.hp += R(g.char) + 2
    elif r == 2:
        g.money -= 4
        g.hp += R(g.char) + 4
    elif r == 3:
        g.money -= 6
        g.hp += R(g.char) + 7
    elif r == 4:
        g.hp += R(g.char)
    elif r == 0:
        return
    hour_pass()


def cafe_pomi():
    hdr()
    items = []
    if g.money >= 2:
        items.append(('Кофе за 2 р.', 1))
    if g.money >= 4:
        items.append(('Корж за 4 р.', 2))
    if g.money >= 6:
        items.append(('Кофе и выпечку, 6 р.', 3))
    items += [('Ничего, просто просидеть здесь часок.', 4),
              ('Совсем ничего. Бывает.', 0)]
    r = menu('Что брать будем?', items)
    if r == 1:
        g.money -= 2
        g.hp += R(g.char) + 3
    elif r == 2:
        g.money -= 4
        g.hp += R(g.char) + 6
    elif r == 3:
        g.money -= 6
        g.hp += R(g.char) + 10
    elif r == 4:
        g.hp += R(g.char)
    elif r == 0:
        return
    hour_pass()


def earn():
    v = R(R(g.char + g.brain)) + 1
    while v > 4:
        v = R(v - 3) + 2
    return v


def terkom_work():
    if not g.tkfree:
        say('"Сказано же, нет свободных компов!"')
        pause()
        return
    if R(3) != 0:
        say('"Извини, парень, свободных кумпутеров нет.')
        say('Пойди поучись пока."')
        g.tkfree = 0
        pause()
        return
    while True:
        hdr()
        items = [('Сидеть и зарабатывать деньги', 1)]
        if g.disk:
            items.append(('Поиграть в MMHEROES', 10))
        if g.inet:
            items.append(("Посидеть часок в Inet'е", 11))
        items.append(('Выйти отсюда на "свежий воздух"', 2))
        r = menu('Ты сидишь за свободным компом в тереховской "конторе". '
                 'Что делать будем?', items)
        if r == 2:
            say('Уходим ...')
            pause()
            return
        if r == 10:
            say('По неизвестной причине, в помещении ТЕРКОМА')
            say('MMHEROES не оказывают никакого метафизического воздействия')
            say('на окружающий мир... Оглядевшись вокруг, ты обнаруживаешь, что')
            say('все товарищи, здесь собравшиеся, РУБЯТСЯ В MMHEROES!')
            pause()
            continue
        v = earn()
        say(f'Тебе накапало {v} руб.')
        g.money += v
        if r == 1:
            dec_hp(R(v * 2), 'Сгорел на работе.')
        else:
            say('Вот здорово - мы сидим, а денежки-то идут!')
        pause()
        hour_pass()
        if g.end:
            return
        if g.hour > 18:
            say('Рабочий день закончился, все по домам.')
            pause()
            return


def surf_inet():
    if R(g.brain) > 6 and g.done[INF] < SUBJ[INF][5]:
        say('Ух ты! Ты нашел програмку, которая нужна для Климова!')
        g.done[INF] += 1
    elif R(3) == 0 and g.brain < 5:
        g.brain += 1
    pause()
    hour_pass()


def reinit_future_ts():
    old = [[dict(t) for t in g.ts[d]] for d in range(g.day + 1)]
    init_ts()
    for d in range(g.day + 1):
        g.ts[d] = old[d]


def play_mmheroes():
    g.incept += 1
    say('ДЗИНЬ!\nДДДЗЗЗЗЗИИИИИИННННННЬ !!!!\n'
        'ДДДДДДЗЗЗЗЗЗЗЗЗЗЗЗЗИИИИИИИИИИННННННННННЬ !!!!!!!!!!\n'
        'Неожиданно ты осознаешь, что началась зачетная неделя,\n'
        'а твоя готовность к этому моменту практически равна нулю.\n')
    say('!!!!!! СТОП! !!!!!!\nЧТО-ТО ТАКОЕ ТЫ УЖЕ ВИДЕЛ!!!\n'
        'Ты просто играешь в компьютерную игру, в которой тебе вдруг\n'
        'предложили... СЫГРАТЬ В ЭТУ САМУЮ ИГРУ! [...]')
    pause()
    if g.stam + g.brain - g.incept * 5 < 8:
        g.hp = 0
        die('Раздвоение ложной личности.')
        return
    hour_pass()
    if g.end:
        return
    say('Постепенно к тебе приходит осознание того, что на самом деле все это -\n'
        'компьютерная игра, и события происходят только в твоем воображении.\n'
        'Вовремя выйдя из странного трансцендентального состояния,\n'
        'ты обнаруживаешь себя в компьютерном классе Мат-Меха.\n'
        'Правда, мир вокруг тебя, похоже, несколько иной, нежели час назад...')
    reinit_future_ts()
    pause()
