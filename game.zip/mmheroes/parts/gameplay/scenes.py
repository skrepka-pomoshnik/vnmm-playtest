# ---------------------------------------------------------------- сцены


def sc_home():
    hdr()
    if 23 - max(0, 50 - g.hp) // 12 < g.hour or g.hour < 4:
        say('Тебя неумолимо клонит ко сну ...')
        pause()
        goto_sleep()
        return
    if g.hour > 17 and R(10) < 3 and not g.invited:
        g.invited = 1
        invite()
        return
    r = menu('Ты в общаге. Что делать?', [
        ('Готовиться', 1), ('Посмотреть расписание', 2), ('Отдыхать', 3),
        ('Лечь спать', 4), ('Пойти на факультет', 5), ('Поехать в ПОМИ', 6),
        ('Пойти в мавзолей', 7), ('С меня хватит!', 8), ('ЧТО ДЕЛАТЬ ???', 9)])
    if r == 1:
        botva()
    elif r == 2:
        ts_full()
        pause()
    elif r == 3:
        g.hp += 7 + R(8)
        hour_pass()
    elif r == 4:
        if 3 < g.hour < 20:
            say('Тебя чего-то не тянет по-спать...')
            pause()
        else:
            goto_sleep()
    elif r == 5:
        go_home()
        g.place = PUNK
        dec_hp(3, 'Умер по пути на факультет.')
    elif r == 6:
        to_pomi()
    elif r == 7:
        go_home()
        g.place = MAUS
        dec_hp(3, 'Умер по пути в мавзолей.')
    elif r == 8:
        try_exit()
    elif r == 9:
        help_scr()


def sc_punk():
    hdr()
    items = [('Идти к преподу', 1), ('Посмотреть на баобаб', 2),
             ('Пойти в общагу', 3), ('Поехать в ПОМИ', 4), ('Пойти в мавзолей', 5)]
    if g.hour < 20:
        items.append(('Пойти в компьютерный класс', 7))
    if 10 <= g.hour <= 18:
        items.append(('Сходить в кафе', 12))
    for i in range(12):
        if g.cm[i]['p'] == PUNK and g.cm[i]['s'] == -1:
            items.append((CM_NAMES[i], 100 + i))
    if g.terkom and g.hour <= 18:
        items.append(('Пойти в ТЕРКОМ поработать', 10))
    items.append(('С меня хватит!', 6))
    r = menu('Ты на факультете. Что делать?', items)
    if r == 1:
        select_prof(False)
    elif r == 2:
        show_top('БАОБАБ')
    elif r == 3:
        go_home()
    elif r == 4:
        to_pomi()
    elif r == 5:
        go_home()
        g.place = MAUS
        dec_hp(3, 'Умер по пути в мавзолей.')
    elif r == 6:
        try_exit()
    elif r == 7:
        go_home()
        g.place = COMP
        dec_hp(2, 'Упал с лестницы у главного входа.')
    elif r == 10:
        terkom_work()
    elif r == 12:
        cafe_punk()
    elif r >= 100:
        talk(r - 100)


def sc_comp():
    hdr()
    if g.hour > 20:
        say('Класс закрывается. Пошли домой!')
        pause()
        go_home()
        dec_hp(R(5), 'Умер по пути домой. Бывает.')
        return
    items = []
    if prof_here(INF):
        items.append((SUBJ[INF][0], 1))
    items += [('Пойти в общагу', 2), ('Покинуть класс', 3),
              ('Поехать в ПОМИ', 4), ('Пойти в мавзолей', 5)]
    if g.inet:
        items.append(("Провести 1 час в Inet'е", 11))
    for i in range(12):
        if g.cm[i]['p'] == COMP:
            items.append((CM_NAMES[i], 100 + i))
    if g.disk:
        items.append(('Поиграть в MMHEROES', 10))
    items.append(('С меня хватит!', 6))
    r = menu('Ты в компьютерном классе. Что делать?', items)
    if r == 1:
        if R(2) == 0:
            say("Климов А.А. сидит и тоскует по халявному Inet'у.")
            say('...')
            pause()
        g.cs = INF
        g.last = INF
    elif r == 2:
        go_home()
    elif r == 3:
        go_home()
        g.place = PUNK
        dec_hp(2, 'Не смог расстаться с компьютером.')
    elif r == 4:
        to_pomi()
    elif r == 5:
        go_home()
        g.place = MAUS
        dec_hp(2, 'Умер по пути в мавзолей.')
    elif r == 6:
        try_exit()
    elif r == 10:
        play_mmheroes()
    elif r == 11:
        surf_inet()
    elif r >= 100:
        talk(r - 100)


def sc_maus():
    hdr()
    items = [('Идти в ПУНК', 1), ('Поехать в ПОМИ', 5), ('Идти в общагу', 2),
             ('Отдыхать', 3)]
    for i in range(12):
        if g.cm[i]['p'] == MAUS:
            items.append((CM_NAMES[i], 100 + i))
    items.append(('С меня хватит!', 4))
    r = menu('Ты в мавзолее. Что делать?', items)
    if r == 1:
        go_home()
        g.place = PUNK
        dec_hp(3, 'Умер по пути на факультет.')
    elif r == 2:
        go_home()
    elif r == 3:
        rest_maus()
    elif r == 4:
        try_exit()
    elif r == 5:
        to_pomi()
    elif r >= 100:
        talk(r - 100)


def sc_pomi():
    hdr()
    items = [('Идти к преподу', 1), ('Посмотреть на доску объявлений', 2),
             ('Пойти в кафе', 3), ('Поехать в ПУНК', 4)]
    for i in range(12):
        if g.cm[i]['p'] == POMI and g.cm[i]['s'] == -1:
            items.append((CM_NAMES[i], 100 + i))
    items.append(('С меня хватит!', 5))
    r = menu('Ты в ПОМИ. Что делать?', items)
    if r == 1:
        select_prof(True)
    elif r == 2:
        show_top('ДОСКА ОБЪЯВЛЕНИЙ ПОМИ')
    elif r == 3:
        cafe_pomi()
    elif r == 4:
        pomi_to_punk()
    elif r == 5:
        try_exit()
    elif r >= 100:
        talk(r - 100)


def router():
    if g.place in (PUNK, POMI, COMP) and g.cs != -1:
        sc_exam()
    elif g.place == POMI:
        sc_pomi()
    elif g.place == PUNK:
        sc_punk()
    elif g.place == MAUS:
        sc_maus()
    elif g.place == COMP:
        sc_comp()
    else:
        sc_home()


# --------------------------------------------------------------- игра
