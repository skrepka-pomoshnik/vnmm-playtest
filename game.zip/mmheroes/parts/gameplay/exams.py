# ---------------------------------------------------------------- зачеты


def select_prof(at_pomi):
    items = [(SUBJ[i][0], i) for i in range(6) if prof_here(i)]
    items.append(('Ни к кому', -1))
    cs = menu('Ты сейчас %s. К кому идти?' % ('в ПОМИ' if at_pomi else 'на факультете'),
              items)
    g.cs = cs
    if cs >= 0:
        g.last = cs
        if R(2) == 0:
            exam_intro(cs)


def exam_intro(s):
    if s == FIZ and R(3) == 0:
        say('Альбинский проводит лекцию о пользе бега')
        say(choice(('для народного хозяйства.', 'для личной жизни.',
                    'для научной работы.', 'для коммунистического строительства.',
                    'для учебы и досуга.', 'для спасения от контроллеров.')))
        g.ts[g.day][FIZ]['t'] += 1
        say('Похоже, он, как всегда, немного увлекся. Ровно на час.')
        hour_pass()
        pause()
        return
    say(INTROS[s])
    pause()


def harass(i):
    say()
    say(f'К тебе пристает {CM_NAMES[i]}. Что будешь делать?')
    r = menu('', [('Пытаться игнорировать', 1), (CM_NAMES[i], 2)])
    if r == 1:
        if CM_HIT[i] > 0:
            say('Тебе как-то нехорошо ...')
            dec_hp(CM_HIT[i], CM_NAMES[i] + ': лучше игнорировать не надо.')
        pause()
    else:
        talk(i)


def suffer(s):
    say('Мучаешься ...')
    k = g.know[s] - SUBJ[s][3] + R(g.brain)
    if g.hp <= 5:
        k -= R(5 - g.hp)
    n = iround(math.sqrt(k) / SUBJ[s][6]) if k > 0 else 0
    n = max(0, min(n, SUBJ[s][5] - g.done[s]))
    g.know[s] = max(0, g.know[s] + R(g.stam) - R(SUBJ[s][3]))
    if s == GIT and g.char * 2 + 26 < g.know[GIT]:
        say('Подкорытов: "Чего-то я не понимаю... Похоже, Вы меня лечите..."')
        n = 0
    h = min(R(g.stam) - SUBJ[s][4], 0)
    g.hp += h
    if g.hp <= 0:
        die(SUBJ[s][0] + ' замучил' + ('' if SUBJ[s][11] else 'а') + '.')
        return
    if n == 0:
        say('Твои мучения были напрасны.')
    else:
        say(f'Тебе зачли еще {n}{zad(n)}!')
        g.done[s] += n
    hour_pass()
    pause()


def prof_gone():
    s = g.cs
    if s == ALG:
        if g.place != PUNK or g.done[ALG] >= SUBJ[ALG][5]:
            say(SUBJ[s][0] + ' уходит.')
            g.cs = -1
            pause()
            return
        say('Всеминов М.А. уходит.')
        r = menu('Пойти за ним на электричку?',
                 [('Да, я хочу еще помучаться', 1), ('Ну уж нет, спасибо!', 2)])
        if r == 2:
            g.place = PUNK
            g.cs = -1
        else:
            train_exam()
        return
    if SUBJ[s][3] * 5 + g.hour * 6 < g.char * 3 + R(60) + 20:
        say(SUBJ[s][0] + ' задерживается еще на час.')
        g.ts[g.day][s]['t'] = g.hour + 1
    else:
        say(SUBJ[s][0] + ' уходит.')
        g.cs = -1
    pause()


def train_exam():
    if g.hour > 20:
        say('М.А. Всемирнов : "Нет, сегодня я больше никому ничего не засчитаю..."\n'
            'Услышав эту фразу, ты осознаешь беспочвенность своих мечтаний\n'
            'о сдаче зачета по алгебре в электричке.')
        g.cs = -1
        pause()
        return
    say('Есть надежда, что в электричке удастся что-то еще решить.\n'
        'Правда, зачетной ведомости с собой не взять...')
    if g.money < 10:
        say('Денег у тебя нет, пришлось ехать зайцем...')
        if g.char < R(10):
            say('Тебя заловили контролеры!')
            say('Высадили в Красных зорях, гады!')
            dec_hp(10, 'Контролеры жизни лишили.')
            g.place = PUNK
            g.cs = -1
            pause()
            return
    else:
        r = menu('', [('Ехать зайцем', 1),
                      ('Честно заплатить 10 руб. за билет в оба конца', 2)])
        if r == 1:
            g.ticket = 0
            if g.char < R(10):
                say('Тебя заловили контролеры!')
                dec_hp(10, 'Контроллеры, контроллеры, контроллеры...')
                say('И со Всемирновым ты ничего не успел...')
                g.cs = -1
                pause()
                return
        else:
            g.money -= 10
            g.ticket = 1
    pause()
    hdr()
    say('Всемирнов принимает зачет даже в электричке!')
    say('Мучаешься ...')
    k = g.know[ALG] - SUBJ[ALG][3] + R(g.brain)
    if g.hp <= 5:
        k -= R(5 - g.hp)
    n = iround(math.sqrt(k) / SUBJ[ALG][6]) if k > 0 else 0
    n = max(0, min(n, SUBJ[ALG][5] - g.done[ALG]))
    g.know[ALG] = max(0, g.know[ALG] + R(g.stam) - R(SUBJ[ALG][3]))
    h = min(R(g.stam * 2 // 3) - SUBJ[ALG][4], 0)
    g.hp += h
    if g.hp <= 0:
        die('Всемирнов М.А. замучил.')
        return
    if n == 0:
        say('Твои мучения были напрасны.')
    else:
        say(f'Тебе зачли еще {n}{zad(n)}!')
        g.done[ALG] += n
    hour_pass()
    pause()
    if not g.end:
        train_arrival()


def train_arrival():
    if g.hour > 20:
        say('Увы, ПОМИ уже закрыто, поэтому придется ехать домой...')
        g.place = HOME
        return
    hdr()
    say('Ты в Питере, на Балтийском вокзале.')
    r = menu('Куда направляемся?',
             [('Домой, в ПУНК!', PUNK), ('Хочу в ПОМИ!', POMI)])
    if r == PUNK:
        if g.ticket:
            say('Хорошо, билет есть...')
        elif g.char < R(10):
            say('Тебя заловили контролеры!')
            say('Высадили в Красных зорях, гады!')
            dec_hp(10, 'Контролеры жизни лишили.')
            hour_pass()
            g.place = PUNK
            pause()
            return
        else:
            say('Уф, доехал...')
        hour_pass()
    g.place = r


def fairy():
    say('Влащенко Н.П.: "Закройте глаза ..."')
    say('Ты послушно закрываешь глаза.')
    say('Влащенко Н.П. касается тебя указкой (она же - волшебная палочка ...)')
    ax = R(15)
    if ax == 0:
        say('Тебе сильно поплохело. Фея была явно не в настроении.')
        dec_hp(30, 'Фея была явно не в настроении.')
    elif ax == 1:
        say('Ты почувствовал себя где-то в другом месте.')
        g.place = POMI
        g.cs = -1
    elif ax == 2:
        g.know[ALG] //= 2
        say('Ты чувствуешь, что подзабыл алгебру...')
    elif ax == 3:
        g.know[MAT] //= 2
        say('Ты чувствуешь, что анализ придется учить заново.')
    elif ax == 4:
        g.brain -= R(2) + 1
        say('В голову постоянно лезут мысли о всяких феях...')
    elif ax == 5:
        g.char -= R(2) + 1
        say('Ты чувствуешь, что все вокруг жаждут твоей смерти.')
    elif ax == 6:
        g.stam -= R(2) + 1
        say('Куда-то подевалась твоя уверенность в себе.')
    elif ax == 7:
        g.brain += R(3) + 1
        say('Голова стала работать заметно лучше.')
    elif ax == 8:
        g.char += R(3) + 1
        say('Ты проникся любовью к окружающему миру.')
    elif ax == 9:
        g.stam += R(3) + 1
        say('Ты готов к любым испытаниям.')
    elif ax == 10:
        if g.money > 0:
            g.money = 0
            say('Пока твои глаза были закрыты, кто-то утащил твои деньги!!!')
        else:
            g.money = 20
            say('Ты нашел в своем кармане какие-то деньги!')
    elif ax in (11, 12, 13):
        g.garlic = R(4) + 1
        g.char -= g.garlic // 2
        say('Ты чувствуешь, что от тебя сильно несет чесноком.')
    else:
        say('Странное чувство быстро прошло.')
    pause()


def after_pass(s):
    if s == ENG:
        fairy()
        return
    if s == ALG:
        say('Всемирнов медленно рисует минус ...\n'
            'И так же медленно пририсовывает к нему вертикальную палочку!\n'
            'Уф! Ну и шуточки у него! Хорошо хоть, зачет поставил...')
        dec_hp(R(6), 'Всемирнов М.А. изничтожил.')
        pause()
        return
    say('Твоя зачетка пополнилась еще одной записью.')
    pause()


def sc_exam():
    if g.cs == -1 or g.end or g.hp <= 0:
        return
    s = g.cs
    hdr()
    if g.done[s] >= SUBJ[s][5]:
        say()
        say('У вас все зачтено, можете быть свободны.')
        if not g.passed[s]:
            g.passed[s] = 1
            g.pday[s] = g.day
            g.left -= 1
            say()
            after_pass(s)
            if g.cs == -1 or g.end:
                return
    t = g.ts[g.day][s]
    if t['t'] <= g.hour:
        prof_gone()
        return
    say(f'Сейчас тебя истязает {SUBJ[s][0]}.')
    pres = [i for i in range(12) if g.cm[i]['p'] == g.place and
            (g.place != COMP or g.cm[i]['s'] == s)]
    if pres:
        say('Кроме тебя, здесь еще сидят: ' + ', '.join(CM_NAMES[i] for i in pres) + '.')
    asked = set()
    cnt = 0
    while True:
        if g.char // 2 <= cnt or cnt > 3:
            break
        for i in pres:
            if i in asked:
                continue
            # оригинал: вне компов пристает только RAI, в компах — все
            if (CM_NAG[i] - cnt // 2 - g.garlic > R(10)
                    and (i == RAI or g.place == COMP)):
                asked.add(i)
                cnt += 1
                harass(i)
                if g.end:
                    return
                if g.ts[g.day][s]['t'] <= g.hour:
                    prof_gone()
                    return
                hdr()
        if not R(2):
            break
    say()
    if g.done[s] == 0:
        say('У тебя еще ничего не зачтено.')
    elif g.done[s] < SUBJ[s][5]:
        say(f'Зачтено {g.done[s]}{zad(g.done[s])} из {SUBJ[s][5]}.')
    else:
        say('У тебя уже все зачтено.')
    items = []
    if not g.passed[s]:
        items.append(('Мучаться дальше', -1))
    for i in pres:
        items.append((CM_NAMES[i], 100 + i))
    items.append(('Бросить это дело', -2))
    r = menu('', items)
    if r == -1:
        suffer(s)
    elif r == -2:
        g.cs = -1
    elif r >= 100:
        talk(r - 100)
