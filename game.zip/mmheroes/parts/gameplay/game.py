def init_ts():
    g.ts = [[{'f': 0, 't': 0, 'w': 0} for _ in range(6)] for _ in range(6)]
    for s in range(6):
        su = SUBJ[s]
        used = set()
        for _ in range(su[7]):
            d = rnd_to(0, 5)
            while d in used:
                d = rnd_to(0, 5)
            used.add(d)
            f = rnd_to(9, 18 - su[9])
            g.ts[d][s] = {'f': f, 't': f + rnd_to(su[8], su[9]),
                          'w': su[10][R(3)]}


def new_game():
    global GOD_MODE
    GOD_MODE = GOD_ARG
    g.rnd = random.Random(SEED)
    ClrScr()
    r = menu('Выбери начальные параметры своего "героя":',
             [('Случайный студент', 1), ('Шибко умный', 2), ('Шибко наглый', 3),
              ('Шибко общительный', 4)] + ([('GOD-режим', 100)] if GOD_ARG else []))
    if r == 2:
        g.brain, g.stam, g.char = R(5) + 5, R(3) + 2, R(3) + 2
    elif r == 3:
        g.brain, g.stam, g.char = R(3) + 2, R(5) + 5, R(3) + 2
    elif r == 4:
        g.brain, g.stam, g.char = R(3) + 2, R(3) + 2, R(5) + 5
    elif r == 100:
        g.brain = g.stam = g.char = 30
    else:
        g.brain, g.stam, g.char = R(3) + 4, R(3) + 4, R(3) + 4
    g.day = 0
    g.hour = 8
    g.place = HOME
    g.cs = -1
    g.last = -1
    g.money = 0
    g.left = 6
    g.hp = R(g.stam * 2) + 40
    g.garlic = 0
    g.disk = g.inet = g.invited = g.incept = 0
    g.terkom = g.stipend = g.ticket = g.djknown = 0
    g.klim = 0
    g.tkfree = 1
    g.end = 0
    g.cause = ''
    g.know = [R(g.brain) for _ in range(6)]
    g.done = [0] * 6
    g.passed = [0] * 6
    g.pday = [-1] * 6
    g.syn = [{'s': 1, 'h': 0} for _ in range(3)]
    g.cm = [{'p': 0, 's': -1} for _ in range(12)]
    init_ts()
    say('\n                ГЕРОИ МАТА И МЕХА ;)\n'
        '        (P) CrWMM Development Team, 2001.\n'
        '        Полная текстовая игра MMHEROES.\n')
    say('ДЗИНЬ!\nДДДЗЗЗЗЗИИИИИИННННННЬ !!!\n'
        'ДДДДДДЗЗЗЗЗЗЗЗЗЗЗЗЗИИИИИИИИИИННННННННННЬ !!!!!!!!!!\n'
        'Ты просыпаешься от звонка будильника 22-го мая в 8:00.\n'
        'Неожиданно ты осознаешь, что началась зачетная неделя,\n'
        'а твоя готовность к этому моменту практически равна нулю.\n'
        'Натягивая на себя скромное одеяние студента, ты всматриваешься\n'
        'в заботливо оставленное соседом расписание:\n'
        'когда и где можно найти искомого препода ?')
    pause()
    ts_full()
    pause()


def final_score():
    """Стипуха: формула финала оригинала, без печати. Используется и в embed."""
    score = sum((6 - g.pday[s]) * (SUBJ[s][5] + SUBJ[s][3]) * 2 // 3
                for s in range(6) if g.passed[s])
    if not g.passed[ALG]:
        score = max(0, score - (SUBJ[ALG][5] - g.done[ALG]) * 4)
    if not g.passed[MAT]:
        score = score * 2 // 3
    if not g.passed[GIT]:
        score = score * 2 // 3
    if g.terkom:
        score = score * 2 // 3
    return score


def game_end():
    ClrScr()
    say()
    if g.hp <= 0:
        say('Легче лбом колоть орехи, чем учиться на МАТ-МЕХе.')
        say('*** ' + str(g.cause))
        pause()
        return
    if g.left > 0:
        say('Уффффф! Во всяком случае, ты еще живой.')
    else:
        say('********* Yes! Ты сделал это! *********')
    say()
    if g.left >= 3:
        say(f'У тебя нет целых {g.left} зачетов!\nТЫ ОТЧИСЛЕН!')
        pause()
        return
    if g.left == 2:
        say('Нет двух зачетов - плохо.\nГоворят, у механиков жизнь проще...\n'
            '- Зря говорят, ХАЛЯВЫ НЕ БУДЕТ!')
    elif g.left == 1:
        say('Нет одного зачета.\nНичего, от этого еще никто не помирал.')
    else:
        say('Поздравляю: ты можешь считать себя настоящим героем Мат-Меха!\n'
            'Успешной тебе сессии !')
    score = final_score()
    if not g.passed[ALG]:
        say()
        say('У тебя нет зачета по алгебре!')
        say('Всемирнов доканал тебя на сессии.')
        say('Естественно, это повлияло на твои оценки.')
    if not g.passed[MAT]:
        say()
        say('У тебя нет допуска по матану!')
    if not g.passed[GIT]:
        say()
        say('У тебя нет зачета по геометрии!')
        say('Как тебя угораздило?')
    if g.terkom:
        say()
        say('К сессии ты "готовился", "работая" в ТЕРКОМе.')
        say('Ты решил больше никогда так не делать.')
    say()
    if score <= 0:
        say('Тебя оставили без стипухи.')
    else:
        say(f'Твоя стипуха - {score} руб.')
        say(f'В заначке {g.money} руб.')
        if GOD_MODE:
            say('Да ты еще и GOD! Нет, тебе в таблицу рекордов нельзя.')
        else:
            TOP.append(score + g.money)
    pause()
