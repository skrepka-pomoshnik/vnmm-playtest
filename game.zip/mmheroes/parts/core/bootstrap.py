#!/usr/bin/env python3
"""ГЕРОИ МАТА И МЕХА — компактный текстовый порт классического текст-квеста.

Оригинал: "mmheroes", CrWMM Development Team, 2001 (Borland Pascal, DOS).
Порт сделан по открытой JS-версии https://github.com/sharpden/mmheroes и
сохраняет её правила: 6 дней, 6 предметов с плавающим расписанием,
здоровье/мозги/выносливость/харизма, зачеты, ТЕРКОМ, однокашники, финалы.

Запуск:  python3 mmheroes.py [--seed N] [--god] [--robot [N]] [--selftest]
Игра:    в терминале — стрелки/Enter/цифры; при пайпе — номера пунктов.

Встраивание мини-игрой: run_embedded(policy, seed=None, god=False) -> dict,
см. README.md. Не вызывайте main() из хоста — она читает sys.argv.
"""
import copy
import math
import os
import random
import sys
import traceback

if __package__:
    from .texts import (
        ALG,
        CM_HIT,
        CM_NAG,
        CM_NAMES,
        COMP,
        DATES,
        DIA,
        DIAMOND_HINTS,
        DJU,
        DREAM_DJUG,
        DREAM_PROFS,
        EDR,
        ENDRU_HINTS,
        ENG,
        FIZ,
        GIT,
        GRI,
        GRISHA_HINTS,
        HOME,
        INF,
        INTROS,
        INVITES,
        KOL,
        KUZ,
        KUZM_HINTS,
        MAT,
        MAUS,
        MIS,
        MISHA_HINTS,
        NIL,
        PAS,
        PINK_DOING,
        PINK_WHO,
        PLACES,
        POMI,
        PUNK,
        RAI,
        SAS,
        SER,
        SERZH_HINTS,
        SUBJ,
    )
else:
    from texts import (
        ALG,
        CM_HIT,
        CM_NAG,
        CM_NAMES,
        COMP,
        DATES,
        DIA,
        DIAMOND_HINTS,
        DJU,
        DREAM_DJUG,
        DREAM_PROFS,
        EDR,
        ENDRU_HINTS,
        ENG,
        FIZ,
        GIT,
        GRI,
        GRISHA_HINTS,
        HOME,
        INF,
        INTROS,
        INVITES,
        KOL,
        KUZ,
        KUZM_HINTS,
        MAT,
        MAUS,
        MIS,
        MISHA_HINTS,
        NIL,
        PAS,
        PINK_DOING,
        PINK_WHO,
        PLACES,
        POMI,
        PUNK,
        RAI,
        SAS,
        SER,
        SERZH_HINTS,
        SUBJ,
    )

# ---------------------------------------------------------------- состояние


class St:
    pass


g = St()
SEED = None
ROBOT = None
GOD_ARG = False
GOD_MODE = False
TOP = []


# ------------------------------------------------------------- DOS-экран 80x25

try:
    import select
    import termios
    import tty
    HAS_TTY = True
except ImportError:          # не-UNIX терминал -> построчный режим
    HAS_TTY = False

TTY = False                  # включается в main()


class Scr:
    """Экран 80x25 с байтом цвета на ячейку, как в оригинале (Screen/ScreenColor)."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.b = [[' '] * 80 for _ in range(25)]
        self.c = [[7] * 80 for _ in range(25)]
        self.x = self.y = 0
        self.col = 7


scr = Scr()
MAXROW = 0
CLR_PENDING = True


def ClrScr():
    global CLR_PENDING, MAXROW
    scr.reset()
    MAXROW = 0
    CLR_PENDING = True


def GotoXY(x, y):
    scr.x, scr.y = x - 1, y - 1


def wr(s):
    global MAXROW
    for ch in str(s):
        if scr.y < 25 and scr.x < 80:
            scr.b[scr.y][scr.x] = ch
            scr.c[scr.y][scr.x] = scr.col
        scr.x += 1
    if scr.y > MAXROW:
        MAXROW = scr.y


def say(s=''):
    global MAXROW
    for part in str(s).split('\n'):
        scr.x = 0
        wr(part)
        scr.y += 1
    if scr.y > MAXROW:
        MAXROW = scr.y


def _upper_bound(cont, val):
    for i, x in enumerate(cont):
        if x > val:
            return i
    return len(cont)


def _ansi(at):
    fg, bg = at & 15, (at >> 4) & 7
    f = (30 + fg) if fg < 8 else (90 + fg - 8)
    return f'\033[{f};{40 + bg}m'


def flush():
    global CLR_PENDING
    if ROBOT:
        return
    if TTY:
        head = '\033[2J\033[H' if CLR_PENDING else '\033[H'
        CLR_PENDING = False
        rows = []
        for r in range(25):
            line, last = [], None
            for cx in range(80):
                at = scr.c[r][cx]
                if at != last:
                    line.append(_ansi(at))
                    last = at
                line.append(scr.b[r][cx])
            rows.append(''.join(line) + '\033[0m\033[K')
        sys.stdout.write(head + '\n'.join(rows) + '\n')
        sys.stdout.flush()
    else:
        for r in range(MAXROW + 1):
            print(''.join(scr.b[r]).rstrip())


def read_key():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == '\x1b':
            ext = ''
            while len(ext) < 2 and select.select([fd], [], [], 0.05)[0]:
                ext += sys.stdin.read(1)
            ch += ext
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    if ch == '\x03':
        raise KeyboardInterrupt
    return ch


def R(n):
    return g.rnd.randrange(n) if n > 0 else 0


def choice(seq):
    return seq[R(len(seq))]


def iround(x):
    return math.floor(x + 0.5)


def rnd_to(a, b):
    return a + R(b - a + 1)


def zad(n):
    if n % 10 == 1 and n % 100 != 11:
        return ' задание'
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return ' задания'
    return ' заданий'


def _in(prompt):
    try:
        return input(prompt)
    except EOFError:
        raise SystemExit('\nПока!')


def pause():
    if ROBOT is not None:
        return
    if TTY:
        GotoXY(1, 24)
        scr.col = 0x0E
        wr('Нажми любую клавишу ...')
        scr.col = 7
        flush()
        read_key()
        GotoXY(1, 24)
        wr(' ' * 26)
    else:
        flush()
        _in('[Enter] ')
