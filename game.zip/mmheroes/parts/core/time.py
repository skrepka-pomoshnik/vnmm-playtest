# ---------------------------------------------------------------- время


def hour_pass():
    if g.end:
        return
    g.tkfree = 1
    move_cm()
    g.hour += 1
    if g.cs == GIT and g.place == POMI:
        dec_hp(6, 'DJuG - это смертельно!')
        g.djknown = 1
    if g.char <= 0:
        g.hp = 0
        die('Бурно прогрессирующая паранойя.')
    if not g.end and g.hour == 24:
        g.hour = 0
        g.day += 1
        midnight()


def go_home():
    g.place = HOME
    g.cs = -1


def midnight():
    if g.place == POMI:
        say('Ты глядишь на часы и видишь: уже полночь!\n'
            'На последней электричке ты едешь домой, в общагу.')
        g.hp -= 4
        if g.hp < 1:
            die('Заснул в электричке и не проснулся.')
        go_home()
        pause()
    elif g.place == PUNK:
        say('Вахтерша глядит на тебя странными глазами:\n'
            'что может делать бедный студент в университете в полночь?\n'
            'Не зная ответ на этот вопрос, ты спешишь в общагу.')
        go_home()
        pause()
    elif g.place == MAUS:
        say('Мавзолей закрывается.\nПора домой!')
        go_home()
        pause()
    elif g.place == HOME:
        goto_sleep()


def morning():
    for i in range(3):
        g.syn[i]['s'] = 1
    g.invited = 0
    kind = 0
    if g.brain <= 2:
        g.brain = 2
        kind = 1
    if g.stam <= 0:
        g.hp = 0
        die('Превратился в овощ.')
        return
    if g.djknown:
        kind = 2
    if R(2) == 0:
        dream(kind)
    g.djknown = 0


def dream(kind):
    if kind == 1:
        say(choice(PINK_WHO))
        say(choice(PINK_DOING) + '...')
        say('Господи! Ну и присниться же такое!')
        pause()
        g.hp = R(10) + 10
    elif kind == 2:
        say('"Здравствуйте!" ... Оно большое ... Оно пыхтит!')
        say('Оно медленно ползет прямо на тебя!!! Оно говорит человеческим голосом:')
        say(choice(DREAM_DJUG))
        say('Уффф... Что-то сегодня опять какие-то гадости снятся.')
        pause()
        g.hp = R(10) + 10
    elif R(3) == 0:
        say(DREAM_PROFS[g.last] if 0 <= g.last < 6 else choice(DREAM_PROFS))
        say('Ну все, похоже, заучился - если преподы по ночам снятся...')
        pause()


def goto_sleep():
    g.cs = -1
    g.place = HOME
    if g.day > 5:
        die('Время вышло.')
        return
    if g.hp > 40:
        g.hp = 40
    grow = min(g.hp + 15 + R(20), 50) - g.hp
    g.hp += grow
    g.hour += R(grow // 4) + 7
    if g.hour > 23:
        g.hour %= 24
        g.day += 1
        if g.day > 5:
            die('Время вышло.')
            return
    morning()
    if g.end:
        return
    if g.hour <= 4:
        g.hour = 5
    if g.garlic > 0:
        g.garlic -= 1
        g.char += R(2)


# --------------------------------------------------------------- однокашники


def wander(i, subs, base):
    g.cm[i]['p'] = base
    g.cm[i]['s'] = -1
    while True:
        cand = False
        hit = False
        for s in subs:
            if prof_today(s):
                cand = True
                if R(10) > 5:
                    hit = True
                    g.cm[i]['p'] = g.ts[g.day][s]['w']
                    g.cm[i]['s'] = s
        if hit or not cand:
            return


def move_cm():
    g.cm[KOL]['p'] = MAUS if nine19() else 0
    g.cm[KOL]['s'] = -1
    wander(PAS, (0, 1, 2), PUNK if nine19() else 0)
    g.cm[DIA]['p'] = COMP if nine19() else 0
    g.cm[DIA]['s'] = -1
    for s in (5, 4, 3, 2, 1, 0):
        if prof_today(s) and R(10) > 5:
            g.cm[DIA]['p'] = g.ts[g.day][s]['w']
            g.cm[DIA]['s'] = s
    if prof_here(ALG):
        g.cm[RAI]['p'] = g.ts[g.day][ALG]['w']
        g.cm[RAI]['s'] = ALG
    elif prof_here(MAT):
        g.cm[RAI]['p'] = g.ts[g.day][MAT]['w']
        g.cm[RAI]['s'] = MAT
    else:
        g.cm[RAI]['p'] = COMP if nine19() else 0
        g.cm[RAI]['s'] = -1
    wander(MIS, (4, 2, 1, 0), PUNK if nine19() else 0)
    wander(SER, (5, 4, 3, 2, 1, 0), PUNK if nine19() else 0)
    g.cm[SAS]['p'] = PUNK if nine19() and R(4) == 0 else 0
    g.cm[SAS]['s'] = -1
    wander(NIL, (0, 1, 2), 0)
    g.cm[KUZ]['p'] = COMP if nine19() and R(4) == 0 else 0
    g.cm[KUZ]['s'] = -1
    g.cm[DJU]['p'] = POMI
    g.cm[DJU]['s'] = GIT
    g.cm[EDR]['p'] = PUNK
    g.cm[EDR]['s'] = MAT
    for s in (0, 1, 2):
        if prof_today(s) and R(10) > 5:
            g.cm[EDR]['p'] = g.ts[g.day][s]['w']
            g.cm[EDR]['s'] = s
    g.cm[GRI]['p'] = MAUS if R(3) == 0 else 0
    g.cm[GRI]['s'] = -1
