def menu(title, items):
    items = list(items)
    if ROBOT is not None:
        return items[ROBOT.randrange(len(items))][1]
    if TTY:
        sel = 0
        y0 = max(7, min(max(scr.y + 2, 9), 22 - len(items)))
        if title:
            GotoXY(1, y0)
            scr.col = 7
            wr(title[:78])
        hint = '\x18/\x19 выбор · Enter · цифры'
        while True:
            for i, (lab, val) in enumerate(items):
                GotoXY(2, y0 + 1 + i)
                if i == sel:
                    scr.col = 0x70
                elif lab.startswith(('С меня', 'Выйти')):
                    scr.col = 0x09
                elif lab in CM_NAMES:
                    scr.col = 0x0E
                else:
                    scr.col = 0x0B
                wr(lab[:76])
            GotoXY(1, 24)
            scr.col = 8
            wr(hint)
            flush()
            k = read_key()
            GotoXY(1, 24)
            wr(' ' * len(hint))
            if k in ('\r', '\n'):
                return items[sel][1]
            if k == '\x1b[A':
                sel = (sel - 1) % len(items)
            elif k == '\x1b[B':
                sel = (sel + 1) % len(items)
            elif k.isdigit() and k != '0' and int(k) <= len(items):
                return items[int(k) - 1][1]
    flush()
    if title:
        print(title)
    for i, (lab, _) in enumerate(items, 1):
        print(f'  {i}) {lab}')
    while True:
        s = _in('> ').strip()
        if s.isdigit() and 1 <= int(s) <= len(items):
            return items[int(s) - 1][1]
        print(f'Введи число от 1 до {len(items)}')


def die(cause):
    if not g.end:
        g.end = 1
        g.cause = cause


def bsod(err):
    """Шуточный синий экран: падение игры не тащит ничего за собой."""
    try:
        lines = (
            '',
            '                    MMHEROES : СИНИЙ ЭКРАН СМЕРТИ',
            '',
            '     Произошла непоправимая ошибка зачетной недели.',
            f'     Код ошибки: 0E : {id(err) % 0xFFFF:04X} : {type(err).__name__}',
            f'     {str(err)[:62]}',
            '',
            '  *  Нажми любую клавишу, чтобы сделать вид, что этого не было.',
            '  *  Нажми CTRL+ALT+DEL, чтобы пойти пересдавать.',
            '  *  Если повторится — так и задумано, это МАТ-МЕХ.',
            '',
            '     Раздавлен безжалостной ошибкой в программе.',
            '     Срочно обратитесь к разработчику ;)',
            '',
        )
        color = sys.stdout.isatty()
        for ln in lines:
            pad = ln.center(72)[:72]
            if color:
                pad = f'\033[1;44;97m{pad}\033[0m'
            print(pad)
        if '--debug' in sys.argv:
            traceback.print_exc()
        try:
            input('[Enter] ')
        except Exception:
            pass
    except Exception:
        pass


def die(cause):
    if not g.end:
        g.end = 1
        g.cause = cause


def dec_hp(n, cause):
    g.hp -= n
    if g.hp <= 0:
        die(cause)


def prof_here(s):
    t = g.ts[g.day][s]
    return t['w'] == g.place and t['f'] <= g.hour < t['t']


def prof_today(s):
    return g.ts[g.day][s]['w'] == g.place


def nine19():
    return 8 < g.hour < 20
