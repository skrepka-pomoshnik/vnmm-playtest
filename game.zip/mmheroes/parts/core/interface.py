# ---------------------------------------------------------------- интерфейс


HEALTH_LINE = [1, 9, 17, 25, 33, 41]
HEALTH_STR = ('живой труп', 'пора помирать ...', 'плохое', 'так себе',
              'среднее', 'хорошее', 'отличное')
HEALTH_COL = [5, 4, 4, 0xE, 0xE, 0xA, 0xA]
BRAIN_LINE = [0, 1, 2, 3, 4, 5, 6, 0x65]
BRAIN_STR = ('Клиническая смерть мозга', 'Голова просто никакая',
             'Думать практически невозможно', 'Думать трудно',
             'Голова почти в норме', 'Голова в норме', 'Голова свежая',
             'Легкость в мыслях необыкновенная',
             'Обратитесь к разработчику ;)')
BRAIN_COL = [5, 5, 0xC, 0xC, 0xE, 0xE, 0xA, 0xA, 0xB]
STAM_LINE = [0, 1, 2, 3, 4, 5, 6]
STAM_STR = ('Мама, роди меня обратно!', 'Окончательно заучился',
            'Я так больше немогууу!', 'Скорее бы все это кончилось...',
            'Еще немного и пора отдыхать', 'Немного устал',
            'Готов к труду и обороне', 'Нас ждут великие дела')
STAM_COL = [5, 5, 0xC, 0xC, 0xE, 0xE, 0xA, 0xA]
CHAR_LINE = [1, 2, 3, 4, 5, 6]
CHAR_STR = ('Очень замкнутый товарищ', 'Предпочитаешь одиночество',
            'Тебе трудно общаться с людьми', 'Тебе непросто общаться с людьми',
            'Ты нормально относишься к окружающим', 'У тебя много друзей',
            'У тебя очень много друзей')
CHAR_COL = [5, 5, 0xC, 0xC, 0xE, 0xA, 0xA]
KNOW_LINE = [6, 13, 21, 31]
KNOW_COL = [3, 7, 0xF, 0xA, 0xE]
KNOW_SUBJ_LINE = ([11, 21, 51], [9, 19, 41], [6, 11, 31],
                  [10, 16, 31], [5, 9, 16], [5, 9, 16])
KNOW_SUBJ_STR = ('Плохо', 'Удовл.', 'Хорошо', 'Отлично')
KNOW_SUBJ_COL = [3, 7, 0xF, 0xE]


def hdr():
    """Точная копия show_header_stats оригинала: координаты и цвета из JS."""
    ClrScr()
    GotoXY(1, 1)
    scr.col = 7
    wr('Сегодня ')
    scr.col = 0xF
    wr(f'{g.day + 22}е мая; {g.hour:02d}:00')
    GotoXY(26, 1)
    scr.col = 0xD
    wr('Версия gamma3.14')
    scr.col = 7
    GotoXY(1, 2)
    wr('Самочувствие: ')
    i = _upper_bound(HEALTH_LINE, g.hp)
    scr.col = HEALTH_COL[i]
    wr(HEALTH_STR[i])
    scr.col = 7
    GotoXY(1, 3)
    wr('Финансы: ')
    if g.money > 0:
        scr.col = 0xF
        wr(f'{g.money} руб.')
    elif not g.stipend:
        scr.col = 0xC
        wr('Надо получить деньги за май...')
    else:
        wr('Ты успел потратить все деньги.')
    scr.col = 7
    GotoXY(1, 4)
    i = _upper_bound(BRAIN_LINE, g.brain)
    scr.col = BRAIN_COL[i]
    wr(BRAIN_STR[i])
    GotoXY(1, 5)
    i = _upper_bound(STAM_LINE, g.stam)
    scr.col = STAM_COL[i]
    wr(STAM_STR[i])
    GotoXY(1, 6)
    i = _upper_bound(CHAR_LINE, max(g.char, 0))
    scr.col = CHAR_COL[i]
    wr(CHAR_STR[i])
    scr.col = 7
    for s in range(6):
        su = SUBJ[s]
        know = max(g.know[s], 0)
        GotoXY(45, s + 1)
        scr.col = 0xB
        wr(su[2])
        GotoXY(67, s + 1)
        scr.col = KNOW_COL[_upper_bound(KNOW_LINE, know)]
        wr(str(know))
        GotoXY(71, s + 1)
        k = _upper_bound(KNOW_SUBJ_LINE[s], know)
        scr.col = KNOW_SUBJ_COL[k]
        wr(KNOW_SUBJ_STR[k])
        if prof_here(s):
            GotoXY(43, s + 1)
            scr.col = 0xE
            wr('!')
    scr.col = 7
    short_timesheet()


def short_timesheet(y=10):
    """show_short_today_timesheet: мини-расписание справа."""
    for s in range(6):
        t = g.ts[g.day][s]
        passed = g.passed[s]
        GotoXY(50, y + s)
        scr.col = 1 if passed else 0xB
        wr(SUBJ[s][2])
        GotoXY(56, y + s)
        scr.col = 5 if passed else 0xC
        wr(PLACES[t['w']])
        if t['w']:
            GotoXY(62, y + s)
            scr.col = 8 if passed else 0xF
            wr(f"{t['f']}-{t['t']}")
        GotoXY(68, y + s)
        done = g.done[s]
        scr.col = 7 if done == 0 else (0xA if done < SUBJ[s][5] else 0xE)
        wr(f'{done}/{SUBJ[s][5]}')
    scr.col = 7


def ts_full():
    ClrScr()
    GotoXY(1, 1)
    scr.col = 0xF
    wr('РАСПИСАНИЕ НЕДЕЛИ: когда и где можно найти искомого препода ?')
    for d in range(6):
        GotoXY(21 + d * 10, 3)
        scr.col = 0xE if d == g.day else 7
        wr(DATES[d])
    for s, su in enumerate(SUBJ):
        ry = 5 + s * 3
        GotoXY(1, ry)
        scr.col = 0xA
        wr(su[0][:18])
        GotoXY(1, ry + 1)
        scr.col = 0xB
        wr(su[1][:18])
        for d in range(6):
            t = g.ts[d][s]
            x = 21 + d * 10
            GotoXY(x, ry)
            if t['w']:
                scr.col = 1 if g.passed[s] else 7
                wr(PLACES[t['w']])
            else:
                scr.col = 8
                wr('----')
            GotoXY(x, ry + 1)
            if t['w'] and not g.passed[s]:
                scr.col = 0xF
                wr(f"{t['f']:02d}-{t['t']:02d}")
    GotoXY(1, 23)
    scr.col = 7
    if g.left == 0:
        scr.col = 0xF
        wr('Все уже сдано!')
    elif g.left == 1:
        scr.col = 0xD
        wr('Остался 1 зачет!')
    else:
        wr(f'Осталось {g.left} зачетов.')
    scr.col = 7


def show_top(where):
    ClrScr()
    GotoXY(1, 1)
    scr.col = 0xF
    wr('* * *'.center(60))
    GotoXY(1, 3)
    scr.col = 0xE
    say(f'{where}: имена тех, кто прошел это наводящее ужас испытание:')
    say()
    scr.col = 7
    say('   ГЕРОЙ            ЗАРАБОТАЛ')
    if not TOP:
        say('   (пока пусто)')
    for i, sc in enumerate(sorted(TOP, reverse=True)[:5], 1):
        say(f' {i}. Герой          {sc} руб.')
    scr.col = 7
    pause()


def help_scr():
    say("""
Есть всего 6 дней. За это время надо успеть получить 6 зачетов.
Чтобы получить зачет, нужно сдать преподу нужное число заданий.
Чтобы сдать задания, нужно чего-то знать и прийти к преподу вовремя.
Чтобы чего-то знать, нужно готовиться (конспект Саши заметно помогает).
Преподавателей надо искать по расписанию; они уходят - время дорого.
Пока готовишься или сдаешь, самочувствие ухудшается; отдых его лечит.
Деньги: стипуха у Паши, ТЕРКОМ, NiL; тратятся на еду и билеты.
Всякие дополнительные персонажи могут помогать, а могут мешать.""")
    pause()


def try_exit():
    r = menu('Ты что, серьезно хочешь закончить игру?',
             [('Нет, не хочу!', 1), ('Я же сказал: с меня хватит!', 2)])
    if r == 2:
        die('Вышел сам.')
