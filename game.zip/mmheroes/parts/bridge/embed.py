def run_embedded(policy, seed=None, god=False, max_steps=20000):
    """Партия как мини-игра: тихо, без экрана и клавиатуры.

    policy(title, items) -> value — хост отвечает на каждое меню
    (items — список (label, value)); первым приходит выбор архетипа.
    Возвращает словарь итогов; состояние модуля восстанавливается,
    исключения пробрасываются хосту после восстановления.
    Один запуск за раз; не вызывать из потоков.
    """
    global SEED, GOD_ARG, ROBOT
    saved_seed, saved_godarg = SEED, GOD_ARG
    saved_robot = ROBOT
    saved_top = TOP[:]
    saved_menu, saved_pause = menu, pause

    def q_menu(title, items):
        return policy(title, list(items))

    def q_pause():
        pass

    globals()['menu'] = q_menu
    globals()['pause'] = q_pause
    try:
        SEED = seed
        GOD_ARG = god
        new_game()
        steps = 0
        while not g.end:
            router()
            steps += 1
            if steps > max_steps:
                raise RuntimeError('run_embedded: превышен лимит шагов')
        return {
            'win': g.hp > 0 and g.left == 0,
            'alive': g.hp > 0,
            'exams_left': g.left,
            'passed': g.passed[:],
            'tasks': g.done[:],
            'knowledge': g.know[:],
            'score': final_score(),
            'money': g.money,
            'days': min(g.day + 1, 6),
            'hp': g.hp,
            'cause': g.cause or None,
        }
    finally:
        globals()['menu'] = saved_menu
        globals()['pause'] = saved_pause
        SEED, GOD_ARG, ROBOT = saved_seed, saved_godarg, saved_robot
        TOP[:] = saved_top


class _OriginalMenuRequest(Exception):
    """Internal suspension point for the Ren'Py adapter."""

    def __init__(self, title, items):
        super().__init__(title)
        self.title = title
        self.items = tuple(items)
        self.frame = _render_menu_frame(title, self.items)


class OriginalMenuRequest:
    """A serializable view of one menu from the original game."""

    def __init__(self, title, items, frame):
        self.title = title
        self.items = tuple(items)
        self.frame = frame


ORIGINAL_HERO_OPTIONS = (
    ('Случайный студент', 1),
    ('Шибко умный', 2),
    ('Шибко наглый', 3),
    ('Шибко общительный', 4),
)


def _screen_text():
    """Return the current DOS buffer without touching the legacy screen."""

    return '\n'.join(''.join(row).rstrip() for row in scr.b).rstrip()


def _render_menu_frame(title, items):
    """Add a menu request to the current 80x25 original DOS frame."""

    rows = [list(row) for row in scr.b]

    def write(row, column, value, limit):
        if not 0 <= row < len(rows):
            return
        for offset, char in enumerate(str(value)[:limit]):
            if column + offset < len(rows[row]):
                rows[row][column + offset] = char

    y0 = max(7, min(max(scr.y + 2, 9), 22 - len(items)))
    write(y0, 0, title, 78)
    for index, (label, _value) in enumerate(items, 1):
        write(y0 + index, 1, f'{index}) {label}', 78)
    write(23, 0, '↑/↓ выбор · Enter · цифры', 78)
    return '\n'.join(''.join(row).rstrip() for row in rows).rstrip()


def _engine_snapshot():
    """Copy the mutable legacy state at a menu boundary."""

    return copy.deepcopy(g.__dict__)


def _restore_engine(snapshot):
    g.__dict__.clear()
    g.__dict__.update(copy.deepcopy(snapshot))


class OriginalSession:
    """Pauseable Ren'Py bridge for the complete original MMHEROES game.

    The legacy port is written as a synchronous terminal program.  A screen
    cannot call its blocking ``main`` loop, so this controller turns each
    original ``menu`` call into a request.  A selected path is replayed from
    the last menu boundary with the copied legacy state and RNG; nested menus
    (travel tickets, exam choices, exit confirmation, and so on) therefore
    retain the original rules without applying an action twice.
    """

    def __init__(self, seed=None, god=False):
        self.seed = seed
        self.god = bool(god)
        hero_options = ORIGINAL_HERO_OPTIONS + (("GOD-режим", 100),) if self.god else ORIGINAL_HERO_OPTIONS
        self._initialized = False
        self._initializing = False
        self._hero = None
        self._path = []
        self._replay_index = 0
        self._root_snapshot = None
        self._request = OriginalMenuRequest(
            'Выбери начальные параметры своего "героя":',
            hero_options,
            'MMHEROES.EXE\n\n' + '\n'.join(
                f'{index}) {label}' for index, (label, _value) in enumerate(
                    hero_options,
                    1,
                )
            ),
        )
        self._error = None

    @property
    def request(self):
        return self._request

    @property
    def menu_title(self):
        return self._request.title if self._request is not None else ''

    @property
    def menu_items(self):
        return self._request.items if self._request is not None else ()

    @property
    def terminal_text(self):
        if self._request is not None:
            return self._request.frame
        return _screen_text()

    @property
    def finished(self):
        return self._error is not None or (self._initialized and bool(getattr(g, 'end', 0)))

    @property
    def error(self):
        return self._error

    @property
    def status(self):
        """Return the current original-game values used by the Ren'Py HUD."""

        if not self._initialized:
            return {
                'date': '22.05',
                'hour': 8,
                'day': 1,
                'place': PLACES[HOME],
                'health': 0,
                'brain': 0,
                'stamina': 0,
                'charisma': 0,
                'money': 0,
                'exams_left': len(SUBJ),
                'passed': (False,) * len(SUBJ),
                'knowledge': (0,) * len(SUBJ),
                'tasks': (0,) * len(SUBJ),
            }
        return {
            'date': f'{g.day + 22:02d}.05',
            'hour': g.hour,
            'day': g.day + 1,
            'place': PLACES[g.place] if 0 <= g.place < len(PLACES) else '----',
            'health': g.hp,
            'brain': g.brain,
            'stamina': g.stam,
            'charisma': g.char,
            'money': g.money,
            'exams_left': g.left,
            'passed': tuple(bool(value) for value in g.passed),
            'knowledge': tuple(max(0, value) for value in g.know),
            'tasks': tuple(g.done),
        }

    def _menu(self, title, items):
        items = tuple(items)
        if self._initializing:
            self._initializing = False
            return self._hero
        if self._replay_index < len(self._path):
            value = self._path[self._replay_index]
            self._replay_index += 1
            if any(candidate == value for _label, candidate in items):
                return value
            raise RuntimeError('original MMHEROES menu changed while replaying a choice')
        raise _OriginalMenuRequest(title, items)

    @staticmethod
    def _pause():
        return None

    def _run_router(self):
        self._replay_index = 0
        saved_menu, saved_pause = menu, pause
        globals()['menu'] = self._menu
        globals()['pause'] = self._pause
        try:
            router()
        except _OriginalMenuRequest as request:
            self._request = OriginalMenuRequest(request.title, request.items, request.frame)
            return 'request'
        except Exception as error:
            self._request = None
            self._error = f'{type(error).__name__}: {error}'
            return 'error'
        finally:
            globals()['menu'] = saved_menu
            globals()['pause'] = saved_pause
        if getattr(g, 'end', 0):
            final_pause = pause
            globals()['pause'] = self._pause
            try:
                game_end()
            except Exception as error:
                self._error = f'{type(error).__name__}: {error}'
            finally:
                globals()['pause'] = final_pause
        self._request = None
        return 'done'

    def _open_next_menu(self):
        self._path = []
        self._root_snapshot = _engine_snapshot()
        outcome = self._run_router()
        if outcome == 'done' and not self.finished:
            self._root_snapshot = _engine_snapshot()
            self._run_router()

    def _initialize(self, hero):
        saved_seed, saved_godarg, saved_robot, saved_god_mode = (
            SEED,
            GOD_ARG,
            ROBOT,
            GOD_MODE,
        )
        self._hero = hero
        self._initializing = True
        globals()['SEED'] = self.seed
        globals()['GOD_ARG'] = self.god
        globals()['ROBOT'] = None
        globals()['GOD_MODE'] = self.god
        saved_menu, saved_pause = menu, pause
        globals()['menu'] = self._menu
        globals()['pause'] = self._pause
        try:
            new_game()
        except Exception as error:
            self._error = f'{type(error).__name__}: {error}'
        finally:
            globals()['menu'] = saved_menu
            globals()['pause'] = saved_pause
            globals()['SEED'] = saved_seed
            globals()['GOD_ARG'] = saved_godarg
            globals()['ROBOT'] = saved_robot
            globals()['GOD_MODE'] = saved_god_mode
            self._initializing = False
        if self._error is not None:
            self._request = None
            return
        self._initialized = True
        self._open_next_menu()

    def choose(self, value):
        """Apply one visible original menu choice and stop at the next one."""

        if self.finished or self._request is None:
            return False
        if not any(candidate == value for _label, candidate in self._request.items):
            return False
        if not self._initialized:
            self._initialize(value)
            return True
        self._path.append(value)
        _restore_engine(self._root_snapshot)
        outcome = self._run_router()
        if outcome == 'request':
            return True
        if self.finished:
            return True
        self._open_next_menu()
        return True

    def result(self):
        """Return the same result shape as ``run_embedded``."""

        return {
            'win': g.hp > 0 and g.left == 0,
            'alive': g.hp > 0,
            'exams_left': g.left,
            'passed': g.passed[:],
            'tasks': g.done[:],
            'knowledge': g.know[:],
            'score': final_score(),
            'money': g.money,
            'days': min(g.day + 1, 6),
            'hp': g.hp,
            'cause': g.cause or None,
        }
