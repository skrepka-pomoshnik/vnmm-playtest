def again():
    return menu('Хочешь попробовать еще?',
                [('ДА!!! ДА!!! ДА!!!', 1), ('Нет... Нет... Не-э-эт...', 2)]) == 1


def selftest():
    """Инварианты баланса и генерации расписания (соответствие оригиналу)."""
    ok = 0
    fails = []
    g.rnd = random.Random(1)
    for _ in range(500):
        v = R(10)
        if not 0 <= v < 10:
            fails.append('R вне [0,n)')
            break
    else:
        ok += 1
    if iround(0.5) == 1 and iround(2.5) == 3 and iround(-1.5) == -1:
        ok += 1  # как Pascal Round / JS Math.round
    else:
        fails.append('iround != Math.round')
    if (zad(1), zad(2), zad(5), zad(11), zad(21)) == (
            ' задание', ' задания', ' заданий', ' заданий', ' задание'):
        ok += 1
    else:
        fails.append('склонение заданий')
    bad_sched = 0
    for seed in range(60):
        g.rnd = random.Random(seed)
        init_ts()
        for s, su in enumerate(SUBJ):
            wins = [t for d in range(6) for t in [g.ts[d][s]] if t['w']]
            if len(wins) != su[7]:
                bad_sched += 1
            for t in wins:
                if not 9 <= t['f'] <= 18 - su[9] or \
                        not su[8] <= t['t'] - t['f'] <= su[9] or \
                        t['w'] not in su[10]:
                    bad_sched += 1
    if not bad_sched:
        ok += 1
    else:
        fails.append(f'расписание: {bad_sched} нарушений')
    # сон: hp после сна всегда в (40..50], час >=7
    g2_ok = True
    for h0 in (40, 45, 49):
        for _ in range(200):
            g.hp = h0
            grow = min(g.hp + 15 + R(20), 50) - g.hp
            g.hp += grow
            hh = R(grow // 4) + 7
            if not 40 <= g.hp <= 50 or not 7 <= hh <= 19:
                g2_ok = False
    if g2_ok:
        ok += 1
    else:
        fails.append('сон вне диапазона')
    print(f'selftest: {ok} проверок пройдено'
          + ('' if not fails else '; ПРОВАЛЫ: ' + '; '.join(fails)))
    return not fails


def main():
    global ROBOT, SEED, GOD_ARG, TTY
    args = sys.argv[1:]
    games = 1
    if '--robot' in args:
        idx = args.index('--robot')
        if idx + 1 < len(args) and args[idx + 1].isdigit():
            games = int(args[idx + 1])
        ROBOT = random.Random(SEED if SEED is not None else 0)
    if '--seed' in args:
        idx = args.index('--seed')
        if idx + 1 < len(args):
            try:
                SEED = int(args[idx + 1])
            except ValueError:
                pass
    GOD_ARG = '--god' in args

    if '--selftest' in args:
        sys.exit(0 if selftest() else 1)
    TTY = HAS_TTY and sys.stdout.isatty() and sys.stdin.isatty()
    try:
        if TTY:
            sys.stdout.write('\033[2J\033[H\033[?25l')
        wins = deaths = crashes = 0
        for _ in range(games):
            while True:
                try:
                    new_game()
                    while not g.end:
                        router()
                    before = len(TOP)
                    game_end()
                    if len(TOP) > before:
                        wins += 1
                    else:
                        deaths += 1
                except SystemExit:
                    raise
                except KeyboardInterrupt:
                    print('\nСрочная эвакуация с сессии! С меня хватит...')
                    return
                except Exception as err:  # BSOD вместо обвала
                    bsod(err)
                    crashes += 1
                    break
                if ROBOT is not None or not again():
                    break
    finally:
        if TTY:
            sys.stdout.write('\033[0m\033[?25h\n')
    if ROBOT is not None:
        print(f'[robot] игр: {games}, финалов со стипухой: {wins}, '
              f'отчислен/погиб: {deaths}, синих экранов: {crashes}')


if __name__ == '__main__':
    try:
        rc = main()
    except BrokenPipeError:
        # stdout закрыт (например, mmheroes.py | head): тихо уходим
        try:
            os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        except Exception:
            pass
        rc = 0
    except SystemExit as e:
        # штатный выход по EOF: сообщение уже выведено, код 0
        if e.code and not isinstance(e.code, int):
            try:
                sys.stderr.write(str(e.code) + '\n')
            except Exception:
                pass
        rc = e.code if isinstance(e.code, int) else 0
    except Exception:
        # последняя линия обороны: даже если сломался сам BSOD
        try:
            sys.stderr.write('\nMMHEROES: аварийный выход.\n')
        except Exception:
            pass
        rc = 1
    sys.exit(rc)
