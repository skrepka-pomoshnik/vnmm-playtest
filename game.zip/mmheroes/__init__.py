"""Runtime API for the embedded MMHEROES game.

The Ren'Py project ships this package with the Windows distribution.  The
interactive DOS terminal remains available through ``mmheroes.py``; hosts
should use ``OriginalSession`` or ``run_embedded`` instead of calling
``main``.
"""

from .mmheroes import ORIGINAL_HERO_OPTIONS, OriginalMenuRequest, OriginalSession, run_embedded

__all__ = (
    "ORIGINAL_HERO_OPTIONS",
    "OriginalMenuRequest",
    "OriginalSession",
    "run_embedded",
)
